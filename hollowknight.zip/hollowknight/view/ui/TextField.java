package com.hollowknight.view.ui;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
public class TextField {

    public float x, y, w, h;
    public final String  placeholder;
    public final boolean isPassword;
    public boolean focused = false;

    private final StringBuilder text = new StringBuilder();
    private final int maxLength;
    public TextField(float x, float y, float w, float h, String placeholder, boolean isPassword) {
        this(x, y, w, h, placeholder, isPassword, 32);
    }

    public TextField(float x, float y, float w, float h, String placeholder, boolean isPassword, int maxLength) {
        this.x = x; this.y = y; this.w = w; this.h = h;
        this.placeholder = placeholder;
        this.isPassword  = isPassword;
        this.maxLength   = maxLength;
    }

    ///input
    public boolean hitTest(float mx, float my) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
    public void typeChar(char c) {
        if (!focused) return;
        if (c == '\b') {                      // backspace
            if (text.length() > 0) text.deleteCharAt(text.length() - 1);
            return;
        }
        if (c < 32 || c == 127) return;        // ignore other control chars
        if (text.length() < maxLength) text.append(c);
    }
    public String getValue() { return text.toString(); }
    public void   clear()    { text.setLength(0); }
    public void draw(ShapeRenderer shapes, SpriteBatch batch, BitmapFont font) {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(focused ? new Color(0.22f, 0.30f, 0.55f, 1f) : new Color(0.16f, 0.16f, 0.26f, 1f));
        shapes.rect(x, y, w, h);
        shapes.setColor(focused ? new Color(0.75f, 0.80f, 1.0f, 1f) : new Color(0.40f, 0.40f, 0.60f, 1f));
        shapes.rect(x, y, w, 2);
        shapes.rect(x, y + h - 2, w, 2);
        shapes.rect(x, y, 2, h);
        shapes.rect(x + w - 2, y, 2, h);
        shapes.end();
        String base = text.length() == 0 ? "" : (isPassword ? "*".repeat(text.length()) : text.toString());
        String shown = base;
        if (focused) {
            boolean blinkOn = (System.currentTimeMillis() / 500L) % 2 == 0;
            shown = base + (blinkOn ? "|" : "");
        }
        boolean showPlaceholder = text.length() == 0 && !focused;

        batch.begin();
        font.setColor(showPlaceholder ? new Color(0.5f, 0.5f, 0.6f, 1f) : Color.WHITE);
        font.draw(batch, showPlaceholder ? placeholder : shown, x + 10, y + h / 2f + 6);
        batch.end();
    }
}
