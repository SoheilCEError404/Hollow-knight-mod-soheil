package com.hollowknight.view;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.GameState;
import com.hollowknight.model.player.Player;
import com.hollowknight.model.system.AchievementSystem;
import com.hollowknight.model.item.CharmType;

public class HUD {

    private static final float MASK_SIZE    = 56f;
    private static final float MASK_PAD     = 6f;
    private static final float MASK_ORIGIN_X = 18f;
    private static final float MASK_ORIGIN_Y_OFFSET = 30f;

    private static final float SOUL_X = 18f;
    private static final float SOUL_W = 44f;
    private static final float SOUL_H = 44f;

    private final Texture maskFull, maskEmpty, vesselFrame, vesselLiquid;
    private final java.util.EnumMap<CharmType, Texture> charmIcons =
        new java.util.EnumMap<>(CharmType.class);
    public String cheatMessage  = null;
    public int    cheatMsgTimer = 0;

    public HUD() {
        maskFull     = tryLoad("sprites/ui/hud/mask_full.png");
        maskEmpty    = tryLoad("sprites/ui/hud/mask_empty.png");
        vesselFrame  = tryLoad("sprites/ui/hud/vessel_frame.png");
        vesselLiquid = tryLoad("sprites/ui/hud/vessel_liquid.png");
        for (CharmType c : CharmType.values())
            charmIcons.put(c, tryLoad("sprites/ui/charms/" + c.name().toLowerCase() + ".png"));
    }

    private Texture tryLoad(String path) {
        try {
            Texture texture = new Texture(path);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        } catch (Exception e) {
            com.badlogic.gdx.Gdx.app.log("HUD", "no texture: " + path);
            return null;
        }
    }
    public void render(SpriteBatch batch, ShapeRenderer shapes,
                       GameState gs, Viewport vp) {
        Player player = gs.getPlayer();
        if (player == null) return;

        float vw = vp.getWorldWidth();
        float vh = vp.getWorldHeight();

        boolean pngMasks  = maskFull != null && maskEmpty != null;
        boolean pngVessel = vesselFrame != null && vesselLiquid != null;
        if (pngMasks || pngVessel) {
            batch.begin();
            if (pngVessel) drawVesselPng(batch, player, vh);
            if (pngMasks)  drawMasksPng(batch, player, vh);
            batch.end();
        }
        if (!pngMasks || !pngVessel) {
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            if (!pngMasks)  drawMasks(shapes, player, vh);
            if (!pngVessel) drawSoulVessel(shapes, player, vh);
            shapes.end();
        }
        if (!player.equippedCharms.isEmpty()) {
            float size = 26f, pad = 6f;
            float startX = vw / 2f - (player.equippedCharms.size() * (size + pad)) / 2f;

            batch.begin();
            int charmPng = 0;
            for (var c : player.equippedCharms) {
                Texture icon = charmIcons.get(c);
                if (icon != null)
                    batch.draw(icon, startX + charmPng * (size + pad), 10f, size, size);
                charmPng++;
            }
            batch.end();

            shapes.begin(ShapeRenderer.ShapeType.Filled);
            int j = 0;
            for (var c : player.equippedCharms) {
                if (charmIcons.get(c) == null) {
                    shapes.setColor(0.85f, 0.75f, 0.20f, 1f);
                    shapes.ellipse(startX + j * (size + pad) + 7f, 17f, 12f, 12f);
                }
                j++;
            }
            shapes.end();
        }

        AchievementSystem.Achievement popup = gs.getAchievements().activePopup();
        if (popup != null) drawAchievementPopup(shapes, popup, vw, vh);

        if (cheatMsgTimer > 0) cheatMsgTimer--;
        else cheatMessage = null;
    }
    private void drawMasksPng(SpriteBatch b, Player p, float vh) {
        float y = vh - MASK_ORIGIN_Y_OFFSET - MASK_SIZE;
        float x0 = SOUL_X + SOUL_W + 10f;
        for (int i = 0; i < p.maxMasks; i++) {
            float x = x0 + i * (MASK_SIZE + MASK_PAD);
            b.draw(i < p.masks ? maskFull : maskEmpty, x, y, MASK_SIZE, MASK_SIZE);
        }
    }
    private void drawVesselPng(SpriteBatch b, Player p, float vh) {
        float x = SOUL_X;
        float y = vh - MASK_ORIGIN_Y_OFFSET - SOUL_H - 10f;
        float frac = (float) p.soul / p.maxSoul;

        if (frac > 0f) {
            int srcH = Math.max(1, (int)(vesselLiquid.getHeight() * frac));
            b.draw(vesselLiquid,
                x, y, SOUL_W, SOUL_H * frac,
                0, vesselLiquid.getHeight() - srcH,
                vesselLiquid.getWidth(), srcH, false, false);
        }
        b.draw(vesselFrame, x, y, SOUL_W, SOUL_H);
    }
    private void drawMasks(ShapeRenderer shape, Player p, float vh) {
        float y = vh - MASK_ORIGIN_Y_OFFSET - MASK_SIZE;
        for (int i = 0; i < p.maxMasks; i++) {
            float x = MASK_ORIGIN_X + i * (MASK_SIZE + MASK_PAD);
            boolean full = i < p.masks;
            shape.setColor(full ? 0.93f : 0.30f, full ? 0.93f : 0.30f,
                full ? 1.00f : 0.40f, 1f);
            shape.ellipse(x, y, MASK_SIZE, MASK_SIZE);
            float fill = MASK_SIZE * 0.55f;
            float off  = (MASK_SIZE - fill) / 2f;
            shape.setColor(full ? 0.70f : 0.15f, full ? 0.70f : 0.15f,
                full ? 0.90f : 0.20f, 1f);
            shape.ellipse(x + off, y + off, fill, fill);
        }
    }

    private void drawSoulVessel(ShapeRenderer s, Player p, float vh) {
        float x = SOUL_X;
        float y = vh - MASK_ORIGIN_Y_OFFSET - MASK_SIZE - 80f - 10f;
        s.setColor(GameConfig.COL_SOUL_BG[0], GameConfig.COL_SOUL_BG[1],
            GameConfig.COL_SOUL_BG[2], GameConfig.COL_SOUL_BG[3]);
        s.rect(x, y, 18f, 80f);
        float fillH = 80f * ((float) p.soul / p.maxSoul);
        s.setColor(GameConfig.COL_SOUL[0], GameConfig.COL_SOUL[1],
            GameConfig.COL_SOUL[2], GameConfig.COL_SOUL[3]);
        s.rect(x, y, 18f, fillH);
        s.setColor(0.55f, 0.70f, 1.0f, 1f);
        s.rect(x, y, 2f, 80f); s.rect(x + 16f, y, 2f, 80f);
        s.rect(x, y, 18f, 2f); s.rect(x, y + 78f, 18f, 2f);
    }

    private void drawAchievementPopup(ShapeRenderer s,
                                      AchievementSystem.Achievement popup, float vw, float vh) {
        float pw = 280f, ph = 50f;
        float px = vw - pw - 16f, py = vh - ph - 16f;
        if (!s.isDrawing()) s.begin(ShapeRenderer.ShapeType.Filled);
        s.setColor(0.10f, 0.10f, 0.18f, 0.92f);
        s.rect(px, py, pw, ph);
        s.setColor(0.85f, 0.75f, 0.20f, 1f);
        s.rect(px, py, pw, 2f); s.rect(px, py + ph - 2f, pw, 2f);
        s.rect(px, py, 2f, ph); s.rect(px + pw - 2f, py, 2f, ph);
        s.end();
    }

    public void setCheatMessage(String msg) {
        cheatMessage  = msg;
        cheatMsgTimer = 180;
    }

    public void dispose() {
        if (maskFull != null)     maskFull.dispose();
        if (maskEmpty != null)    maskEmpty.dispose();
        if (vesselFrame != null)  vesselFrame.dispose();
        if (vesselLiquid != null) vesselLiquid.dispose();
        for (Texture t : charmIcons.values())
            if (t != null) t.dispose();
    }
}
