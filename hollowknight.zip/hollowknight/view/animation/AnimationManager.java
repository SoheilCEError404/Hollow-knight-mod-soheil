package com.hollowknight.view.animation;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.hollowknight.model.player.PlayerState;
import java.util.EnumMap;
import java.util.Map;

public class AnimationManager {

    private static class Anim {
        Animation<TextureRegion> anim;
        float   stateTime = 0f;
        boolean loop = true;
        Anim(Animation<TextureRegion> a, boolean loop) { this.anim = a; this.loop = loop; }
    }
    private final Map<PlayerState, Anim>      animations        = new EnumMap<>(PlayerState.class);
    private final Map<PlayerState, Texture>   sheetTextures     = new EnumMap<>(PlayerState.class);
    private final Map<PlayerState, Texture[]> sequenceTextures  = new EnumMap<>(PlayerState.class);

    private PlayerState current = PlayerState.IDLE;
    public void loadSheet(PlayerState state, String path, int cols, int rows, float frameSecs) {
        loadSheet(state, path, cols, rows, frameSecs, true);
    }

    public void loadSheet(PlayerState state, String path, int cols, int rows, float frameSecs, boolean loop) {
        try {
            Texture sheet = new Texture(path);
            sheetTextures.put(state, sheet);
            int fw = sheet.getWidth()  / cols;
            int fh = sheet.getHeight() / rows;
            TextureRegion[][] tmp = TextureRegion.split(sheet, fw, fh);
            TextureRegion[] frames = new TextureRegion[cols * rows];
            int k = 0;
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    frames[k++] = tmp[r][c];
            animations.put(state, new Anim(new Animation<>(frameSecs, frames), loop));
        } catch (Exception e) {
            Gdx.app.error("AnimationManager", "notfound " + state + " (" + path + "): " + e.getMessage());
        }
    }
    public void loadFrameSequence(PlayerState state, String folder, String prefix, int frameCount, int digits, String extension, float frameSecs, boolean loop) {
        try {
            TextureRegion[] frames        = new TextureRegion[frameCount];
            Texture[] frameTextures = new Texture[frameCount];

            for (int i = 0; i < frameCount; i++) {
                String num  = String.format("%0" + digits + "d", i);
                String path = folder + "/" + prefix + num + "." + extension;
                Texture tex = new Texture(Gdx.files.internal(path));
                frameTextures[i] = tex;
                frames[i] = new TextureRegion(tex);
            }
            sequenceTextures.put(state, frameTextures);
            animations.put(state, new Anim(new Animation<>(frameSecs, frames), loop));
        } catch (Exception e) {
            Gdx.app.error("AnimationManager", "notfound " + state + ": " + e.getMessage());
        }
    }

    public void update(PlayerState state, float delta) {
        if (state != current) {
            current = state;
            Anim a = animations.get(current);
            if (a != null) a.stateTime = 0f;   // restart the animation from frame 0
        }
        Anim a = animations.get(current);
        if (a != null) a.stateTime += delta;
    }
    public void draw(SpriteBatch batch, float x, float y, float w, float h, boolean flipX) {
        Anim a = animations.get(current);
        if (a == null) return;
        TextureRegion frame = a.anim.getKeyFrame(a.stateTime, a.loop);
        if (flipX != frame.isFlipX()) frame.flip(true, false);
        batch.draw(frame, x, y, w, h);
    }
    /// //////
    public void dispose() {
        sheetTextures.values().forEach(Texture::dispose);
        sequenceTextures.values().forEach(arr -> {
            for (Texture t : arr) if (t != null) t.dispose();
        });
    }
}
