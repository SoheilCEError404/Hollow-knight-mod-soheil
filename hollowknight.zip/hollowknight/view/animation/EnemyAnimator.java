package com.hollowknight.view.animation;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import java.util.HashMap;
import java.util.Map;

public class EnemyAnimator {

    private final Map<String, Animation<TextureRegion>> anims    = new HashMap<>();
    private final Map<String, Texture[]>                textures = new HashMap<>();

    public void loadFrameSequence(String key, String folder, String prefix, int frameCount, int digits, String extension, float frameSecs) {
        try {
            TextureRegion[] frames = new TextureRegion[frameCount];
            Texture[] texArr = new Texture[frameCount];
            for (int i = 0; i < frameCount; i++) {
                String num  = String.format("%0" + digits + "d", i);
                String path = folder + "/" + prefix + num + "." + extension;
                if (!Gdx.files.internal(path).exists()) {
                    Gdx.app.error("EnemyAnimator", "Frame not found: " + path);
                    return;
                }
                Texture t = new Texture(Gdx.files.internal(path));
                texArr[i] = t;
                frames[i] = new TextureRegion(t);
            }
            textures.put(key, texArr);
            anims.put(key, new Animation<>(frameSecs, frames));
        } catch (Exception e) {
            Gdx.app.error("EnemyAnimator", "failed " + key + ": " + e.getMessage());
        }

    }
    public void loadSheetRow(String key, String path, int cols, int rows, int row, int frameCount, float frameDuration) {
        try {
            com.badlogic.gdx.graphics.Texture sheet =
                new com.badlogic.gdx.graphics.Texture(com.badlogic.gdx.Gdx.files.internal(path));
            sheet.setFilter(com.badlogic.gdx.graphics.Texture.TextureFilter.Linear, com.badlogic.gdx.graphics.Texture.TextureFilter.Linear);

            com.badlogic.gdx.graphics.g2d.TextureRegion[][] grid = com.badlogic.gdx.graphics.g2d.TextureRegion.split(sheet, sheet.getWidth() / cols, sheet.getHeight() / rows);
            com.badlogic.gdx.graphics.g2d.TextureRegion[] frames = new com.badlogic.gdx.graphics.g2d.TextureRegion[frameCount];
            for (int i = 0; i < frameCount; i++) frames[i] = grid[row][i];
            anims.put(key,
                new com.badlogic.gdx.graphics.g2d.Animation<>(frameDuration, frames));
            textures.put(key, new Texture[]{ sheet });    // برای dispose
        } catch (Exception e) {
            com.badlogic.gdx.Gdx.app.log("EnemyAnimator", "notfound: " + path);
        }
    }

    public boolean has(String key) { return anims.containsKey(key); }
    public void draw(SpriteBatch batch, String key, float stateTime,
                     float x, float y, float w, float h, boolean flipX) {
        Animation<TextureRegion> a = anims.get(key);
        if (a == null) return;
        TextureRegion frame = a.getKeyFrame(stateTime, true);   // loop
        if (flipX != frame.isFlipX()) frame.flip(true, false);
        batch.draw(frame, x, y, w, h);
    }
    /// ////
    public void dispose() {
        textures.values().forEach(arr -> {
            for (Texture t : arr) if (t != null) t.dispose();
        });
    }
}
