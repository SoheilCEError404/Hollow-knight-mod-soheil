package com.hollowknight.view.screens;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.system.SaveManager;

public class NewGameScreen extends BaseScreen {

    private SaveManager.SaveData[] slots;
    private int confirmSlot = -1;   // slot awaiting overwrite confirmation, -1 = none

    private static final float ROW_W = VW - 80, ROW_H = 56, ROW_PAD = 14;
    private static final float ROW_X = 40;
    private static final float ROW_Y_TOP = VH - 140;

    public NewGameScreen(HollowKnight game) { super(game); }

    @Override
    public void show() {
        super.show();
        slots       = game.saveManager.loadAllSlots();
        confirmSlot = -1;
    }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        float bx = 24, by = VH - 70;
        if (drawButton(bx, by, 100, 34, "Back", isHovered(bx, by, 100, 34))) {
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        }

        drawTitle("New Game");

        for (int i = 0; i < slots.length; i++) {
            float ry = ROW_Y_TOP - i * (ROW_H + ROW_PAD);
            drawRow(i, ry);
        }

        if (confirmSlot >= 0) drawConfirmOverlay();
    }

    private void drawRow(int index, float y) {
        SaveManager.SaveData sd = slots[index];
        boolean empty = sd == null;

        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(empty ? new Color(0.14f, 0.20f, 0.14f, 1f)
                              : new Color(0.30f, 0.18f, 0.18f, 1f));
        shapes.rect(ROW_X, y, ROW_W, ROW_H);
        shapes.setColor(empty ? new Color(0.45f, 0.75f, 0.45f, 1f)
                              : new Color(0.80f, 0.45f, 0.45f, 1f));
        shapes.rect(ROW_X, y, ROW_W, 2);
        shapes.rect(ROW_X, y + ROW_H - 2, ROW_W, 2);
        shapes.end();

        String label = empty
                ? "Slot " + (index + 1) + "  —  Empty" : "Slot " + (index + 1) + "   " + sd.completionPercent + "%   (starting here will overwrite)";

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, label, ROW_X + 16, y + ROW_H / 2f + 6);
        batch.end();

        float startX = ROW_X + ROW_W - 100, startY = y + ROW_H / 2f - 16;
        if (drawButton(startX, startY, 80, 32, "Start", isHovered(startX, startY, 80, 32))) {
            if (empty) game.startNewGame(index);
            else       confirmSlot = index;   // ask before overwriting
        }
    }

    private void drawConfirmOverlay() {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0f, 0f, 0f, 0.7f);
        shapes.rect(0, 0, VW, VH);
        float pw = 360, ph = 140, px = VW / 2f - pw / 2f, py = VH / 2f - ph / 2f;
        shapes.setColor(0.14f, 0.10f, 0.10f, 1f);
        shapes.rect(px, py, pw, ph);
        shapes.end();

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, "Overwrite Slot " + (confirmSlot + 1) + "?", px + 24, py + ph - 24);
        font.draw(batch, "This cannot be undone.", px + 24, py + ph - 48);
        batch.end();

        float yesX = px + 30, btnY = py + 20;
        float noX  = px + pw - 130;
        if (drawButton(yesX, btnY, 100, 36, "Overwrite", isHovered(yesX, btnY, 100, 36))) {
            game.startNewGame(confirmSlot);
            confirmSlot = -1;
        }
        if (drawButton(noX, btnY, 100, 36, "Cancel", isHovered(noX, btnY, 100, 36))) {
            confirmSlot = -1;
        }
    }
}
