package com.hollowknight.view.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;

public abstract class BaseScreen implements Screen {

    protected final HollowKnight       game;
    protected final SpriteBatch        batch;
    protected final ShapeRenderer      shapes;
    protected final BitmapFont         font;
    protected final OrthographicCamera camera;
    protected final Viewport           viewport;
    private   final GlyphLayout        glyphLayout = new GlyphLayout();

    protected Screen previousScreen;
    protected Texture background;

    protected static final float VW = GameConfig.V_WIDTH;
    protected static final float VH = GameConfig.V_HEIGHT;

    protected BaseScreen(HollowKnight game) {
        this.game   = game;
        this.batch  = game.batch;
        this.shapes = game.shapes;
        this.font   = new BitmapFont();
        font.getData().setScale(1.2f);

        camera   = new OrthographicCamera();
        viewport = new FitViewport(VW, VH, camera);
        viewport.apply(true);
        camera.setToOrtho(false, VW, VH);
    }

    public void setPreviousScreen(Screen s) { previousScreen = s; }
    protected void loadBackground(String path) {
        background = loadTexture(path);
    }
    protected Texture loadTexture(String path) {
        try {
            Texture t = new Texture(path);
            t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return t;
        } catch (Exception e) {
            Gdx.app.error("BaseScreen", "notfound: " + path + " (" + e.getMessage() + ")");
            return null;
        }
    }

    protected void drawBackground() {
        drawImage(background, VW / 2f, VH / 2f, VW, VH);
    }

    protected void drawImage(Texture tex, float centerX, float centerY, float w, float h) {
        if (tex == null) return;
        batch.begin();
        batch.draw(tex, centerX - w / 2f, centerY - h / 2f, w, h);
        batch.end();
    }
    protected void clearScreen(float r, float g, float b) {
        Gdx.gl.glClearColor(r, g, b, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    }
    protected boolean drawButton(float x, float y, float w, float h, String label, boolean hovered) {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(hovered ? new Color(0.35f, 0.35f, 0.60f, 1f) : new Color(0.18f, 0.18f, 0.32f, 1f));
        shapes.rect(x, y, w, h);
        shapes.setColor(hovered ? new Color(0.75f, 0.75f, 1.0f, 1f) : new Color(0.45f, 0.45f, 0.70f, 1f));
        shapes.rect(x, y, w, 2);
        shapes.rect(x, y + h - 2, w, 2);
        shapes.rect(x, y, 2, h);
        shapes.rect(x + w - 2, y, 2, h);
        shapes.end();

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, label, x + 14, y + h / 2f + 6);
        batch.end();

        if (!hovered) return false;
        return Gdx.input.isButtonJustPressed(Input.Buttons.LEFT);
    }
    protected boolean drawMenuText(String label, float centerX, float y, float scale) {
        font.getData().setScale(scale);
        glyphLayout.setText(font, label);
        float textW = glyphLayout.width;
        float textH = glyphLayout.height;
        float x = centerX - textW / 2f;

        boolean hovered = isHovered(x - 30, y - textH - 8, textW + 60, textH + 16);

        batch.begin();
        font.setColor(hovered ? new Color(1f, 0.95f, 0.75f, 1f) : Color.WHITE);
        font.draw(batch, label, x, y);
        if (hovered) {
            font.draw(batch, "«", x - 26, y);
            font.draw(batch, "»", x + textW + 12, y);
        }
        batch.end();

        font.getData().setScale(1.2f);
        return hovered && Gdx.input.isButtonJustPressed(Input.Buttons.LEFT);
    }

    protected boolean isHovered(float bx, float by, float bw, float bh) {
        float mx = Gdx.input.getX();
        float my = Gdx.graphics.getHeight() - Gdx.input.getY();
        float scaleX = VW / (float) Gdx.graphics.getWidth();
        float scaleY = VH / (float) Gdx.graphics.getHeight();
        float vx = mx * scaleX;
        float vy = my * scaleY;
        return vx >= bx && vx <= bx + bw && vy >= by && vy <= by + bh;
    }

    protected void drawTitle(String title) {
        batch.begin();
        font.getData().setScale(2.0f);
        font.setColor(Color.WHITE);
        font.draw(batch, title, VW / 2f - title.length() * 8f, VH - 30f);
        font.getData().setScale(1.2f);
        batch.end();
    }

    protected void drawSubtitle(String text, float x, float y) {
        batch.begin();
        font.setColor(new Color(0.7f, 0.7f, 0.9f, 1f));
        font.draw(batch, text, x, y);
        batch.end();
    }

    @Override public void show()   { viewport.apply(true); }
    @Override public void hide()   {}
    @Override public void pause()  {}
    @Override public void resume() {}

    @Override
    public void resize(int w, int h) {
        viewport.update(w, h, true);
        camera.setToOrtho(false, VW, VH);
    }

    @Override
    public void dispose() {
        font.dispose();
        if (background != null) background.dispose();
    }
}
