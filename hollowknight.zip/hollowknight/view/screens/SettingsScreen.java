package com.hollowknight.view.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.Lang;
import com.hollowknight.controller.AudioManager;
import com.hollowknight.controller.InputHandler;

public class SettingsScreen extends BaseScreen {

    private boolean waitingForKey    = false;
    private InputHandler.Action rebindTarget;
    private String  statusMsg        = "";
    private int     statusTimer      = 0;

    private static final float SLIDER_W = 260f, SLIDER_H = 14f;
    private static final float LEFT_X   = VW / 2f - SLIDER_W / 2f;

    public SettingsScreen(HollowKnight game) { super(game); }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        drawTitle(Lang.translate("settings"));
        if (statusTimer > 0) { statusTimer--; }
        else statusMsg = "";

        float y = VH - 105;
        AudioManager am = game.audioManager;

        //music
        drawSubtitle(Lang.translate("Music Volume: ") + percents(am.musicVolume), LEFT_X, y + 20);
        drawSlider(LEFT_X, y, SLIDER_W, SLIDER_H, am.musicVolume);
        if (sliderDragged(LEFT_X, y, SLIDER_W, SLIDER_H)) {
            float v = (Gdx.input.getX() / (float) Gdx.graphics.getWidth()) * VW;
            am.setMusicVolume((v - LEFT_X) / SLIDER_W);
        }
        y -= 55;
        //toggle
        String mtxt = am.musicEnabled ? Lang.translate("Music: ON") : Lang.translate("Music: OFF");
        if (drawButton(LEFT_X, y, 180, 36, mtxt, isHovered(LEFT_X, y, 180, 36))) {
            am.toggleMusic();
        }
        y -= 55;

        //sfx
        drawSubtitle(Lang.translate("SFX Volume: ") + percents(am.sfxVolume), LEFT_X, y + 20);
        drawSlider(LEFT_X, y, SLIDER_W, SLIDER_H, am.sfxVolume);
        if (sliderDragged(LEFT_X, y, SLIDER_W, SLIDER_H)) {
            float v = (Gdx.input.getX() / (float) Gdx.graphics.getWidth()) * VW;
            am.setSfxVolume((v - LEFT_X) / SLIDER_W);
        }
        y -= 55;

        //toggle
        String stxt = am.sfxEnabled ? Lang.translate("SFX: ON") : Lang.translate("SFX: OFF");
        if (drawButton(LEFT_X, y, 180, 36, stxt, isHovered(LEFT_X, y, 180, 36))) {
            am.toggleSfx();
        }
        y -= 55;
        //language
        if (drawButton(LEFT_X + 200, y + 55, 220, 36, Lang.translate("language"),
            isHovered(LEFT_X + 200, y + 55, 220, 36))) {
            Lang.toggle();
        }
        /// ///
        drawSubtitle(Lang.translate("Key Rebinding (click then press a key):"), LEFT_X, y + 20);
        InputHandler ih = new InputHandler(); // display only
        InputHandler.Action[] actions = {
            InputHandler.Action.JUMP, InputHandler.Action.DASH,
            InputHandler.Action.ATTACK, InputHandler.Action.FOCUS
        };
        float rbx = LEFT_X;
        for (InputHandler.Action a : actions) {
            String lbl = a.name() + ": " + Input.Keys.toString(
                    new InputHandler().getBinding(a));
            float rby = y - 40;
            boolean hov = isHovered(rbx, rby, 200, 30);
            if (drawButton(rbx, rby, 200, 30, lbl, hov)) {
                rebindTarget = a;
                waitingForKey = true;
                statusMsg  = Lang.translate("Press any key for ") + a.name();
                statusTimer = 180;
            }
            rbx += 215;
            if (rbx > VW - 220) { rbx = LEFT_X; y -= 40; }
        }

        if (waitingForKey) {
            for (int k = 0; k < 256; k++) {
                if (Gdx.input.isKeyJustPressed(k)) {
                    new InputHandler().rebind(rebindTarget, k);
                    waitingForKey = false;
                    statusMsg  = Lang.translate("Rebound ") + rebindTarget.name() + Lang.translate(" to ") + Input.Keys.toString(k);
                    statusTimer = 120;
                    break;
                }
            }
        }

        //reset controls button
        float rx = LEFT_X, ry = 80;
        if (drawButton(rx, ry, 200, 36, Lang.translate("Reset Controls"), isHovered(rx, ry, 200, 36))) {
            new InputHandler().resetBindings();
            statusMsg = Lang.translate("Controls reset."); statusTimer = 90;
        }

        //message
        if (!statusMsg.isEmpty()) {
            batch.begin();
            font.setColor(Color.YELLOW);
            font.draw(batch, statusMsg, LEFT_X, 60);
            batch.end();
        }

        //save and Back
        float bx = VW - 200, by = 30;
        if (drawButton(bx, by, 160, 36, Lang.translate("Save & Back"), isHovered(bx, by, 160, 36))) {
            game.audioManager.saveSettings();
            if (previousScreen != null) game.setScreen(previousScreen);
            else game.navigateTo(com.hollowknight.config.GameConfig.STATE_MAIN_MENU);
        }
    }

    private void drawSlider(float x, float y, float w, float h, float value) {
        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.20f, 0.20f, 0.35f, 1f);
        shapes.rect(x, y, w, h);
        shapes.setColor(0.55f, 0.55f, 0.90f, 1f);
        shapes.rect(x, y, w * value, h);
        // Handle
        float hx = x + w * value - 6;
        shapes.setColor(1f, 1f, 1f, 1f);
        shapes.rect(hx, y - 3, 12, h + 6);
        shapes.end();
    }

    private boolean sliderDragged(float x, float y, float w, float h) {
        if (!Gdx.input.isTouched()) return false;
        float mx = Gdx.input.getX() / (float) Gdx.graphics.getWidth() * VW;
        float my = (Gdx.graphics.getHeight() - Gdx.input.getY()) / (float) Gdx.graphics.getHeight() * VH;
        return mx >= x && mx <= x + w && my >= y - 10 && my <= y + h + 10;
    }

    private String percents(float v) { return (int)(v * 100) + "%"; }
}
