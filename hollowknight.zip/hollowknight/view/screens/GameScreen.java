package com.hollowknight.view.screens;

import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.controller.AudioManager;
import com.hollowknight.controller.CheatManager;
import com.hollowknight.controller.GameController;
import com.hollowknight.controller.InputHandler;
import com.hollowknight.model.GameState;
import com.hollowknight.model.player.Player;
import com.hollowknight.model.world.Level;
import com.hollowknight.view.GameRenderer;
import com.hollowknight.model.player.PlayerState;

public class GameScreen extends BaseScreen
        implements GameController.GameEventListener {

    private GameRenderer   renderer;
    private GameController controller;
    private InputHandler   input;
    private CheatManager   cheat;

    public GameScreen(HollowKnight game) { super(game); }

    public void newGame() {
        init(null);
    }
    public void loadSlot(int slot) {
        var sd = game.saveManager.load(slot);
        init(sd);
        game.gameState.activeSaveSlot = slot;
    }

    private void init(com.hollowknight.model.system.SaveManager.SaveData sd) {
        Level level  = new Level();
        Player player;
        if (sd != null) {
            player = new Player(sd.playerX, sd.playerY);
            player.masks    = sd.masks;
            player.maxMasks = sd.maxMasks;
            player.soul     = sd.soul;
            player.deaths   = sd.deaths;
            player.enemiesKilled = sd.enemiesKilled;
            level.switchRoom(sd.currentRoomId, sd.playerX, sd.playerY);
        } else {
            var startRoom = level.currentRoom;
            player = new Player(startRoom.spawnX, startRoom.spawnY);
        }

        game.gameState.init(player, level);
        if (sd != null && sd.achievements != null) game.gameState.getAchievements().fromArray(sd.achievements);

        input= new InputHandler();
        cheat= new CheatManager(game.audioManager);
        controller = new GameController(game.gameState, input, game.audioManager, cheat);
        controller.setListener(this);
        if (renderer != null) renderer.dispose();
        renderer = new GameRenderer(game.batch, game.shapes);
        renderer.resize(com.badlogic.gdx.Gdx.graphics.getWidth(),
            com.badlogic.gdx.Gdx.graphics.getHeight());
        renderer.camera.position.set(player.x + player.W / 2f, player.y + player.H / 2f, 0);
        renderer.camera.update();
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.DEAD,
            "sprites/player/death", "Death_", 21, 3, "png", 0.09f, false);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.RUNNING,
            "sprites/player/walk", "Walk_", 3,
            3, "png", 0.07f, true);
        /// ///////
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.IDLE,
            "sprites/player/idle", "Idle_",
            9,
            3, "png", 0.07f, true);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.DASHING,
            "sprites/player/dash", "Dash_", 12,
            3, "png", 0.05f, false);

        renderer.getAnimManager().loadFrameSequence(
            PlayerState.JUMPING,
            "sprites/player/airborne", "Airborne_",
             7,
            3, "png", 0.10f, false);

        renderer.getAnimManager().loadFrameSequence(
            PlayerState.DOUBLE_JUMPING,
            "sprites/player/doublejump", "DJump_",
             8,
            3, "png", 0.09f, false);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.FALLING,
            "sprites/player/fall", "Fall_",
             6,
            3, "png", 0.07f, true);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.HURT,
            "sprites/player/idlehurt", "Idle Hurt_",
            11,
            3, "png", 0.12f, true);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.CASTING,
            "sprites/player/cast", "Cast_",
            1,
            3, "png", 0.07f, false );
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.WALL_SLIDING,
            "sprites/player/wallslide", "WallSlide_",
            4,
            3, "png", 0.10f, true);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.ATTACKING_H,
            "sprites/player/slash", "Slash_",
            5,
            3, "png", 0.05f, false);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.ATTACKING_UP,
            "sprites/player/upslash", "UpSlash_",
            5,
            3, "png", 0.05f, false);
        renderer.getAnimManager().loadFrameSequence(
            PlayerState.ATTACKING_DOWN,
            "sprites/player/downslash", "DownSlash_",
            5,
            3, "png", 0.05f, false);
        renderer.GameController_ref = controller;
        //BGM
        game.audioManager.playBgmForRoom(level.currentRoom);
    }


    private boolean pendingRestart = false;

    @Override
    public void onPlayerDead() {
        pendingRestart = true;
    }

    @Override
    public void render(float delta) {
        if (pendingRestart) {
            pendingRestart = false;
            newGame();
            return;
        }
        if (renderer == null || controller == null) return;
        controller.update();
        renderer.render(game.gameState, delta);
    }

    @Override
    public void resize(int w, int h) {
        super.resize(w, h);
        if (renderer != null) renderer.resize(w, h);
    }

    @Override
    public void dispose() {
        super.dispose();
        if (renderer != null) renderer.dispose();
    }

    @Override
    public void onBossDefeated() {
        renderer.triggerShake(0.9f);
        game.gameState.getAchievements().unlock("completion");
    }

    @Override
    public void onRoomTransition(String roomId, float tx, float ty) {
        if ("the_end".equals(roomId)) {
            var fk = game.gameState.getLevel().falseKnight;
            if (fk == null || !fk.alive)
                game.navigateTo(GameConfig.STATE_THE_END);
            return;
        }
        controller.enterRoom(roomId, tx, ty);
        renderer.triggerShake(0.2f);
        //reset camera
        var room = game.gameState.getLevel().currentRoom;
        renderer.camera.position.x = tx + 12;
        renderer.camera.position.y = ty + 18;
        renderer.camera.update();
        game.audioManager.playBgmForRoom(room);
    }

    @Override
    public void onPauseRequested() {
        game.gameState.onPause();
        game.navigateTo(GameConfig.STATE_PAUSED);
    }

    @Override
    public void onInventoryRequested() {
        game.navigateTo(GameConfig.STATE_INVENTORY);
    }

    @Override
    public void onCheatActivated(String msg) {
        renderer.getHud().setCheatMessage(msg);
    }
}
