package com.hollowknight.view.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.config.Lang;
import com.hollowknight.model.system.AchievementSystem;

class MainMenuScreen extends BaseScreen {

    private static final float CENTER_GAP = 56;
    private static final float CENTER_Y0  = VH / 2f + CENTER_GAP;

    private String message      = "";
    private int    messageTimer = 0;

    public MainMenuScreen(HollowKnight game) {
        super(game);
        loadBackground("sprites/ui/Menu.png");
    }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        drawBackground();

        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        //left
        String loginLabel = game.loggedInUsername != null
            ? "Logout (" + game.loggedInUsername + ")": Lang.translate("Login / Signup");
        if (drawMenuText(loginLabel, 120, VH - 50, 1.0f)) {
            if (game.loggedInUsername != null) {
                game.loggedInUsername = null;
                showMessage(Lang.translate("Logged out."));
            } else {
                game.navigateTo(GameConfig.STATE_LOGIN);
            }
        }
        //right
        if (drawMenuText(Lang.translate("Settings"), VW - 90, VH - 50, 1.0f)) {
            game.navigateTo(GameConfig.STATE_SETTINGS);
        }

        //Continue/New Game/Load
        String[] centerLabels = { Lang.translate("Continue"), Lang.translate("New Game"), Lang.translate("Load"),Lang.translate("Achievements") };  // ✅ هر فریم
        for (int i = 0; i < centerLabels.length; i++) {
            float y = CENTER_Y0 - i * CENTER_GAP;
            if (drawMenuText(centerLabels[i], VW / 2f, y, 1.4f)) {
                handleCenter(i);
            }
        }

        //exit
        if (drawMenuText(Lang.translate("Exit"), 60, 40, 1.0f)) {
            com.badlogic.gdx.Gdx.app.exit();
        }

        //message
        if (messageTimer > 0) {
            messageTimer--;
            batch.begin();
            font.getData().setScale(1.0f);
            font.setColor(Color.YELLOW);
            font.draw(batch, message, VW / 2f - 80, CENTER_Y0 - 3 * CENTER_GAP - 10);
            batch.end();
        }
    }

    private void handleCenter(int i) {
        switch (i) {
            case 0 -> { if (!game.continueGame()) showMessage("No saved game found."); }
            case 1 -> game.navigateTo(GameConfig.STATE_NEW_GAME_MENU);
            case 2 -> game.navigateTo(GameConfig.STATE_LOAD_MENU);
            case 3 -> game.navigateTo(GameConfig.STATE_ACHIEVEMENTS);
        }
    }

    private void showMessage(String msg) { message = msg; messageTimer = 150; }
}
class GuideScreen extends BaseScreen {

    public GuideScreen(HollowKnight game) { super(game); }

    private static final String[] CONTROLS = {
        "Move:       ← →",
        "Jump:       Z      (hold longer = higher jump)",
        "Dash:       C",
        "Attack:     X      (Up/Down held = directional)",
        "Focus/Heal: A      (stand still, costs soul)",
        "Spell V.S:  V      (Vengeful Spirit, 33 soul)",
        "Spell H.W.: S      (Howling Wraiths, 33 soul)",
        "Interact:   Up Arrow",
        "Inventory:  I",
        "Pause:      Escape"
    };
    private static final String[] ABILITIES = {
        "Double Jump  press Z again while airborne.",
        "Wall Claw    slide walls; jump off to wall-jump.",
        "Pogo         attack downward on enemies to bounce.",
        "Dash         brief horizontal burst; resets airborne DJ."
    };
    private static final String[] CHEATS = {
        "Ctrl+B  Teleport to Boss Arena",
        "Ctrl+N  Noclip Mode",
        "Ctrl+H  Emergency Heal",
        "Ctrl+R  Refill Soul",
        "Ctrl+G  God Mode",
        "Ctrl+K  Kill all enemies "
    };

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);
        drawTitle("Guide");

        float x1 = 40, x2 = VW / 2f + 20;
        float y  = VH - 100;

        batch.begin();
        font.getData().setScale(1.3f);
        font.setColor(Color.YELLOW);
        font.draw(batch, "Controls", x1, y);
        font.setColor(new Color(0.6f, 0.6f, 0.8f, 1f));
        y -= 24;
        font.getData().setScale(1.0f);
        for (String line : CONTROLS) { font.draw(batch, line, x1, y); y -= 20; }

        y = VH - 100;
        font.getData().setScale(1.3f);
        font.setColor(Color.YELLOW);
        font.draw(batch, "Abilities", x2, y);
        font.setColor(new Color(0.6f, 0.6f, 0.8f, 1f));
        y -= 24;
        font.getData().setScale(1.0f);
        for (String line : ABILITIES) { font.draw(batch, line, x2, y); y -= 22; }

        y -= 20;
        font.getData().setScale(1.3f);
        font.setColor(Color.YELLOW);
        font.draw(batch, "Cheat Codes", x2, y);
        font.setColor(new Color(0.6f, 0.7f, 0.4f, 1f));
        y -= 24;
        font.getData().setScale(1.0f);
        for (String line : CHEATS) { font.draw(batch, line, x2, y); y -= 20; }
        batch.end();

        float bx = VW / 2f - 60, by = 30;
        if (drawButton(bx, by, 120, 36, "Back", isHovered(bx, by, 120, 36)))
            game.setScreen(previousScreen != null ? previousScreen : game.getScreen());
    }
}
class AchievementsScreen extends BaseScreen {

    public AchievementsScreen(HollowKnight game) { super(game); }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);
        drawTitle("Achievements");

        var all = game.gameState.getAchievements().getAll();
        float cardW = 520, cardH = 52, gap = 10;
        float cardX = VW / 2f - cardW / 2f;
        float topY  = VH - 100;
//1
        float y = topY;
        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        for (AchievementSystem.Achievement a : all.values()) {
            boolean on = a.unlocked;
            shapes.setColor(on ? new Color(0.12f, 0.20f, 0.12f, 1f)
                : new Color(0.12f, 0.12f, 0.18f, 1f));
            shapes.rect(cardX, y - cardH, cardW, cardH);
            shapes.setColor(on ? new Color(0.85f, 0.75f, 0.15f, 1f)
                : new Color(0.30f, 0.30f, 0.35f, 1f));
            shapes.ellipse(cardX + 12, y - cardH / 2f - 13, 26, 26);
            y -= cardH + gap;
        }
        shapes.end();

//2
        y = topY;
        batch.begin();
        for (AchievementSystem.Achievement a : all.values()) {
            boolean on = a.unlocked;
            font.getData().setScale(1.1f);
            font.setColor(on ? Color.WHITE : new Color(0.4f, 0.4f, 0.5f, 1f));
            font.draw(batch, on ? a.name : "🔒", cardX + 52, y - 12);
            font.getData().setScale(0.9f);
            font.setColor(on ? new Color(0.7f, 0.7f, 0.8f, 1f)
                : new Color(0.3f, 0.3f, 0.4f, 1f));
            font.draw(batch, on ? a.description : "Locked", cardX + 52, y - 33);
            y -= cardH + gap;
        }
        font.getData().setScale(1.2f);
        batch.end();

        float bx = VW / 2f - 60, by = 30;
        if (drawButton(bx, by, 120, 36, "Back", isHovered(bx, by, 120, 36)))
            game.setScreen(previousScreen != null ? previousScreen : game.getScreen());
    }
}
class PauseScreen extends BaseScreen {

    private static final float BTN_W = 200, BTN_H = 38;
    private static final float BTN_X = VW / 2f - BTN_W / 2f;
    private static final float[] BTN_Y = {
        VH/2f + 70, VH/2f + 20, VH/2f - 30, VH/2f - 80
    };
    private static final String[] LABELS = {
        "Continue", 
        "Cheat Codes", 
        "Settings", 
        "Save & Quit"
    };

    public PauseScreen(HollowKnight game) { super(game); }

    @Override
    public void render(float delta) {
        shapes.setProjectionMatrix(camera.combined);
        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0f, 0f, 0f, 0.55f);
        shapes.rect(0, 0, VW, VH);
        shapes.end();

        batch.setProjectionMatrix(camera.combined);
        drawTitle("PAUSED");

        for (int i = 0; i < LABELS.length; i++) {
            boolean hov = isHovered(BTN_X, BTN_Y[i], BTN_W, BTN_H);
            if (drawButton(BTN_X, BTN_Y[i], BTN_W, BTN_H, LABELS[i], hov)) {
                handleButton(i);
            }
        }

        //cheat code references
        batch.begin();
        font.getData().setScale(0.85f);
        font.setColor(new Color(0.55f, 0.70f, 0.45f, 1f));
        font.draw(batch, "Cheats: Ctrl+B or N/H/R/G/K", BTN_X, BTN_Y[3] - 30);
        font.getData().setScale(1.2f);
        batch.end();
    }

    private void handleButton(int i) {
        switch (i) {
            case 0 -> {
                game.gameState.onResume();
                game.setScreen(previousScreen);
            }
            case 1 -> {}
            case 2 -> game.navigateTo(GameConfig.STATE_SETTINGS);
            case 3 -> {
                if (previousScreen instanceof GameScreen gs)
                    game.saveManager.save(game.gameState.activeSaveSlot, game.gameState);
                game.navigateTo(GameConfig.STATE_MAIN_MENU);
            }
        }
    }
}
class TheEndScreen extends BaseScreen {

    private int timer = 0;
    private final com.badlogic.gdx.graphics.Texture endImage;

    public TheEndScreen(HollowKnight game) {
        super(game);
        endImage = loadTexture("sprites/ui/the_end.png");
    }

    @Override
    public void render(float delta) {
        timer++;
        float fade = Math.min(1f, timer / 120f);//2second fade

        clearScreen(0f, 0f, 0f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        if (endImage != null) {
            batch.begin();
            batch.setColor(1f, 1f, 1f, fade);
            batch.draw(endImage, VW / 2f - 300, VH / 2f - 60, 600, 220);
            batch.setColor(Color.WHITE);
            batch.end();
        } else {
            batch.begin();
            font.getData().setScale(4.0f);
            font.setColor(new Color(0.95f, 0.90f, 0.75f, fade));
            font.draw(batch, "THE  END", VW / 2f - 140, VH / 2f + 90);
            batch.end();
        }

        var p = game.gameState.getPlayer();
        batch.begin();
        font.getData().setScale(1.2f);
        font.setColor(new Color(0.85f, 0.78f, 0.60f, fade));
        font.draw(batch, "False Knight has fallen. Hallownest is at peace.",
            VW / 2f - 210, VH / 2f + 10);
        font.setColor(new Color(1f, 1f, 1f, fade));
        if (p != null)
            font.draw(batch, "Enemies slain: " + p.enemiesKilled,
                VW / 2f - 90, VH / 2f - 30);
        font.draw(batch, "Play time:     " + fmt(game.gameState.getElapsedSeconds()),
            VW / 2f - 90, VH / 2f - 56);
        batch.end();
        if (timer > 180) {
            float bx = VW / 2f - 190, by = 50;
            if (drawButton(bx, by, 180, 38, "Main Menu",
                isHovered(bx, by, 180, 38))
                || Gdx.input.isKeyJustPressed(Input.Keys.ENTER))
                game.navigateTo(GameConfig.STATE_MAIN_MENU);
            if (drawButton(bx + 200, by, 180, 38, "Exit",
                isHovered(bx + 200, by, 180, 38)))
                Gdx.app.exit();
        }
    }

    private String fmt(long s) {
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
class GameOverScreen extends BaseScreen {

    private final int  deaths;
    private final int  kills;
    private final long playSecs;
    private int        timer = 0;

    public GameOverScreen(HollowKnight game, int deaths, int kills, long playSecs) {
        super(game);
        this.deaths   = deaths;
        this.kills    = kills;
        this.playSecs = playSecs;
    }

    @Override
    public void render(float delta) {
        timer++;
        float fade = Math.min(1f, timer / 90f);

        clearScreen(0f, 0f, 0f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        batch.begin();
        ///"YOU DIED" text
        font.getData().setScale(3.5f);
        font.setColor(new Color(0.75f, 0.15f, 0.15f, fade));
        font.draw(batch, "YOU DIED", VW / 2f - 100, VH / 2f + 60);
        font.getData().setScale(1.2f);
        font.setColor(new Color(1f, 1f, 1f, fade));
        font.draw(batch, "Deaths:       " + deaths,  VW/2f - 80, VH/2f - 10);
        font.draw(batch, "Enemies slain: " + kills,  VW/2f - 80, VH/2f - 36);
        font.draw(batch, "Play time:    " + fmt(playSecs), VW/2f - 80, VH/2f - 62);
        batch.end();

        if (timer > 150) {
            float bx = VW/2f - 90, by = 60;
            if (drawButton(bx, by, 180, 38, "Respawn",  isHovered(bx, by, 180, 38)))
                game.navigateTo(GameConfig.STATE_PLAYING);
            if (drawButton(bx + 200, by, 180, 38, "Main Menu",
                    isHovered(bx + 200, by, 180, 38)))
                game.navigateTo(GameConfig.STATE_MAIN_MENU);
        }
    }

    private String fmt(long s) {
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
public final class ScreenFactory {
    private ScreenFactory() {}
    public static com.badlogic.gdx.Screen mainMenu    (HollowKnight g) { return new MainMenuScreen(g); }
    public static com.badlogic.gdx.Screen theEnd      (HollowKnight g) { return new TheEndScreen(g); }
    public static com.badlogic.gdx.Screen guide       (HollowKnight g) { return new GuideScreen(g); }
    public static com.badlogic.gdx.Screen achievements(HollowKnight g) { return new AchievementsScreen(g); }

    public static com.badlogic.gdx.Screen pauseScreen(HollowKnight g,
            com.badlogic.gdx.Screen back) {
        PauseScreen ps = new PauseScreen(g);
        ps.setPreviousScreen(back);
        return ps;
    }

    public static com.badlogic.gdx.Screen gameOver(HollowKnight g,
            int deaths, int kills, long secs) {
        return new GameOverScreen(g, deaths, kills, secs);
    }
    public static void setBack(com.badlogic.gdx.Screen screen,com.badlogic.gdx.Screen back) {
        if (screen instanceof BaseScreen bs) bs.setPreviousScreen(back);
    }
    public static void setPauseBack(com.badlogic.gdx.Screen screen,com.badlogic.gdx.Screen back) {
        if (screen instanceof BaseScreen bs) bs.setPreviousScreen(back);
    }
}
