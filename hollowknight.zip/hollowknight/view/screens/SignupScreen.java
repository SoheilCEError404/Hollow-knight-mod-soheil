package com.hollowknight.view.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.view.ui.TextField;

public class SignupScreen extends BaseScreen {

    private final TextField nameField  = new TextField(VW / 2f - 160, VH / 2f + 74, 320, 36, "name", false);
    private final TextField emailField = new TextField(VW / 2f - 160, VH / 2f + 26, 320, 36, "email", false);
    private final TextField passField  = new TextField(VW / 2f - 160, VH / 2f - 22, 320, 36, "password", true);
    private final TextField[] fields = { nameField, emailField, passField };

    private String statusMsg   = "";
    private Color  statusColor = Color.YELLOW;
    private int    statusTimer = 0;

    public SignupScreen(HollowKnight game) { super(game); }

    @Override
    public void show() {
        super.show();
        for (TextField f : fields) f.clear();
        for (TextField f : fields) f.focused = false;
        nameField.focused = true;
        statusTimer = 0;

        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override public boolean keyTyped(char c) {
                for (TextField f : fields) if (f.focused) { f.typeChar(c); break; }
                return true;
            }
            @Override public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.TAB)   cycleFocus();
                if (keycode == Input.Keys.ENTER) attemptSignup();
                return true;
            }
        });
    }

    @Override
    public void hide() {
        super.hide();
        Gdx.input.setInputProcessor(null);
    }

    private void cycleFocus() {
        int idx = 0;
        for (int i = 0; i < fields.length; i++) if (fields[i].focused) idx = i;
        for (TextField f : fields) f.focused = false;
        fields[(idx + 1) % fields.length].focused = true;
    }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);
        drawTitle("Signup");

        handleFocusClick();

        for (TextField f : fields) f.draw(shapes, batch, font);

        float backX = VW / 2f - 160, btnY = VH / 2f - 78;
        float subX  = VW / 2f + 60;
        if (drawButton(backX, btnY, 100, 36, "Back", isHovered(backX, btnY, 100, 36))) {
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        }
        if (drawButton(subX, btnY, 100, 36, "Submit", isHovered(subX, btnY, 100, 36))) {
            attemptSignup();
        }

        // Link to Login
        float loginX = VW / 2f - 80, loginY = VH / 2f - 124;
        drawSubtitle("Already have an account?", loginX - 70, loginY + 34);
        if (drawButton(loginX, loginY, 160, 30, "Log In", isHovered(loginX, loginY, 160, 30))) {
            game.navigateTo(GameConfig.STATE_LOGIN);
        }

        if (statusTimer > 0) {
            statusTimer--;
            batch.begin();
            font.setColor(statusColor);
            font.draw(batch, statusMsg, VW / 2f - 160, VH / 2f + 136);
            batch.end();
        }
    }

    private void handleFocusClick() {
        if (!Gdx.input.justTouched()) return;
        float mx = Gdx.input.getX() / (float) Gdx.graphics.getWidth() * VW;
        float my = (Gdx.graphics.getHeight() - Gdx.input.getY())
                / (float) Gdx.graphics.getHeight() * VH;
        for (TextField f : fields) f.focused = f.hitTest(mx, my);
    }

    private void attemptSignup() {
        String name  = nameField.getValue().trim();
        String email = emailField.getValue().trim();
        String pass  = passField.getValue();

        if (name.isEmpty() || pass.isEmpty()) {
            setStatus("Name and password are required.", Color.RED);
            return;
        }
        if (game.accountManager.usernameExists(name)) {
            setStatus("Username already taken.", Color.RED);
            return;
        }
        if (game.accountManager.signUp(name, email, pass)) {
            game.loggedInUsername = name;
            setStatus("Account created!", Color.GREEN);
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        } else {
            setStatus("Could not create account.", Color.RED);
        }
    }

    private void setStatus(String msg, Color c) { statusMsg = msg; statusColor = c; statusTimer = 150; }
}
