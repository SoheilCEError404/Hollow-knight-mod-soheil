package com.hollowknight.view.screens;

import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.item.CharmType;
import com.hollowknight.model.player.Player;

public class InventoryScreen extends BaseScreen {

    private CharmType selected     = null;
    private String    infoText     = "";

    private static final float CARD_W = 180f, CARD_H = 68f, CARD_PAD = 12f;
    private static final float ORIGIN_X = 30f, ORIGIN_Y_TOP = VH - 110f;
    private static final int   COLS     = 4;
    private final java.util.EnumMap<CharmType, com.badlogic.gdx.graphics.Texture>
        charmIcons = new java.util.EnumMap<>(CharmType.class);

    public InventoryScreen(HollowKnight game) {
        super(game);
        for (CharmType c : CharmType.values()) {
            try {
                var t = new com.badlogic.gdx.graphics.Texture("sprites/ui/charms/" + c.name().toLowerCase() + ".png");
                t.setFilter(com.badlogic.gdx.graphics.Texture.TextureFilter.Linear,
                    com.badlogic.gdx.graphics.Texture.TextureFilter.Linear);
                charmIcons.put(c, t);
            } catch (Exception e) {
                com.badlogic.gdx.Gdx.app.log("Inventory", "no icon: " + c.name());
            }
        }
    }

    @Override
    public void render(float delta) {
        clearScreen(0.05f, 0.05f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);
        drawTitle("Inventory ------------ Charms");

        Player p = game.gameState.getPlayer();
        if (p == null) { drawSubtitle("No game in progress.", 40, VH / 2f); return; }

        // Notch bar
        drawNotchBar(p);

        // Charm grid
        CharmType[] all = p.discoveredCharms.toArray(new CharmType[0]);
        for (int i = 0; i < all.length; i++) {
            int col = i % COLS;
            int row = i / COLS;
            float cx = ORIGIN_X + col * (CARD_W + CARD_PAD);
            float cy = ORIGIN_Y_TOP - row * (CARD_H + CARD_PAD);
            drawCharmCard(p, all[i], cx, cy);
        }

        // Info panel
        if (selected != null) drawInfoPanel(selected, p);

        // Back button
        float bx = VW - 160, by = 30;
        if (drawButton(bx, by, 130, 36, "Close", isHovered(bx, by, 130, 36))) {
            if (previousScreen != null) game.setScreen(previousScreen);
        }
    }

    private void drawNotchBar(Player p) {
        float bx = VW - 200, by = VH - 80;
        batch.begin();
        font.setColor(Color.YELLOW);
        font.draw(batch, "Notches: " + p.notchesUsed + " / " + GameConfig.TOTAL_NOTCHES, bx, by);
        batch.end();
        // Notch circles
        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        for (int i = 0; i < GameConfig.TOTAL_NOTCHES; i++) {
            boolean used = i < p.notchesUsed;
            shapes.setColor(used ? new Color(0.85f, 0.75f, 0.20f, 1f) : new Color(0.25f, 0.25f, 0.35f, 1f));
            shapes.ellipse(bx + i * 28f, by - 26, 22, 22);}
        shapes.end();
    }

    private void drawCharmCard(Player p, CharmType charm, float cx, float cy) {
        boolean equipped = p.equippedCharms.contains(charm);
        boolean select  = charm == selected;
        boolean hovered = isHovered(cx, cy, CARD_W, CARD_H);

        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        if  (select)      shapes.setColor(0.25f, 0.22f, 0.45f, 1f);
        else if (equipped) shapes.setColor(0.14f, 0.22f, 0.14f, 1f);
        else if (hovered)      shapes.setColor(0.18f, 0.18f, 0.30f, 1f);
        else shapes.setColor(0.10f, 0.10f, 0.18f, 1f);
        shapes.rect(cx, cy, CARD_W, CARD_H);

        // Charm icon circle
        Color iconCol = equipped
                ? new Color(0.85f, 0.75f, 0.20f, 1f) : new Color(0.40f, 0.40f, 0.55f, 1f);
        if (charmIcons.get(charm) == null) {
            shapes.setColor(iconCol);
            shapes.ellipse(cx + 8, cy + CARD_H / 2f - 16, 32, 32);
        }
        // Notch cost pips
        for (int n = 0; n < charm.notchCost; n++) {
            shapes.setColor(0.75f, 0.65f, 0.15f, 1f);
            shapes.ellipse(cx + CARD_W - 20 - n * 14, cy + 6, 10, 10);
        }
        shapes.end();

        // Text
        batch.begin();
        var icon = charmIcons.get(charm);
        if (icon != null) {
            if (!equipped) batch.setColor(0.55f, 0.55f, 0.65f, 1f); // خاموش = کم‌نور
            batch.draw(icon, cx + 8, cy + CARD_H / 2f - 16, 32, 32);
            batch.setColor(Color.WHITE);
        }
        font.getData().setScale(0.9f);
        font.setColor(equipped ? Color.GREEN : Color.WHITE);
        font.draw(batch, charm.name,    cx + 48, cy + CARD_H - 10);
        font.getData().setScale(0.75f);
        font.setColor(new Color(0.6f, 0.6f, 0.8f, 1f));
        font.draw(batch, "Cost: " + charm.notchCost, cx + 48, cy + CARD_H - 30);
        font.getData().setScale(1.0f);
        batch.end();
        //select
        if (hovered && com.badlogic.gdx.Gdx.input.isButtonJustPressed(
                com.badlogic.gdx.Input.Buttons.LEFT)) {
            if (selected == charm) {
                toggleCharm(p, charm);
                selected = null;}
            else {
                selected  = charm;
                infoText  = charm.description;}
        }
    }

    private void toggleCharm(Player player, CharmType charm) {
        if (player.equippedCharms.contains(charm)) player.unequipCharm(charm);
        else  player.equipCharm(charm);
    }

    private void drawInfoPanel(CharmType charm, Player p) {
        float px = 30, py = 80, pw = VW * 0.55f, ph = 60;
        shapes.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.08f, 0.08f, 0.14f, 0.95f);
        shapes.rect(px, py, pw, ph);
        shapes.end();

        boolean equipped = p.equippedCharms.contains(charm);
        batch.begin();
        font.getData().setScale(0.9f);
        font.setColor(Color.WHITE);
        font.draw(batch, charm.description, px + 10, py + ph - 10);
        font.setColor(equipped ? Color.GREEN : Color.YELLOW);
        font.draw(batch,
                equipped ? "Equipped  (click again to unequip)" : "Click again to equip",
                px + 10, py + ph - 32);
        font.getData().setScale(1.0f);
        batch.end();
    }
}
