package com.hollowknight.view.screens;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.system.SaveManager;

public class LoadMenuScreen extends BaseScreen {

    private SaveManager.SaveData[] slots;

    private static final float ROW_W = VW - 80, ROW_H = 56, ROW_PAD = 14;
    private static final float ROW_X = 40;
    private static final float ROW_Y_TOP = VH - 140;

    public LoadMenuScreen(HollowKnight game) { super(game); }

    @Override
    public void show() {
        super.show();
        slots = game.saveManager.loadAllSlots();
    }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);

        // Back button — top-left, matches wireframe
        float bx = 24, by = VH - 70;
        if (drawButton(bx, by, 100, 34, "Back", isHovered(bx, by, 100, 34))) {
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        }

        drawTitle("Load Menu");

        for (int i = 0; i < slots.length; i++) {
            float ry = ROW_Y_TOP - i * (ROW_H + ROW_PAD);
            drawRow(i, ry);
        }
    }

    private void drawRow(int index, float y) {
        SaveManager.SaveData sd = slots[index];
        boolean empty = sd == null;

        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(empty ? new Color(0.12f, 0.12f, 0.18f, 1f)
                              : new Color(0.20f, 0.26f, 0.45f, 1f));
        shapes.rect(ROW_X, y, ROW_W, ROW_H);
        shapes.setColor(new Color(0.55f, 0.65f, 0.85f, 1f));
        shapes.rect(ROW_X, y, ROW_W, 2);
        shapes.rect(ROW_X, y + ROW_H - 2, ROW_W, 2);
        shapes.end();

        String label = empty
                ? "Slot " + (index + 1) + "  —  Empty" : "Slot " + (index + 1) + "   " + sd.completionPercent + "%" + "   Deaths: " + sd.deaths + "   " + formatTime(sd.playtimeSeconds);

        batch.begin();
        font.setColor(empty ? new Color(0.45f, 0.45f, 0.55f, 1f) : Color.WHITE);
        font.draw(batch, label, ROW_X + 16, y + ROW_H / 2f + 6);
        batch.end();

        float loadBtnX = ROW_X + ROW_W - 100, loadBtnY = y + ROW_H / 2f - 16;
        if (!empty) {
            if (drawButton(loadBtnX, loadBtnY, 80, 32, "Load", isHovered(loadBtnX, loadBtnY, 80, 32))) {
                game.loadGame(index);}
        }
        else {
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            shapes.setColor(new Color(0.18f, 0.18f, 0.22f, 1f));
            shapes.rect(loadBtnX, loadBtnY, 80, 32);
            shapes.end();
            batch.begin();
            font.setColor(new Color(0.4f, 0.4f, 0.45f, 1f));
            font.draw(batch, "Load", loadBtnX + 22, loadBtnY + 22);
            batch.end();
        }
    }

    private String formatTime(long secs) {
        return String.format("%d:%02d", secs / 60, secs % 60);
    }
}
