package com.hollowknight.view.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Color;
import com.hollowknight.HollowKnight;
import com.hollowknight.config.GameConfig;
import com.hollowknight.view.ui.TextField;

public class LoginScreen extends BaseScreen {

    private final TextField usernameField = new TextField(VW / 2f - 160, VH / 2f + 30, 320, 36, "username", false);
    private final TextField passwordField = new TextField(VW / 2f - 160, VH / 2f - 18, 320, 36, "password", true);
    private final TextField[] fields = { usernameField, passwordField };

    private String statusMsg   = "";
    private Color  statusColor = Color.YELLOW;
    private int    statusTimer = 0;

    public LoginScreen(HollowKnight game) { super(game); }

    @Override
    public void show() {
        super.show();
        usernameField.clear();
        passwordField.clear();
        usernameField.focused = true;
        passwordField.focused = false;
        statusTimer = 0;

        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override public boolean keyTyped(char c) {
                for (TextField f : fields) if (f.focused) { f.typeChar(c); break; }
                return true;
            }
            @Override public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.TAB)   cycleFocus();
                if (keycode == Input.Keys.ENTER) attemptLogin();
                return true;
            }
        });
    }

    @Override
    public void hide() {
        super.hide();
        Gdx.input.setInputProcessor(null);
    }

    private void cycleFocus() {
        int idx = usernameField.focused ? 0 : 1;
        for (TextField f : fields) f.focused = false;
        fields[(idx + 1) % fields.length].focused = true;
    }

    @Override
    public void render(float delta) {
        clearScreen(0.04f, 0.04f, 0.10f);
        batch.setProjectionMatrix(camera.combined);
        shapes.setProjectionMatrix(camera.combined);
        drawTitle("Login");

        handleFocusClick();

        for (TextField f : fields) f.draw(shapes, batch, font);

        float backX = VW / 2f - 160, btnY = VH / 2f - 70;
        float subX  = VW / 2f + 60;
        if (drawButton(backX, btnY, 100, 36, "Back", isHovered(backX, btnY, 100, 36))) {
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        }
        if (drawButton(subX, btnY, 100, 36, "Submit", isHovered(subX, btnY, 100, 36))) {
            attemptLogin();
        }

        // Link to Signup
        float signX = VW / 2f - 80, signY = VH / 2f - 116;
        drawSubtitle("No account yet?", signX - 10, signY + 34);
        if (drawButton(signX, signY, 160, 30, "Create Account", isHovered(signX, signY, 160, 30))) {
            game.navigateTo(GameConfig.STATE_SIGNUP);
        }

        if (statusTimer > 0) {
            statusTimer--;
            batch.begin();
            font.setColor(statusColor);
            font.draw(batch, statusMsg, VW / 2f - 160, VH / 2f + 92);
            batch.end();
        }
    }

    private void handleFocusClick() {
        if (!Gdx.input.justTouched()) return;
        float mx = Gdx.input.getX() / (float) Gdx.graphics.getWidth() * VW;
        float my = (Gdx.graphics.getHeight() - Gdx.input.getY())
                / (float) Gdx.graphics.getHeight() * VH;
        for (TextField f : fields) f.focused = f.hitTest(mx, my);
    }

    private void attemptLogin() {
        String u = usernameField.getValue().trim();
        String p = passwordField.getValue();
        if (u.isEmpty() || p.isEmpty()) { setStatus("Enter both fields.", Color.RED); return; }

        if (game.accountManager.login(u, p)) {
            game.loggedInUsername = u;
            setStatus("Welcome back, " + u + "!", Color.GREEN);
            game.navigateTo(GameConfig.STATE_MAIN_MENU);
        } else {
            setStatus("Invalid username or password.", Color.RED);
        }
    }

    private void setStatus(String msg, Color c) { statusMsg = msg; statusColor = c; statusTimer = 150; }
}
