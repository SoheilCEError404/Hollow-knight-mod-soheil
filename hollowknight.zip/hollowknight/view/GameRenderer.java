package com.hollowknight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.GameState;
import com.hollowknight.model.enemy.Enemy;
import com.hollowknight.model.enemy.boss.FalseKnight;
import com.hollowknight.model.enemy.fixed.CrystalGuardian;
import com.hollowknight.model.enemy.ground.GroundEnemy;
import com.hollowknight.model.player.Player;
import com.hollowknight.model.player.PlayerState;
import com.hollowknight.model.spell.HowlingWraithsEffect;
import com.hollowknight.model.spell.Projectile;
import com.hollowknight.model.world.Hazard;
import com.hollowknight.model.world.Platform;
import com.hollowknight.model.world.Room;
import com.hollowknight.view.animation.AnimationManager;
import com.hollowknight.view.animation.EnemyAnimator;
import com.hollowknight.view.effects.ScreenShake;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.hollowknight.model.enemy.fixed.HuskHornhead;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.hollowknight.model.enemy.boss.Shockwave;
public class GameRenderer {

    //LibGDX
    private final SpriteBatch    batch;
    private final ShapeRenderer  shapes;
    private final BitmapFont     font;
    public  final OrthographicCamera camera;
    public  final Viewport           viewport;
    private final HUD              hud;
    private final ScreenShake     shake;
    private final AnimationManager anim;
    private final EnemyAnimator    enemyAnim = new EnemyAnimator();
    private OrthogonalTiledMapRenderer tiledRenderer   = null;
    private TiledMap activeTiledMap  = null;
    private int[] bgLayers = new int[0];//background
    private int[] fgLayers = new int[0];//fore

    //colour libgdx
    private static final Color[] BG_COLORS = {
        new Color(0.05f, 0.05f, 0.12f, 1f),
        new Color(0.04f, 0.12f, 0.06f, 1f),
        new Color(0.04f, 0.04f, 0.18f, 1f),
        new Color(0.12f, 0.06f, 0.18f, 1f)
    };
    private static final Color[] PLATFORM_COLORS = {
        new Color(0.25f, 0.25f, 0.35f, 1f),
        new Color(0.18f, 0.32f, 0.16f, 1f),
        new Color(0.22f, 0.22f, 0.40f, 1f),
        new Color(0.35f, 0.22f, 0.45f, 1f)
    };
    private static final Color[] HAZARD_COLORS = {
        new Color(0.70f, 0.70f, 0.80f, 1f),
        new Color(0.30f, 0.70f, 0.25f, 1f),
        new Color(0.50f, 0.50f, 0.90f, 1f),
        new Color(0.55f, 0.30f, 0.80f, 1f)
    };
    private float zoteTimer = 0f;
    private float spellTimer = 0f;
    private float   slashTimer   = 0f;
    private boolean wasAttacking = false;
    private Texture youDiedTex;
    //////////
    public GameRenderer(SpriteBatch batch, ShapeRenderer shapes) {
        this.batch  = batch;
        this.shapes = shapes;
        this.font   = new BitmapFont();
        font.getData().setScale(1.1f);
        camera   = new OrthographicCamera();
        viewport = new FitViewport(GameConfig.V_WIDTH, GameConfig.V_HEIGHT, camera);
        viewport.apply(true);
        hud   = new HUD();
        shake = new ScreenShake();
        anim  = new AnimationManager();

        //enemies animations
        enemyAnim.loadFrameSequence("crawler_walk",
            "sprites/enemies/crawler", "Walk_", 4, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("crawler_turn",
            "sprites/enemies/crawler", "Turn_", 2, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("guardian_idle",
            "sprites/enemies/guardian", "guardian_", 1, 3, "png", 0.10f);
        enemyAnim.loadFrameSequence("crystallized_idle",
            "sprites/enemies/crystallized", "Idle_", 5, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("crystallized_turn",
            "sprites/enemies/crystallized", "Turn_", 3, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("crystallized_run",
            "sprites/enemies/crystallized", "Run_", 6, 3, "png", 0.08f);

        enemyAnim.loadFrameSequence("crawler_dead",
            "sprites/enemies/crawler", "DeathLand_", 2, 3, "png", 0.10f);
        enemyAnim.loadFrameSequence("guardian_dead",
            "sprites/enemies/guardian", "Dead_", 1, 3, "png", 0.10f);
        enemyAnim.loadFrameSequence("crystallized_dead",
            "sprites/enemies/crystallized", "DeathLand_", 1, 3, "png", 0.10f);
        //2
        enemyAnim.loadFrameSequence("mosquito_idle",
            "sprites/enemies/mosquito", "Idle_", 8, 3, "png", 0.09f);
        enemyAnim.loadFrameSequence("mosquito_attack",
            "sprites/enemies/mosquito", "Attack_", 3, 3, "png", 0.07f);
        enemyAnim.loadFrameSequence("mosquito_turn",
            "sprites/enemies/mosquito", "Turn_", 2, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("mosquito_dead",
            "sprites/enemies/mosquito", "DeathLand_", 2, 3, "png", 0.12f);
        enemyAnim.loadFrameSequence("mosscreep_walk",
            "sprites/enemies/mosscreep", "Walk_", 3, 3, "png", 0.12f);
        enemyAnim.loadFrameSequence("mosscreep_turn",
            "sprites/enemies/mosscreep", "Turn_", 3, 3, "png", 0.10f);
        enemyAnim.loadFrameSequence("mosscreep_dead",
            "sprites/enemies/mosscreep", "DeathLand_", 2, 3, "png", 0.12f);
        //zote
        enemyAnim.loadFrameSequence("zote_idle",
            "sprites/npc/zote", "Idle_", 5, 3, "png", 0.15f);   // تنفس آرام
        enemyAnim.loadFrameSequence("zote_talk",
            "sprites/npc/zote", "Talk_", 5, 3, "png", 0.12f);
        enemyAnim.loadFrameSequence("zote_attack",
            "sprites/npc/zote", "Attack_", 4, 3, "png", 0.09f);
        //spell
        enemyAnim.loadFrameSequence("vs_fly",
            "sprites/effects/vengeful", "Fly_", 7, 3, "png", 0.07f);   // ⚠️ تعداد فریم
        enemyAnim.loadSheetRow("hw_cast",
            "sprites/effects/wraiths/VoidSpells.png",
            5, 2, 0, 5, 0.08f);
        //F_K
        String fkDir = "sprites/enemies/false_knight";
        enemyAnim.loadFrameSequence("fk_idle", fkDir, "Idle_", 5, 3, "png", 0.15f);
        enemyAnim.loadFrameSequence("fk_slam", fkDir, "Jump Attack_", 8, 3, "png", 0.10f);
        enemyAnim.loadFrameSequence("fk_run",  fkDir, "Run_",  5, 3, "png", 0.08f);
        enemyAnim.loadFrameSequence("fk_jump", fkDir, "Jump_", 4, 3, "png", 0.12f);
        enemyAnim.loadFrameSequence("fk_stun", fkDir, "Stun Recover_", 6, 3, "png", 5f);
        enemyAnim.loadFrameSequence("fk_dead", fkDir, "DeathLand_", 11, 3, "png", 0.25f);
        //Nail
        enemyAnim.loadFrameSequence("slash_h",
            "sprites/effects/slash", "SlashEffect_", 6, 3, "png", 0.04f);
        enemyAnim.loadFrameSequence("slash_up",
            "sprites/effects/slash", "UpSlashEffect_", 6, 3, "png", 0.04f);
        enemyAnim.loadFrameSequence("slash_down",
            "sprites/effects/slash", "DownSlashEffect_", 6, 3, "png", 0.04f);
        //shockwave
        enemyAnim.loadFrameSequence("shockwave",
            "sprites/effects/shockwave", "Shockwave_", 4, 3, "png", 0.08f);
        try {
            youDiedTex = new Texture("sprites/ui/you_died.png");
            youDiedTex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        } catch (Exception ex) {
            youDiedTex = null;
        }
    }
    private String fkAnimKey(FalseKnight fk) {
        if (!fk.alive) return "fk_dead";
        return switch (fk.fkState) {
            case MACE_SLAM, POWER_MACE_SLAM     -> "fk_slam";
            case CHARGE_RUN                     -> "fk_run";
            case OFFENSIVE_LEAP, DEFENSIVE_LEAP -> "fk_jump";
            case STUNNED                        -> "fk_stun";
            case DEAD                           -> "fk_dead";
            default                             -> "fk_idle";
        };
    }

    public void render(GameState gameState, float delta) {
        if (gameState.getPlayer() == null) return;
        //wave
        var fkShake = gameState.getLevel().falseKnight;
        if (fkShake != null && fkShake.alive) {
            if (fkShake.powerSlamImpact) shake.trauma(0.8f);//power slam
            else if (fkShake.slamImpact)      shake.trauma(0.5f);//usual slam
        }
        shake.update();
        updateCamera(gameState.getPlayer(), gameState.getLevel().currentRoom);

        Room   room   = gameState.getLevel().currentRoom;
        int    envIdx = environmentIndex(room.environment);
        Player player = gameState.getPlayer();

        Gdx.gl.glClearColor(BG_COLORS[envIdx].r, BG_COLORS[envIdx].g,
            BG_COLORS[envIdx].b, 1f);
        Gdx.gl.glClear(com.badlogic.gdx.graphics.GL20.GL_COLOR_BUFFER_BIT);
        shapes.setProjectionMatrix(camera.combined);
        batch .setProjectionMatrix(camera.combined);

        //map
        if (room.tiledMap != null) {
            if (room.tiledMap != activeTiledMap) {
                if (tiledRenderer != null) tiledRenderer.dispose();
                tiledRenderer  = new OrthogonalTiledMapRenderer(room.tiledMap, 1f);
                activeTiledMap = room.tiledMap;
                java.util.List<Integer> bg = new java.util.ArrayList<>();
                java.util.List<Integer> fg = new java.util.ArrayList<>();
                var layers = room.tiledMap.getLayers();
                for (int i = 0; i < layers.getCount(); i++) {
                    if (!(layers.get(i) instanceof TiledMapTileLayer)) continue;//no objects
                    String name = layers.get(i).getName().toLowerCase();
                    if (name.contains("fore") || name.contains("front")) fg.add(i);
                    else bg.add(i);
                }
                bgLayers = new int[bg.size()];
                for (int i = 0; i < bg.size(); i++) bgLayers[i] = bg.get(i);
                fgLayers = new int[fg.size()];
                for (int i = 0; i < fg.size(); i++) fgLayers[i] = fg.get(i);
                Gdx.app.log("GameRenderer", "bg layers: " + bg + "  fg layers: " + fg);
            }
            tiledRenderer.setView(camera);
            if (bgLayers.length > 0) tiledRenderer.render(bgLayers);//just back
        } else {
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            Color pc = PLATFORM_COLORS[envIdx];
            for (Platform pl : room.platforms) {
                shapes.setColor(pl.type == Platform.Type.ONE_WAY
                    ? pc.r * 0.7f : pc.r, pc.g, pc.b, 1f);
                shapes.rect(pl.x, pl.y, pl.w, pl.h);
            }
            shapes.setColor(pc.r + 0.15f, pc.g + 0.15f, pc.b + 0.15f, 1f);
            for (Platform pl : room.platforms) {
                if (pl.type != Platform.Type.ONE_WAY)
                    shapes.rect(pl.x, pl.top() - 3, pl.w, 3);
            }
            shapes.end();

            shapes.begin(ShapeRenderer.ShapeType.Filled);
            Color hc = HAZARD_COLORS[envIdx];
            for (Hazard hz : room.hazards) {
                shapes.setColor(hc);
                float tw = hz.w / 4f;
                for (int i = 0; i < 4; i++) {
                    float bx = hz.x + i * tw;
                    shapes.triangle(bx, hz.y, bx + tw, hz.y, bx + tw / 2f, hz.y + hz.h);
                }
            }
            shapes.end();
        }
        //wall
        if (!room.breakableWalls.isEmpty()) {
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            for (com.hollowknight.model.world.BreakableWall bw : room.breakableWalls) {
                if (bw.broken) continue;
                float t = bw.hp / 5f;
                shapes.setColor(0.15f + 0.45f * t, 0.12f + 0.35f * t, 0.10f + 0.30f * t, 1f);
                shapes.rect(bw.x, bw.y, bw.w, bw.h);
                shapes.setColor(0.10f, 0.08f, 0.06f, 1f);
                for (int i = 5; i > bw.hp; i--) {
                    float cy = bw.y + bw.h * (i / 6f);
                    shapes.rect(bw.x + 4, cy, bw.w - 8, 2);
                }
            }
            shapes.end();
        }
        //enemies dead
        batch.begin();
        for (Enemy enemy : room.enemies) {
            if (!enemy.alive) {
                String deadKey = enemyCorpseKey(enemy);
                if (deadKey != null && enemyAnim.has(deadKey)) {
                    float dw = enemy.width  * 1.3f;
                    float dh = enemy.height * 1.2f;
                    enemyAnim.draw(batch, deadKey, 0f,
                        enemy.x + enemy.width / 2f - dw / 2f, enemy.y,
                        dw, dh, enemy.facing < 0);
                }
                continue;
            }
            String key = enemyAnimKey(enemy);
            if (key == null || !enemyAnim.has(key)) continue;
            enemy.animTimer += delta;
            //red when hurts
            if (enemy.hurtTimer > 0) batch.setColor(1f, 0.35f, 0.35f, 1f);

            float drawW = enemy.width  * 1.3f;
            float drawH = enemy.height * 1.2f;
            if (enemy instanceof FalseKnight) {//draw bigger but hitbox is previous
                drawW = enemy.width  * 4f;
                drawH = enemy.height * 3f;
            }
            enemyAnim.draw(batch, key, enemy.animTimer,
                enemy.x + enemy.width / 2f - drawW / 2f,
                enemy.y, drawW, drawH,
                enemy.facing < 0);
            batch.setColor(1f, 1f, 1f, 1f);
        }
        batch.end();
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        for (Enemy enemy : room.enemies) {
            if (!enemy.alive) continue;
            String key = enemyAnimKey(enemy);
        }
        shapes.end();
        //zote
        if (room.hasZote) drawZote(room, delta);
        //guardian
        for (Enemy enemy : room.enemies) {
            if (enemy instanceof CrystalGuardian cg && cg.laserActive) {
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                shapes.setColor(0.55f, 0.30f, 1.0f, 0.85f);
                float ly = cg.y + cg.height / 2f - 4f;
                if (cg.laserFacing > 0)
                    shapes.rect(cg.x + cg.width, ly, room.boundsW - cg.x - cg.width, 8f);
                else
                    shapes.rect(0, ly, cg.x, 8f);
                shapes.end();
            }
        }
        spellTimer += delta;
        boolean vsPng = enemyAnim.has("vs_fly");
        boolean hwPng = enemyAnim.has("hw_cast");
        if (vsPng || hwPng) {
            batch.begin();
            if (vsPng) for (Projectile proj : gameState.projectiles) {
                if (!proj.alive) continue;
                float dw = Projectile.W * 2.2f, dh = Projectile.H * 2.6f;
                enemyAnim.draw(batch, "vs_fly", spellTimer,
                    proj.x + Projectile.W / 2f - dw / 2f,
                    proj.y + Projectile.H / 2f - dh / 2f,
                    dw, dh, proj.velX < 0);
            }
            if (hwPng) for (HowlingWraithsEffect hw : gameState.wraiths) {
                if (!hw.alive) continue;
                float dw = hw.W * 3f;
                float dh = hw.H * 1.1f;
                enemyAnim.draw(batch, "hw_cast", spellTimer,
                    hw.x + hw.W / 2f - dw / 2f,
                    hw.y, dw, dh, false);
            }
            batch.end();
        }

        if (!vsPng || !hwPng) {
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            if (!vsPng) for (Projectile proj : gameState.projectiles) {
                shapes.setColor(0.75f, 0.40f, 1.0f, 1f);
                shapes.ellipse(proj.x, proj.y, Projectile.W, Projectile.H);
            }
            if (!hwPng) for (HowlingWraithsEffect hw : gameState.wraiths) {
                shapes.setColor(0.55f, 0.30f, 1.0f, 0.55f);
                shapes.rect(hw.x, hw.y, hw.W, hw.H);
            }
            shapes.end();
        }

        //player
        if (GameController_ref != null && !GameController_ref.waves.isEmpty()) {
            if (enemyAnim.has("shockwave")) {
                batch.begin();
                for (Shockwave w : GameController_ref.waves) {
                    if (!w.alive) continue;
                    float dw = Shockwave.W * 2.2f, dh = Shockwave.H * 1.4f;
                    enemyAnim.draw(batch, "shockwave", spellTimer,
                        w.x + Shockwave.W / 2f - dw / 2f, w.y, dw, dh, w.dir < 0);                    // موج چپ‌رو فلیپ می‌شود
                }
                batch.end();
            }
            else {
                shapes.begin(ShapeRenderer.ShapeType.Filled);  // fallback: مستطیل نارنجی
                shapes.setColor(1f, 0.55f, 0.15f, 0.9f);
                for (Shockwave w : GameController_ref.waves)
                    if (w.alive) shapes.rect(w.x, w.y, Shockwave.W, Shockwave.H);
                shapes.end();
            }
        }
        //foreground
        if (room.tiledMap != null && tiledRenderer != null && fgLayers.length > 0) {
            tiledRenderer.render(fgLayers);
        }
        //boss helath
        if (room.isBossRoom && gameState.getLevel().falseKnight != null
            && gameState.getLevel().falseKnight.alive) {
            drawBossBar(gameState);
        }
        //hud
        viewport.apply();
        OrthographicCamera hudCam = new OrthographicCamera(
            GameConfig.V_WIDTH, GameConfig.V_HEIGHT);
        hudCam.setToOrtho(false, GameConfig.V_WIDTH, GameConfig.V_HEIGHT);
        hudCam.update();
        shapes.setProjectionMatrix(hudCam.combined);
        batch .setProjectionMatrix(hudCam.combined);
        hud.render(batch, shapes, gameState, viewport);
        if (GameController_ref != null) drawDialogue();

        if (hud.cheatMessage != null) {
            batch.begin();
            font.setColor(Color.YELLOW);
            font.draw(batch, hud.cheatMessage, 20, 30);
            batch.end();
        }

        var popup = gameState.getAchievements().activePopup();
        if (popup != null) {
            batch.begin();
            font.setColor(Color.GOLD);
            font.draw(batch, "Achievement: " + popup.name, GameConfig.V_WIDTH - 290f, GameConfig.V_HEIGHT - 22f);
            font.setColor(Color.WHITE);
            font.draw(batch, popup.description, GameConfig.V_WIDTH - 290f, GameConfig.V_HEIGHT - 42f);
            batch.end();
        }
        //you died popup
        if (gameState.getPlayer() != null && gameState.getPlayer().state == PlayerState.DEAD) {
            batch.begin();
            if (youDiedTex != null) {
                float dw = 600f, dh = 400f;
                batch.draw(youDiedTex, GameConfig.V_WIDTH  / 2f - dw / 2f, GameConfig.V_HEIGHT / 2f - dh / 2f + 30f, dw, dh);
            }
            else {
                font.getData().setScale(3.5f);
                font.setColor(0.80f, 0.12f, 0.12f, 1f);
                font.draw(batch, "YOU DIED", GameConfig.V_WIDTH / 2f - 100, GameConfig.V_HEIGHT / 2f + 40);
                font.getData().setScale(1f);
                font.setColor(Color.WHITE);
            }
            batch.end();
        }
    }
    private void drawZote(Room room, float delta) {
        zoteTimer += delta;
        String key;
        if (room.zoteAngryTimer > 0) key = "zote_attack";
        else if (GameController_ref != null && GameController_ref.inDialogue) key = "zote_talk";
        else key = "zote_idle";
        if (!enemyAnim.has(key)) key = enemyAnim.has("zote_idle") ? "zote_idle" : null;
        if (key != null) {
            float drawW = 100f, drawH = 80f;
            batch.begin();
            enemyAnim.draw(batch, key, zoteTimer,
                room.zoteX + 13f - drawW / 2f, room.zoteY,
                drawW, drawH,
                room.zoteFacing < 0);
            batch.end();
        }
        else {
            float b = 1f + 0.06f * (float) Math.sin(zoteTimer * 3f);
            shapes.begin(ShapeRenderer.ShapeType.Filled);
            shapes.setColor(0.82f, 0.78f, 0.70f, 1f);
            shapes.rect(room.zoteX, room.zoteY, 26, 36 * b);
            shapes.setColor(0.95f, 0.90f, 0.80f, 1f);
            shapes.ellipse(room.zoteX + 3, room.zoteY + 26 * b, 20, 18);
            shapes.setColor(0.20f, 0.15f, 0.10f, 1f);
            shapes.ellipse(room.zoteX + 15, room.zoteY + 30 * b, 5, 5);
            shapes.end();
        }
        if (GameController_ref != null && GameController_ref.playerNearZote) {
            batch.begin();
            font.setColor(Color.WHITE);
            font.draw(batch, "[UP] Talk", room.zoteX - 10, room.zoteY + 60);
            batch.end();
        }
    }
    private String enemyAnimKey(Enemy enemy) {
        if (enemy instanceof CrystalGuardian) return "guardian_idle";
        if (enemy instanceof FalseKnight fk) return fkAnimKey(fk);

        if (enemy instanceof HuskHornhead hh) {
            if (hh.turnTimer > 0) return "crystallized_turn";
            if (Math.abs(hh.velX) > 3f) return "crystallized_run";
            return "crystallized_idle";
        }
        if (enemy instanceof com.hollowknight.model.enemy.flying.FlyingEnemy) {
            float spd = Math.abs(enemy.velX) + Math.abs(enemy.velY);
            if (spd > 3f && enemyAnim.has("mosquito_attack"))
                return "mosquito_attack";
            return enemyAnim.has("mosquito_idle") ? "mosquito_idle" : null;
        }
        //groundy
        if (enemy instanceof GroundEnemy groundEnemy) {
            if (groundEnemy.getClass().getSimpleName().equals("Mosscreep")) {
                if (groundEnemy.turnTimer > 0 && enemyAnim.has("mosscreep_turn"))
                    return "mosscreep_turn";
                return enemyAnim.has("mosscreep_walk") ? "mosscreep_walk" : null;
            }
            return groundEnemy.turnTimer > 0 ? "crawler_turn" : "crawler_walk";
        }
        return null;
    }
    private String enemyCorpseKey(Enemy e) {
        if (e instanceof CrystalGuardian) return "guardian_dead";
        if (e instanceof HuskHornhead)    return "crystallized_dead";

        if (e instanceof com.hollowknight.model.enemy.flying.FlyingEnemy)
            return enemyAnim.has("mosquito_dead") ? "mosquito_dead" : null;

        if (e instanceof GroundEnemy) {
            if (e.getClass().getSimpleName().equals("Mosscreep")
                && enemyAnim.has("mosscreep_dead")) return "mosscreep_dead";
            return "crawler_dead";
        }
        return null;
    }
    private void drawBossBar(GameState gs) {
        FalseKnight fk = gs.getLevel().falseKnight;
        float bw = GameConfig.V_WIDTH * 0.60f;
        float bx = (GameConfig.V_WIDTH - bw) / 2f;
        float by = 24f;
        float frac = (float) fk.hp / fk.maxHp;

        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.15f, 0.05f, 0.05f, 1f);
        shapes.rect(bx, by, bw, 14);
        shapes.setColor(fk.phase2 ? 0.90f : 0.75f,
            fk.phase2 ? 0.25f : 0.20f, 0.20f, 1f);
        shapes.rect(bx, by, bw * frac, 14);
        shapes.setColor(0.60f, 0.20f, 0.20f, 1f);
        shapes.rect(bx, by + 12, bw, 2);
        shapes.end();

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, "False Knight" + (fk.phase2 ? " (Phase 2)" : ""),
            bx, by + 28);
        batch.end();
    }
    public com.hollowknight.controller.GameController GameController_ref;

    private void drawDialogue() {
        if (GameController_ref == null || GameController_ref.activeDialogue == null) return;

        String full  = GameController_ref.activeDialogue;
        int n = Math.min(GameController_ref.dialogueCharCount, full.length());
        String shown = full.substring(0, n);

        float dw = 560f, dh = 84f;
        float dx = (GameConfig.V_WIDTH - dw) / 2f;
        float dy = 60f;

        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0.08f, 0.08f, 0.14f, 0.92f);
        shapes.rect(dx, dy, dw, dh);
        shapes.setColor(0.60f, 0.60f, 0.80f, 1f);
        shapes.rect(dx, dy + dh - 2, dw, 2);
        shapes.end();

        batch.begin();
        font.setColor(Color.GOLD);
        font.draw(batch, "Zote the Mighty:", dx + 12, dy + dh - 12);
        font.setColor(Color.WHITE);
        font.draw(batch, shown, dx + 12, dy + dh - 34);
        if (n >= full.length()) {
            font.setColor(Color.LIGHT_GRAY);
            font.draw(batch, "[Enter]", dx + dw - 70, dy + 18);
        }
        batch.end();
    }

    ///camera
    private void updateCamera(Player p, Room room) {
        float targetX = p.x + p.W / 2f;
        float targetY = p.y + p.H / 2f;
        camera.position.x += (targetX - camera.position.x) * GameConfig.CAMERA_softmovement;
        camera.position.y += (targetY - camera.position.y) * GameConfig.CAMERA_softmovement;
        float hw = GameConfig.V_WIDTH  / 2f;
        float hh = GameConfig.V_HEIGHT / 2f;
        camera.position.x = MathUtils.clamp(camera.position.x, room.boundsX + hw, room.boundsX + room.boundsW  - hw);
        camera.position.y = MathUtils.clamp(camera.position.y, room.boundsY + hh, room.boundsY + room.boundsH - hh);
        camera.position.x += shake.getOffsetX();
        camera.position.y += shake.getOffsetY();
        camera.update();
    }

    public void triggerShake(float amount) { shake.trauma(amount); }
    public void resize(int w, int h) {
        viewport.update(w, h, true);
    }
    private int environmentIndex(String env) {
        return switch (env) {
            case GameConfig.ENV_GREENPATH     -> 1;
            case GameConfig.ENV_CITY_OF_TEARS -> 2;
            case GameConfig.ENV_CRYSTAL_PEAKS -> 3;
            default -> 0;
        };
    }
    public HUD getHud() { return hud; }
    public AnimationManager getAnimManager() { return anim; }
    /// /////
    public void dispose() {
        font.dispose();
        anim.dispose();
        enemyAnim.dispose();
        hud.dispose();
        if (tiledRenderer != null) tiledRenderer.dispose();
        if (youDiedTex != null) youDiedTex.dispose();
    }
}
