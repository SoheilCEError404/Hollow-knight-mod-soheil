package com.hollowknight.view.effects;

import java.util.Random;
public class ScreenShake {
    private float trauma     = 0f;
    private float offsetX    = 0f;
    private float offsetY    = 0f;

    private static final float DECAY     = 0.035f;
    private static final float MAX_SHIFT = 12f;
    private final Random rng = new Random();

    public void trauma(float amount) {
        trauma = Math.min(1f, trauma + amount);
    }

    public void update() {
        if (trauma <= 0f) { offsetX = offsetY = 0f; return; }
        float shake = trauma * trauma;
        //smooth
        offsetX = (rng.nextFloat() * 2 - 1) * MAX_SHIFT * shake;
        offsetY = (rng.nextFloat() * 2 - 1) * MAX_SHIFT * shake;
        trauma  = Math.max(0f, trauma - DECAY);
    }
    public float getOffsetX() { return offsetX; }
    public float getOffsetY() { return offsetY; }
}
