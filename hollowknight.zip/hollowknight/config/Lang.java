package com.hollowknight.config;

import com.badlogic.gdx.Gdx;
import java.util.HashMap;
import java.util.Map;

public final class Lang {
    public static String current = "en";
    private static final Map<String, String[]> String = new HashMap<>();  //----->0=english 1=french

    static {
        put("Continue",        "Continue",        "Continuer");
        put("New Game",        "New Game",        "Nouvelle partie");
        put("Load",            "Load",            "Charger");
        put("Settings",        "Settings",        "Parametres");
        put("Exit",            "Exit",            "Quitter");
        put("Login / Signup",  "Login / Signup",  "Connexion / Inscription");
        put("Logged out.",     "Logged out.",     "Deconnecte.");
        put("Logout",          "Logout",          "Deconnexion");
        put("No saved game found.", "No saved game found.", "Aucune sauvegarde trouvee.");

        put("settings",        "Settings",        "Parametres");
        put("Music Volume: ",  "Music Volume: ",  "Volume musique: ");
        put("Music: ON",       "Music: ON",       "Musique: OUI");
        put("Music: OFF",      "Music: OFF",      "Musique: NON");
        put("SFX Volume: ",    "SFX Volume: ",    "Volume effets: ");
        put("SFX: ON",         "SFX: ON",         "Effets: OUI");
        put("SFX: OFF",        "SFX: OFF",        "Effets: NON");
        put("Key Rebinding (click then press a key):",
            "Key Rebinding (click then press a key):",
            "Touches (cliquez puis appuyez sur une touche):");
        put("Press any key for ", "Press any key for ", "Appuyez sur une touche pour ");
        put("Rebound ",        "Rebound ",        "Touche ");
        put(" to ",            " to ",            " changee en ");
        put("Reset Controls",  "Reset Controls",  "Reinitialiser les commandes");
        put("Controls reset.", "Controls reset.", "Commandes reinitialisees.");
        put("Save & Back",     "Save & Back",     "Enregistrer & Retour");
        put("language",        "Language: English", "Langue: Francais");

        put("Load Menu",       "Load Menu",       "Menu de chargement");
        put("New Game Menu",   "New Game Menu",   "Nouvelle partie");
        put("Back",            "Back",            "Retour");
        put("Empty",           "Empty",           "Vide");
        put("Start",           "Start",           "Commencer");
        put("Slot ",           "Slot ",           "Emplacement ");
        put("Deaths: ",        "Deaths: ",        "Morts: ");

        put("Guide",           "Guide",           "Guide");
        put("Controls",        "Controls",        "Commandes");
        put("Abilities",       "Abilities",       "Capacites");
        put("Cheat Codes",     "Cheat Codes",     "Codes de triche");
        put("Achievements",    "Achievements",    "Succes");
        put("Locked",          "Locked",          "Verrouille");

        put("PAUSED",          "PAUSED",          "PAUSE");
        put("Save & Quit",     "Save & Quit",     "Sauvegarder & Quitter");

        put("YOU DIED",        "YOU DIED",        "VOUS ETES MORT");
        put("Deaths:",         "Deaths:",         "Morts:");
        put("Enemies slain:",  "Enemies slain:",  "Ennemis tues:");
        put("Play time:",      "Play time:",      "Temps de jeu:");
        put("Respawn",         "Respawn",         "Reapparaitre");
        put("Main Menu",       "Main Menu",       "Menu principal");
    }

    private static void put(String k,String en,String fr) { String.put(k, new String[]{en,fr}); }

    public static String translate(String key) {
        String[] v = String.get(key);
        return v == null ? key : (current.equals("fr") ? v[1] : v[0]);
    }

    public static void toggle() {
        current = current.equals("en") ? "fr" : "en";
        var p = Gdx.app.getPreferences("hk_lang");
        p.putString("lang", current);
        p.flush();
    }

    public static void load() {current = Gdx.app.getPreferences("hk_lang").getString("lang", "en");}
}
