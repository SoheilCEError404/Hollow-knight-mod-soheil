package com.hollowknight.config;

public final class GameConfig {
    //libgdx colour (RGBA ShapeRenderer)
    public static final float[] COL_SOUL       = {0.65f, 0.82f, 1.0f, 1.0f};
    public static final float[] COL_SOUL_BG    = {0.10f, 0.10f, 0.20f, 1.0f};

    //screen
    public static final int    V_WIDTH        = 960;
    public static final int    V_HEIGHT       = 540;
    //physic
    public static final float GRAVITY          = -0.55f;
    public static final float MAX_FALL_SPEED   = -16f;
    public static final float WALL_SLIDE_SPEED = -1.2f;
    public static final float PLAYER_SPEED     = 4.5f;
    public static final float JUMP_FORCE       = 13.5f;
    public static final float DOUBLE_JUMP_FORCE = 12.0f;
    public static final float DASH_SPEED       = 12f;
    public static final int   DASH_DURATION    = 14;
    public static final int   DASH_COOLDOWN    = 45;
    public static final float POGO_BOUNCE      = 13.5f;
    public static final float KNOCKBACK_FORCE  = 6f;
    public static final int   COYOTE_TIME      = 8;
    //Player
    public static final int   MAX_MASKS          = 5;
    public static final int   STARTING_MASKS     = 5;
    public static final int   MAX_SOUL           = 99;
    public static final int   SOUL_PER_HIT       = 11;
    public static final int   SPELL_COST         = 33;
    public static final int   FOCUS_COST         = 33;
    public static final int   FOCUS_FRAMES       = 90;
    public static final int   INVINCIBILITY_FRAMES = 60;
    // 1sec

    //fight
    public static final int   NAIL_DAMAGE        = 5;
    public static final float NAIL_REACH         = 38f;
    public static final int   NAIL_TOTAL_FRAMES  = 18;

    //spell
    public static final float VS_SPEED         = 9f;        //vengeful spirit
    public static final int   VS_DAMAGE        = 15;
    public static final int   HW_DAMAGE        = 5;         //howling wraiths
    public static final int   HW_TICKS         = 3;
    public static final int   HW_DURATION      = 25;
    public static final int   CAST_LOCK_FRAMES = 22;

    //camera
    public static final float CAMERA_softmovement = 0.09f;

    //charms
    public static final int TOTAL_NOTCHES = 3;

    //save
    public static final int    SAVE_SLOTS        = 4;
    public static final String SAVE_FILE_PREFIX  = "hk_save_";

    //audio
    public static final float DEFAULT_MUSIC_VOL = 0.5f;
    public static final float DEFAULT_SFX_VOL   = 0.8f;

    //Enemy_HP
    public static final int HP_CRAWLID         = 8;
    public static final int HP_MOSSCREEP       = 10;
    public static final int HP_TIKTIK          = 8;
    public static final int HP_CRYSTAL_CRAWLER = 12;
    public static final int HP_MOSQUITO        = 10;
    public static final int HP_MOSSFLY         = 8;
    public static final int HP_WINGED_SENTRY   = 15;
    public static final int HP_CRYSTAL_HUNTER  = 12;
    public static final int HP_HUSK_HORNHEAD   = 20;
    public static final int HP_CRYSTAL_GUARDIAN = 30;
    public static final int HP_FALSE_KNIGHT    = 160;

    //False_Knight--->fk
    public static final int   FK_STUN_DURATION       = 120;
    public static final int   FK_MIN_DECISION_CD     = 55;
    public static final float FK_CHARGE_SPEED        = 7f;
    public static final float FK_PHASE2_SPEED_MULT   = 1.4f;
    public static final float FK_NEAR_THRESHOLD      = 150f;
    public static final float FK_FAR_THRESHOLD       = 300f;
    public static final int   FK_SLAM_DAMAGE      = 1;
    public static final int   FK_WAVE_DAMAGE      = 2;
    public static final float FK_WAVE_START_SPEED = 3.0f;
    public static final float FK_WAVE_ACCEL       = 0.15f;//----->increase speed attack


    //Game_states
    public static final String STATE_MAIN_MENU    = "main_menu";
    public static final String STATE_LOGIN        = "login";
    public static final String STATE_SIGNUP       = "signup";
    public static final String STATE_LOAD_MENU    = "load_menu";
    public static final String STATE_NEW_GAME_MENU = "new_game_menu";
    public static final String STATE_SETTINGS     = "settings";
    public static final String STATE_GUIDE        = "guide";
    public static final String STATE_ACHIEVEMENTS = "achievements";
    public static final String STATE_PLAYING      = "playing";
    public static final String STATE_PAUSED       = "paused";
    public static final String STATE_INVENTORY    = "inventory";
    public static final String STATE_GAME_OVER    = "game_over";

    //worlds
    public static final String ENV_FORGOTTEN_CROSSROADS = "forgotten_crossroads";
    public static final String ENV_GREENPATH            = "greenpath";
    public static final String ENV_CITY_OF_TEARS        = "city_of_tears";
    public static final String ENV_CRYSTAL_PEAKS        = "crystal_peaks";
    public static final String STATE_THE_END = "the_end";
}
