package com.hollowknight.model.spell;

import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.config.GameConfig;

public class Projectile {
    public float x, y;
    public final float velX;
    public int  damage;
    public boolean alive = true;
    public static final float W = 22f, H = 14f;

    public Projectile(float x, float y, int facing) {
        this.x      = x + (facing > 0 ? 20f : -W - 20f);
        this.y      = y;
        this.velX   = facing * GameConfig.VS_SPEED;
        this.damage = GameConfig.VS_DAMAGE;
    }
    /// /////////
    public void update() {
        if (!alive) return;
        x += velX;
    }

    public Rectangle getBounds() { return new Rectangle(x, y, W, H); }
    public void destroy(){ alive = false; }
}
