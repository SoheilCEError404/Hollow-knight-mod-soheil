package com.hollowknight.model.spell;

import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.config.GameConfig;
public class HowlingWraithsEffect {

    public float  x, y;
    public boolean alive     = true;
    public int    timer      = GameConfig.HW_DURATION;
    public int    ticksLeft  = GameConfig.HW_TICKS;
    public int    nextTick   = GameConfig.HW_DURATION / GameConfig.HW_TICKS;
    public static final float W = 60f, H = 120f;

    public HowlingWraithsEffect(float playerX, float playerY, float playerW, float playerH) {
        this.x = playerX + playerW / 2f - W / 2f;
        this.y = playerY + playerH;
    }
    //////////////
    public boolean update() {
        if (!alive) return false;
        timer--;
        nextTick--;
        if (timer <= 0) { alive = false; return false; }
        if (nextTick <= 0 && ticksLeft > 0) {
            ticksLeft--;
            nextTick = GameConfig.HW_DURATION / GameConfig.HW_TICKS;
            return true;  // damage frame
        }
        return false;
    }

    public Rectangle getBounds() { return new Rectangle(x, y, W, H); }
}
