package com.hollowknight.model.player;

/** All discrete states the player character can be in. */
public enum PlayerState {
    IDLE,
    RUNNING,
    JUMPING,
    DOUBLE_JUMPING,
    FALLING,
    DASHING,
    WALL_SLIDING,
    ATTACKING_H,
    ATTACKING_UP,
    ATTACKING_DOWN,
    FOCUSING, //increase soul
    CASTING, //casting when spell
    HURT,
    DEAD
}
