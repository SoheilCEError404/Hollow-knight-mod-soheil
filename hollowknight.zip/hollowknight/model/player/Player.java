package com.hollowknight.model.player;

import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.item.CharmType;
import java.util.EnumSet;
import java.util.Set;

public class Player {
    public float x, y;
    public float velX, velY;
    public final float W = 24f, H = 36f;// hitbox
    public int   facing     = 1;
    public int   wallSide   = 0;
    // -1 left
    // 0 -----
    // 1 right
    public boolean onGround    = false;
    public boolean onWall      = false;
    public int coyoteTimer = 0;
    //attack
    public boolean isAttacking   = false;
    public boolean attackHitbox  = false;   // active hitbox window
    public int     attackTimer   = 0;
    //0=right
    //1=left
    //2=up
    //3=down
    public int     attackDir     = 0;
    //jump
    public boolean jumpHeld        = false;
    public boolean canDoubleJump   = false;
    public boolean doubleJumpUsed  = false;
    public int doubleJumpAnimTimer=0;

    //dash
    public boolean isDashing          = false;
    public int dashTimer          = 0;
    public int dashCooldownTimer  = 0;
    public int dashDirection      = 1;

    //mask
    public int  masks = GameConfig.STARTING_MASKS;
    public int  maxMasks = GameConfig.MAX_MASKS;
    public int  invincibleTimer = 0;
    public boolean isInvincible = false;
    //soul
    public int  soul = 0;
    public int  maxSoul = GameConfig.MAX_SOUL;
    public boolean isFocusing    = false;
    public int     focusTimer    = 0;
    public int     focusDuration = GameConfig.FOCUS_FRAMES;

    //spell define
    public boolean isCasting = false;
    public int castLockTimer = 0;
    //0=---
    //1=VengefulSpirit
    //2=HowlingWraiths */
    public int     pendingSpell  = 0;

    // ── Charms ────────────────────────────────────────────────────────────────
    public Set<CharmType> equippedCharms    = EnumSet.noneOf(CharmType.class);
    public int notchesUsed       = 0;
    public Set<CharmType> discoveredCharms  = EnumSet.of(
            CharmType.SOUL_CATCHER, CharmType.DASHMASTER,
            CharmType.UNBREAKABLE_STRENGTH, CharmType.QUICK_SLASH,
            CharmType.QUICK_FOCUS, CharmType.HEAVY_BLOW,
            CharmType.SHARP_SHADOW, CharmType.VOID_HEART
    );
    public boolean hasDoubleJump       = true;
    public boolean hasMantisWallClaw   = true;
    public boolean hasVengefulSpirit   = true;
    public boolean hasHowlingWraiths   = true;
    public float respawnX, respawnY;
    public int deaths       = 0;
    public int enemiesKilled = 0;
    public PlayerState state = PlayerState.IDLE;
    public int   knockbackTimer = 0;
    public float knockbackVelX  = 0;

    public Player(float startX, float startY) {
        this.x = startX; this.y = startY;
        this.respawnX = startX; this.respawnY = startY;
    }
    /// ////////////////////////////////////
    public void update() {
        updateTimers();
        applyGravity();
        applyKnockback();
        updateFocus();
        updateState();
    }
    /// ////////////////////////////////////
    //rules
    private void applyGravity() {
        if (isDashing) return; //gravity disabled during dash
        if (onWall && !onGround && velY < 0) {
            velY = Math.max(velY + GameConfig.GRAVITY, GameConfig.WALL_SLIDE_SPEED);
        } else {
            velY = Math.max(velY + GameConfig.GRAVITY, GameConfig.MAX_FALL_SPEED);
        }
    }

    private void applyKnockback() {
        if (knockbackTimer > 0) {
            knockbackTimer--;
            velX = knockbackVelX;
        }
    }

    private void updateFocus() {
        if (!isFocusing) return;
        focusTimer++;
        if (focusTimer >= focusDuration) {
            completeFocus();
        }
    }

    private void completeFocus() {
        if (soul >= GameConfig.FOCUS_COST && masks < maxMasks) {
            soul -= GameConfig.FOCUS_COST;
            masks++;
        }
        isFocusing  = false;
        focusTimer  = 0;
    }

    private void updateTimers() {
        if (invincibleTimer > 0 && --invincibleTimer == 0) isInvincible = false;
        //dash
        if (dashTimer > 0       && --dashTimer == 0)       isDashing = false;
        if (dashCooldownTimer > 0) dashCooldownTimer--;
        //attack
        if (attackTimer > 0) {
            attackTimer--;
            attackHitbox = attackTimer > (GameConfig.NAIL_TOTAL_FRAMES / 2);
            if (attackTimer == 0) { isAttacking = false; attackHitbox = false; }
        }
        //Spell cast lock
        if (castLockTimer > 0 && --castLockTimer == 0) isCasting = false;
        //double jump
        if (doubleJumpAnimTimer > 0) doubleJumpAnimTimer--;
        //second jump on air
        if (onGround) { canDoubleJump = hasDoubleJump; doubleJumpUsed = false; }
        //coyote
        if (!onGround && coyoteTimer > 0) coyoteTimer--;
    }

    //movement
    public void moveX(int dir) {
        if (isDashing) return;
        if (knockbackTimer > 0) return;   // ignore movement during knockback
        if (isCasting || isFocusing) return;
        velX = dir * playerSpeed();
        if (dir != 0) facing = dir;
    }

    public void stopX() {
        if (isDashing) return;
        if (knockbackTimer == 0) velX = 0;

    }
    public boolean tryJump() {
        if (isFocusing) return false;

        //jump
        if (onGround || coyoteTimer > 0) {
            velY = GameConfig.JUMP_FORCE;
            jumpHeld      = true;
            canDoubleJump = hasDoubleJump;
            doubleJumpUsed = false;
            onGround      = false;
            coyoteTimer   = 0;
            return true;
        }
        // Wall jump
        if (onWall && hasMantisWallClaw) {
            velY    = GameConfig.JUMP_FORCE * 0.95f;
            velX    = -wallSide * GameConfig.PLAYER_SPEED * 1.5f;
            onWall  = false; wallSide = 0;
            canDoubleJump  = hasDoubleJump;
            doubleJumpUsed = false;
            return true;
        }
        // Double jump
        if (canDoubleJump && !doubleJumpUsed && hasDoubleJump) {
            velY = GameConfig.DOUBLE_JUMP_FORCE;
            doubleJumpUsed = true;
            canDoubleJump  = false;
            doubleJumpAnimTimer=24;
            return true;
        }
        return false;
    }
    public void cutJump() {
        if (velY > 0) velY *= 0.40f;
    }
    public boolean tryDash() {
        if (dashCooldownTimer > 0 || isFocusing) return false;
        isDashing         = true;
        dashTimer         = GameConfig.DASH_DURATION;
        dashCooldownTimer = GameConfig.DASH_COOLDOWN;
        dashDirection     = facing;
        velX = dashDirection * dashSpeed();
        velY = 0;
        if (!onGround) canDoubleJump = true; // Sharp Shadow / air-dash resets dj
        return true;
    }
    public boolean tryAttack(int dir) {
        if (isAttacking || isCasting || isFocusing) return false;
        isAttacking  = true;
        attackHitbox = true;
        attackDir    = dir;
        attackTimer  = GameConfig.NAIL_TOTAL_FRAMES;
        return true;
    }

    //pogo
    public void triggerPogo() {
        velY          = GameConfig.POGO_BOUNCE;
        canDoubleJump = hasDoubleJump;
        doubleJumpUsed = false;
    }
    //focus
    public boolean tryFocus() {
        if (isFocusing || !onGround || soul < GameConfig.FOCUS_COST) return false;
        if (masks >= maxMasks) return false;
        if (isCasting || isAttacking) return false;
        isFocusing = true;
        focusTimer = 0;
        return true;
    }
    public void stopFocus() {
        isFocusing = false;
        focusTimer = 0;
    }
    //spell
    public boolean tryVengefulSpirit() {
        if (!hasVengefulSpirit || isCasting || soul < GameConfig.SPELL_COST) return false;
        soul         -= GameConfig.SPELL_COST;
        isCasting     = true;
        pendingSpell  = 1;
        castLockTimer = GameConfig.CAST_LOCK_FRAMES;
        return true;
    }
    public boolean tryHowlingWraiths() {
        if (!hasHowlingWraiths || isCasting || soul < GameConfig.SPELL_COST) return false;
        soul         -= GameConfig.SPELL_COST;
        isCasting     = true;
        pendingSpell  = 2;
        castLockTimer = GameConfig.CAST_LOCK_FRAMES;
        return true;
    }

    //health
    public boolean takeDamage(int amount, float srcX) {
        if (isInvincible) return false;
        masks = Math.max(0, masks - amount);
        isInvincible     = true;
        invincibleTimer  = GameConfig.INVINCIBILITY_FRAMES;
        stopFocus();
        // Knockback away from source
        knockbackTimer = 15;
        knockbackVelX  = (x > srcX ? 1 : -1) * GameConfig.KNOCKBACK_FORCE;
        velY           = 4f;
        if (masks == 0) die();
        return true;
    }
    public void die() {
        state = PlayerState.DEAD;
        deaths++;
    }
    public void setRespawnPoint(float rx, float ry) {
        respawnX = rx; respawnY = ry;
    }
    //soul
    public void gainSoul(int amount) {
        int bonus = equippedCharms.contains(CharmType.SOUL_CATCHER) ? 3 : 0;
        soul = Math.min(maxSoul, soul + amount + bonus);
    }
    //charm manage set
    public boolean equipCharm(CharmType charm) {
        if (equippedCharms.contains(charm)) return false;
        int cost = charm.notchCost;
        if (notchesUsed + cost > GameConfig.TOTAL_NOTCHES) return false;
        equippedCharms.add(charm);
        notchesUsed += cost;
        applyCharmEffect(charm);
        return true;
    }

    public void unequipCharm(CharmType charm) {
        if (equippedCharms.remove(charm)) {
            notchesUsed -= charm.notchCost;
            removeCharmEffect(charm);
        }
    }

    private void applyCharmEffect(CharmType c) {
        if (c == CharmType.QUICK_FOCUS)
            focusDuration = (int)(GameConfig.FOCUS_FRAMES * 0.60f);
    }

    private void removeCharmEffect(CharmType charm) {
        if (charm == CharmType.QUICK_FOCUS)
            focusDuration = GameConfig.FOCUS_FRAMES;
    }

    public int nailDamage() {
        return equippedCharms.contains(CharmType.UNBREAKABLE_STRENGTH)
                ? (int)(GameConfig.NAIL_DAMAGE * 1.5f) : GameConfig.NAIL_DAMAGE;
    }

    private float playerSpeed() {
        return GameConfig.PLAYER_SPEED;
    }

    private float dashSpeed() {
        return equippedCharms.contains(CharmType.DASHMASTER)
                ? GameConfig.DASH_SPEED * 1.15f : GameConfig.DASH_SPEED;
    }

    //bound rage
    public Rectangle getBounds() {
        return new Rectangle(x, y, W, H);
    }
    public Rectangle getAttackBounds() {
        if (!attackHitbox) return new Rectangle(0, 0, 0, 0);
        float cx = x + W / 2f, cy = y + H / 2f;
        float reach = GameConfig.NAIL_REACH;
        switch (attackDir) {
            case 0: return new Rectangle(cx + 4,          cy - 15,  reach, 30);  // right
            case 1: return new Rectangle(cx - 4 - reach,  cy - 15,  reach, 30);  // left
            case 2: return new Rectangle(cx - 15,         cy + 4,   30, reach);  // up
            case 3: return new Rectangle(cx - 15,         cy - 4 - reach, 30, reach); // down
        }
        return new Rectangle(0, 0, 0, 0);
    }
    private void updateState() {
        if (state == PlayerState.DEAD) return;
        if (isFocusing)         { state = PlayerState.FOCUSING;    return; }
        if (isCasting)          { state = PlayerState.CASTING;     return; }
        if (isDashing)          { state = PlayerState.DASHING;     return; }
        if (isAttacking) {
            state = switch (attackDir) {
                case 2 -> PlayerState.ATTACKING_UP;
                case 3 -> PlayerState.ATTACKING_DOWN;
                default -> PlayerState.ATTACKING_H;
            };
            return;
        }
        if (onWall && !onGround && velY < 0) { state = PlayerState.WALL_SLIDING; return; }
        if (!onGround) {
            if (onWall && hasMantisWallClaw && velY < 0)
            { state = PlayerState.WALL_SLIDING; return; }
            if (doubleJumpAnimTimer > 0)
            { state = PlayerState.DOUBLE_JUMPING; return; }   //-->new
            state = velY > 0 ? PlayerState.JUMPING : PlayerState.FALLING;
            return;
        }
        state = (velX != 0) ? PlayerState.RUNNING : PlayerState.IDLE;
    }
    public void land_on_ground() {
        onGround      = true;
        canDoubleJump = hasDoubleJump;
        doubleJumpUsed = false;
        velY          = 0;
        coyoteTimer   = COYOTE_TIME;
        pogo_reset();
        // Update respawn point
        respawnX = x; respawnY = y;
    }

    private void pogo_reset() { /* pogo auto-resets on any landing */ }

    public void leaveGround() {
        onGround    = false;
        coyoteTimer = COYOTE_TIME;
    }

    public void leaveWall() {
        onWall   = false;
        wallSide = 0;
    }

    public void touchWall(int side) {
        onWall   = true;
        wallSide = side;
    }

    private static final int COYOTE_TIME = GameConfig.COYOTE_TIME;

    @Override
    public String toString() {
        return String.format("Player[%.0f,%.0f vel=%.1f,%.1f masks=%d soul=%d %s]", x, y, velX, velY, masks, soul, state);
    }
}
