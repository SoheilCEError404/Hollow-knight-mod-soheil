package com.hollowknight.model.world;

import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.boss.FalseKnight;

import java.util.LinkedHashMap;
import java.util.Map;

public class Level {

    private final Map<String, Room> rooms = new LinkedHashMap<>();
    public  Room        currentRoom;
    public  FalseKnight falseKnight;   // direct reference for boss UI

    public Level() {
        buildRooms();
        currentRoom = rooms.get("tiled_map1");
    }
    private void buildRooms() {
        Room boss = buildBossRoom();
        Room map2 = buildTiledMap2(boss);
        buildTiledMap1(map2);
    }
    private void buildTiledMap1(Room map2) {
        Room r = TiledRoomLoader.load(
            "tiled_map1",
            GameConfig.ENV_CRYSTAL_PEAKS,
            "maps/map1.tmx",
            "tiled_map2",
            map2.spawnX, map2.spawnY
        );
        rooms.put(r.id, r);
    }
    private Room buildTiledMap2(Room boss) {
        Room r = TiledRoomLoader.load(
            "tiled_map2",
            GameConfig.ENV_GREENPATH,
            "maps/map2.tmx",
            "boss_room",
            boss.spawnX, boss.spawnY);
        rooms.put(r.id, r);
        return r;
    }
    private Room buildBossRoom() {
        Room r = TiledRoomLoader.load(
            "boss_room",
            GameConfig.ENV_FORGOTTEN_CROSSROADS,
            "maps/boss.tmx",
            "the_end",
            0f, 0f);
        r.isBossRoom = true;
        for (com.hollowknight.model.enemy.Enemy e : r.enemies)
            if (e instanceof FalseKnight fk) falseKnight = fk;
        rooms.put(r.id, r);
        return r;
    }
    public boolean switchRoom(String id, float px, float py) {
        Room next = rooms.get(id);
        if (next == null) return false;
        currentRoom.resetEnemies();
        currentRoom = next;
        return true;
    }
}
