package com.hollowknight.model.world;

import com.badlogic.gdx.math.Rectangle;

public class WaterWalkZone {
    public float x, y, w, h;

    public WaterWalkZone(float x, float y, float w, float h) {
        this.x = x; this.y = y; this.w = w; this.h = h;
    }

    public Rectangle getBounds() { return new Rectangle(x, y, w, h); }
}
