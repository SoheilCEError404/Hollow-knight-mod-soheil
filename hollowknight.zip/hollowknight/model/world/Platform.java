package com.hollowknight.model.world;

import com.badlogic.gdx.math.Rectangle;

public class Platform {

    public enum Type {
        SOLID,
        ONE_WAY,
        MOVING
    }

    public float x, y, w, h;
    public Type  type;
    public float moveSpeedX = 0, moveSpeedY = 0;
    public float minX, maxX, minY, maxY;
    private int moveDir = 1;
    public Platform(float x, float y, float w, float h, Type type) {
        this.x = x; this.y = y; this.w = w; this.h = h;
        this.type = type;
    }
    public void update() {
        if (type != Type.MOVING) return;
        x += moveSpeedX * moveDir;
        if (x >= maxX) { x = maxX; moveDir = -1; }
        if (x <= minX) { x = minX; moveDir =  1; }
    }

    public Rectangle getBounds() { return new Rectangle(x, y, w, h); }

    public float top()    { return y + h; }
    public float right()  { return x + w; }
}
