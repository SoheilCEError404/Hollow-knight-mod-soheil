package com.hollowknight.model.world;

import com.badlogic.gdx.math.Rectangle;
public class BreakableWall {

    public float x, y, w, h;
    public int hp = 5;// تعداد ضربه‌ی لازم(hp wall)
    public boolean broken = false;
    public int hitCooldown = 0;
    public Platform platform;//solid

    public BreakableWall(float x, float y, float w, float h) {
        this.x = x; this.y = y; this.w = w; this.h = h;
    }
    public Rectangle getBounds() {
        return new Rectangle(x, y, w, h);
    }
}
