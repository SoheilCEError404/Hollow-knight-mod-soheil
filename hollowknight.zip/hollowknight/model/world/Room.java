package com.hollowknight.model.world;

import com.hollowknight.model.enemy.Enemy;

import java.util.ArrayList;
import java.util.List;
import com.badlogic.gdx.maps.tiled.TiledMap;
public class Room {

    public final String id;
    public final String environment;
    public TiledMap tiledMap = null;
    //camera
    public float boundsX, boundsY, boundsW, boundsH;
    //physics
    public final List<Platform> platforms = new ArrayList<>();
    public final List<Hazard>   hazards   = new ArrayList<>();
    public final List<WaterWalkZone> waterWalkZones = new ArrayList<>();
    // Entities
    public final List<Enemy>    enemies   = new ArrayList<>();
    public final List<BreakableWall> breakableWalls = new ArrayList<>();
    //zote
    public float zoteHomeX, zoteHomeY;
    public boolean hasZote       = false;
    public float   zoteX, zoteY;
    public int     zoteDialogueIndex = 0;
    public int   zoteAngryTimer  = 0;
    public int   zoteHitCooldown = 0;
    public int   zoteAttackTick  = 0;
    public float zoteFacing      = 1;
    // Boss room flag
    public boolean isBossRoom    = false;
    public float spawnX, spawnY;
    //portal
    public static class Portal {
        public float x, y, w, h;
        public String targetRoomId;
        public float  targetX, targetY;
        public Portal(float x, float y, float w, float h,
                      String targetRoomId, float tx, float ty) {
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.targetRoomId = targetRoomId;
            this.targetX = tx; this.targetY = ty;
        }
    }
    public final List<Portal> portals = new ArrayList<>();
    public Room(String id, String environment,
                float bx, float by, float bw, float bh) {
        this.id = id;
        this.environment = environment;
        this.boundsX = bx; this.boundsY = by;
        this.boundsW = bw; this.boundsH = bh;
    }
    public void resetEnemies() {
        for (Enemy e : enemies) e.respawn();
    }
    public void update(float px, float py) {
        for (Platform plat : platforms) plat.update();
        for (Enemy    e : enemies)   e.update(px, py);
    }
}
