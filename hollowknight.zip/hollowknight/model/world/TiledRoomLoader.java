package com.hollowknight.model.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.model.enemy.fixed.CrystalGuardian;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.flying.FlyingEnemyFactory;
import com.hollowknight.model.enemy.ground.GroundEnemyFactory;
import com.hollowknight.model.enemy.fixed.HuskHornhead;
import com.hollowknight.model.enemy.boss.FalseKnight;

public final class TiledRoomLoader {

    private static final String OBJECT_LAYER = "Object Layer 1";

    private TiledRoomLoader() {}
    public static Room load(String roomId, String environment, String tmxPath, String nextRoomId, float  nextSpawnX, float  nextSpawnY) {
    //load tiled
        TiledMap map;
        try {
            map = new TmxMapLoader().load(tmxPath);
        }catch (Exception e) {
            e.printStackTrace();
            return new Room(roomId, environment, 0, 0, 960, 540);
        }
        MapProperties mp = map.getProperties();
        float mapW = mp.get("width",      Integer.class) * mp.get("tilewidth",  Integer.class);
        float mapH = mp.get("height",     Integer.class) * mp.get("tileheight", Integer.class);
        Gdx.app.log("TiledRoomLoader", "mapW=" + mapW + " mapH=" + mapH);

        Room room = new Room(roomId, environment, 0, 0, mapW, mapH);
        room.tiledMap = map;
        MapLayer layer = map.getLayers().get(OBJECT_LAYER);
        if (layer == null) {
            return room;
        }

        for (MapObject obj : layer.getObjects()) {
            String cls = classOf(obj);
            Gdx.app.log("TiledRoomLoader", "Processing: class='" + cls + "' name='" + obj.getName() + "'");

            switch (cls) {
                case "floor"            -> addFloor(room, obj, mapH);
                case "climb"            -> addClimb(room, obj, mapH);
                case "is dead"          -> addHazard(room, obj, mapH);
                case "walk in water"    -> addWaterWalk(room, obj, mapH);
                case "brokable wall" -> addBreakableWall(room, obj, mapH);
                case "turn to next map",
                     "end map2","End game" -> addPortal(room, obj, mapH,
                    nextRoomId, nextSpawnX, nextSpawnY);
                case "start player",
                     "start spawn player",
                     "start spawn" -> {
                    setSpawn(room, obj, mapH);
                    Gdx.app.log("TiledRoomLoader", "SpawnX=" + room.spawnX + " SpawnY=" + room.spawnY);
                }
                case "false knight spawn" -> addFalseKnight(room, obj, mapH);
                case "laser enemy",
                     "guardian"         -> addLaserEnemy(room, obj, mapH);
            case "Crystal Crawler enemy" -> addCrawler(room, obj, mapH);
                case "Crystallized enemy"    -> addCrystallized(room, obj, mapH);
                case "Mosscreep enemy"  -> addMosscreep(room, obj, mapH);
                case "Mosquito"         -> addMosquito(room, obj, mapH);
            case "advicer"          -> addAdvicer(room, obj, mapH);
            default -> Gdx.app.log("TiledRoomLoader",
                    "  ↳ no handler for class '" + cls + "' — skipped");

            }
        }

        Gdx.app.log("TiledRoomLoader",
            roomId + " loaded: " + room.platforms.size() + " platforms, "
                + room.hazards.size() + " hazards, "
                + room.waterWalkZones.size() + " water zones, "
                + room.portals.size() + " portals, "
                + room.enemies.size() + " enemies.");
        return room;
    }
    private static String classOf(MapObject obj) {
        MapProperties p = obj.getProperties();
        String v = p.get("type",  String.class);
        if (v == null || v.isEmpty()) v = p.get("class", String.class);
        if (v == null || v.isEmpty()) v = obj.getName();  // ← fallback به Name
        return v == null ? "" : v.trim();
    }
    private static Rectangle rectOf(MapObject obj) {
        MapProperties p = obj.getProperties();
        Float x = p.get("x",      Float.class);
        Float y = p.get("y",      Float.class);
        Float w = p.get("width",  Float.class);
        Float h = p.get("height", Float.class);
        if (x == null || y == null) return null;
        return new Rectangle(x, y,
            w != null ? w : 32f,
            h != null ? h : 32f);
    }
    private static float toGameY(float tiledY, float objH, float mapH) {
        return tiledY;
    }
    private static void addFloor(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.platforms.add(new Platform(
            r.x, toGameY(r.y, r.height, mapH), r.width, r.height,
            Platform.Type.SOLID));
    }
    private static void addClimb(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.platforms.add(new Platform(
            r.x, toGameY(r.y, r.height, mapH), r.width, r.height,
            Platform.Type.ONE_WAY));
    }

    private static void addHazard(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.hazards.add(new Hazard(
            r.x, toGameY(r.y, r.height, mapH), r.width, r.height));
    }

    private static void addWaterWalk(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        float y = toGameY(r.y, r.height, mapH);
        //sfx bound
        room.waterWalkZones.add(new WaterWalkZone(r.x, y, r.width, r.height));
        float sink = 6f;
        float surfaceTop = y + r.height - sink;
        room.platforms.add(new Platform(
            r.x, surfaceTop - 12f, r.width, 12f,
            Platform.Type.ONE_WAY));
    }
    private static void addBreakableWall(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        float gy = toGameY(r.y, r.height, mapH);
        BreakableWall bw = new BreakableWall(r.x, gy, r.width, r.height);
        bw.platform = new Platform(r.x, gy, r.width, r.height, Platform.Type.SOLID);
        room.platforms.add(bw.platform);
        room.breakableWalls.add(bw);
    }
    private static void addPortal(Room room, MapObject obj, float mapH,
                                  String targetRoom, float targetX, float targetY) {
        if (targetRoom == null) return;
        Rectangle r = rectOf(obj);
        if (r == null) return;

        Float w = obj.getProperties().get("width", Float.class);
        boolean isPoint = (w == null || w == 0f);

        if (isPoint) {
            room.portals.add(new Room.Portal(
                r.x - 24f, r.y - 100f, 48f, 200f,
                targetRoom, targetX, targetY));
        } else {
            room.portals.add(new Room.Portal(
                r.x, r.y, r.width, r.height,
                targetRoom, targetX, targetY));
        }
    }

    private static void setSpawn(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.spawnX = r.x;
        room.spawnY = r.y;
    }

    private static void addLaserEnemy(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.enemies.add(new CrystalGuardian(
            r.x, toGameY(r.y, r.height, mapH)));
    }
    private static void addMosscreep(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.enemies.add(GroundEnemyFactory.create(
            GameConfig.ENV_GREENPATH,
            r.x, toGameY(r.y, r.height, mapH)));
    }

    private static void addMosquito(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.enemies.add(FlyingEnemyFactory.create(
            GameConfig.ENV_FORGOTTEN_CROSSROADS,
            r.x, toGameY(r.y, r.height, mapH)));
    }
    private static void addCrystallized(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.enemies.add(new HuskHornhead(r.x, toGameY(r.y, r.height, mapH)));
    }
    private static void addAdvicer(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.hasZote = true;
        room.zoteX   = r.x;
        room.zoteY   = toGameY(r.y, r.height, mapH);
        room.zoteHomeX = room.zoteX;
        room.zoteHomeY = room.zoteY;
    }
    private static void addCrawler(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        room.enemies.add(GroundEnemyFactory.create(
            GameConfig.ENV_CRYSTAL_PEAKS,
            r.x, toGameY(r.y, r.height, mapH)));
    }
    private static void addFalseKnight(Room room, MapObject obj, float mapH) {
        Rectangle r = rectOf(obj);
        if (r == null) return;
        float fx = r.x;
        float fy = r.y;
        room.enemies.add(new FalseKnight(fx, fy, fx - 300f, fx + 300f));
        room.isBossRoom = true;
    }
}
