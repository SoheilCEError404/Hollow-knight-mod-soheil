package com.hollowknight.model.system;

import com.badlogic.gdx.Gdx;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.GameState;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SaveManager {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    public static class SaveData {
        public int     slot;
        public String  currentRoomId;
        public float   playerX, playerY;
        public int     masks, maxMasks, soul;
        public int     deaths, enemiesKilled;
        public long    playtimeSeconds;
        public boolean[] achievements;
        public String  timestamp;
        public int     completionPercent;
        public boolean valid = true;
    }
    private String filePath(int slot) {
        return Gdx.files.local(GameConfig.SAVE_FILE_PREFIX + slot + ".json").file().getAbsolutePath();
    }
    public boolean save(int slot, GameState gs) {
        SaveData data = new SaveData();
        data.slot          = slot;
        data.currentRoomId = gs.getLevel().currentRoom.id;
        data.playerX       = gs.getPlayer().x;
        data.playerY       = gs.getPlayer().y;
        data.masks         = gs.getPlayer().masks;
        data.maxMasks      = gs.getPlayer().maxMasks;
        data.soul          = gs.getPlayer().soul;
        data.deaths        = gs.getPlayer().deaths;
        data.enemiesKilled = gs.getPlayer().enemiesKilled;
        data.playtimeSeconds = gs.getElapsedSeconds();
        data.achievements  = gs.getAchievements().toArray();
        data.completionPercent = gs.bossDefeated
                ? 100 : Math.min(90, gs.getPlayer().enemiesKilled * 3);
        data.timestamp     = java.time.LocalDateTime.now().toString();

        try (FileWriter w = new FileWriter(filePath(slot))) {
            gson.toJson(data, w);
            return true;
        } catch (IOException e) {
            Gdx.app.error("SaveManager", "Save failed: " + e.getMessage());
            return false;
        }
    }

    public SaveData load(int slot) {
        try (FileReader r = new FileReader(filePath(slot))) {
            return gson.fromJson(r, SaveData.class);
        } catch (IOException e) {
            return null;  // slot empty
        }
    }
    public SaveData[] loadAllSlots() {
        SaveData[] all = new SaveData[GameConfig.SAVE_SLOTS];
        for (int i = 0; i < GameConfig.SAVE_SLOTS; i++) all[i] = load(i);
        return all;
    }
}
