package com.hollowknight.model.system;

import com.badlogic.gdx.Gdx;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class AccountManager {

    public static class Account {
        public String username;
        public String email;
        public String passwordHash;
    }
    private static final String FILE_NAME = "hk_accounts.json";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private List<Account> accounts = new ArrayList<>();

    public AccountManager() { load(); }
    public boolean signUp(String username, String email, String password) {
        if (username == null || username.isBlank() || password == null || password.isBlank())
            return false;
        if (usernameExists(username)) return false;

        Account a = new Account();
        a.username     = username;
        a.email        = email == null ? "" : email;
        a.passwordHash = hash(password);
        accounts.add(a);
        save();
        return true;
    }
    public boolean login(String username, String password) {
        if (username == null || password == null) return false;
        String hashed = hash(password);
        for (Account account : accounts) {
            if (account.username.equalsIgnoreCase(username) && account.passwordHash.equals(hashed))
                return true;
        }
        return false;
    }

    public boolean usernameExists(String username) {
        for (Account account : accounts)
            if (account.username.equalsIgnoreCase(username)) return true;
        return false;
    }
    private String filePath() {
        return Gdx.files.local(FILE_NAME).file().getAbsolutePath();
    }
    /// ///
    private void load() {
        try (FileReader reader = new FileReader(filePath())) {
            Type listType = new TypeToken<List<Account>>() {}.getType();
            List<Account> loaded = gson.fromJson(reader, listType);
            accounts = loaded != null ? loaded : new ArrayList<>();
        } catch (Exception e) {
            accounts = new ArrayList<>();  // no file yet — first run
        }
    }

    private void save() {
        try (FileWriter writer = new FileWriter(filePath())) {
            gson.toJson(accounts, writer);
        } catch (Exception e) {
            Gdx.app.error("AccountManager", "save failed: " + e.getMessage());
        }
    }
    private String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            //non
            return input;
        }
    }
}
