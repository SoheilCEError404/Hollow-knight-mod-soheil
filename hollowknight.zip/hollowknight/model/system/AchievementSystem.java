package com.hollowknight.model.system;

import java.util.LinkedHashMap;
import java.util.Map;

public class AchievementSystem {
    public boolean[] toArray() {
        boolean[] arr = new boolean[achievements.size()];
        int i = 0;
        for (Achievement a : achievements.values()) arr[i++] = a.unlocked;
        return arr;
    }
    public void fromArray(boolean[] arr) {
        int i = 0;
        for (Achievement a : achievements.values()) {
            if (i < arr.length) a.unlocked = arr[i++];
        }
    }
    public static class Achievement {
        public final String id;
        public final String name;
        public final String description;
        public boolean unlocked = false;
        public int popupTimer   = 0;
        public Achievement(String id, String name, String desc) {
            this.id = id; this.name = name; this.description = desc;
        }
    }

    private final Map<String, Achievement> achievements = new LinkedHashMap<>();
    public interface Listener { void onUnlocked(Achievement a); }
    private Listener listener;
    public AchievementSystem() {
        register("completion",   "True Ending",        "Defeat False Knight.");
        register("speedrun",     "Speedrunner",        "Complete the game in under 20 minutes.");
        register("true_hunter",  "True Hunter",        "Defeat 50 enemies.");
        register("false_knight", "Defeat False Knight","Beat the False Knight boss.");
        register("pacifist",     "Pacifist",           "Reach the boss without killing enemies.");
    }

    private void register(String id, String name, String desc) {
        achievements.put(id, new Achievement(id, name, desc));
    }

    public void unlock(String id) {
        Achievement achievement = achievements.get(id);
        if (achievement == null || achievement.unlocked) return;
        achievement.unlocked   = true;
        achievement.popupTimer = 300; // 5 second in 60 fps
        if (listener != null) listener.onUnlocked(achievement);
    }

    public Map<String, Achievement> getAll() { return achievements; }
    public void updatePopups() {
        for (Achievement achievement : achievements.values())
            if (achievement.popupTimer > 0) achievement.popupTimer--;
    }
    public Achievement activePopup() {
        for (Achievement achievement : achievements.values())
            if (achievement.popupTimer > 0) return achievement;
        return null;
    }

}
