package com.hollowknight.model.item;
public enum CharmType {

    SOUL_CATCHER       ("Soul Catcher",         1, "Gain extra Soul per nail hit."),
    DASHMASTER         ("Dashmaster",           1, "Shorter cooldown between dashes."),
    UNBREAKABLE_STRENGTH("Unbreakable Strength",2, "Nail deals 50% more damage."),
    QUICK_SLASH        ("Quick Slash",          2, "Attack speed greatly increased."),
    QUICK_FOCUS        ("Quick Focus",          1, "Heal 40% faster."),
    HEAVY_BLOW         ("Heavy Blow",           2, "Enemies knocked back further. (optional)"),
    SHARP_SHADOW       ("Sharp Shadow",         2, "Dash through enemies to deal damage. (optional)"),
    VOID_HEART         ("Void Heart",           1, "Spells deal 50% more damage; enhanced animations. (optional)");

    public final String name;
    public final int notchCost;
    public final String description;

    CharmType(String name, int notchCost, String description) {
        this.name = name;
        this.notchCost = notchCost;
        this.description = description;
    }
}
