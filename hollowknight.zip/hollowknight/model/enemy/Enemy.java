package com.hollowknight.model.enemy;

import com.badlogic.gdx.math.Rectangle;

/**
 * MVC – Model layer.
 * All concrete enemies extend this.
 */
public abstract class Enemy {
    public float x, y;
    public float velX, velY;
    public float width, height;
    public int  maxHp,hp;
    public int  damage          = 1;   // mask damage on contact
    public float knockbackForce = 5f;
    //state
    public boolean alive     = true;
    public boolean onGround  = false;
    public int facing    = 1;
    // 1 right,
    // -1 left
    public int hurtTimer = 0;
    public boolean isActive  = true;
    //spawn point
    public final float spawnX, spawnY;
    public float animTimer = 0f;
    protected Enemy(float x, float y, float w, float h, int hp) {
        this.x = x; this.y = y;
        this.spawnX = x; this.spawnY = y;
        this.width = w; this.height = h;
        this.maxHp = hp; this.hp = hp;
    }
    public final void update(float playerX, float playerY) {
        if (!alive || !isActive) return;
        if (hurtTimer > 0) hurtTimer--;
        updateAI(playerX, playerY);
    }
    protected abstract void updateAI(float px, float py);
    public boolean takeDamage(int damage,float srcX) {
        if (!alive) return false;
        hp -= damage;
        hurtTimer = 10;
        if (hp <= 0) {
            hp = 0;//die
            die();
        }
        //knockback
        float kbDir = (x > srcX) ? 1f : -1f;
        velX = kbDir * knockbackForce;
        return true;
    }

    protected void die() {
        alive = false;
    }
    public void respawn() {
        x = spawnX; y = spawnY;
        hp = maxHp;
        alive = true;
        velX = velY = 0;
        onRespawn();
    }
    protected void onRespawn() {}
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
    public Rectangle getContactBounds() {
        float shrink = 4f;
        return new Rectangle(x + shrink, y + shrink, width - shrink * 2, height - shrink * 2);
    }
}
