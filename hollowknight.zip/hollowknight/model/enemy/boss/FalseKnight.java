package com.hollowknight.model.enemy.boss;

import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.Enemy;
import com.badlogic.gdx.math.Rectangle;
import java.util.Random;
public class FalseKnight extends Enemy {
    //false_knight
    public enum FKState {
        IDLE, MACE_SLAM, CHARGE_RUN, OFFENSIVE_LEAP,
        DEFENSIVE_LEAP, POWER_MACE_SLAM, STUNNED, DEAD
    }
    private final Random random = new Random();
    public FKState fkState = FKState.IDLE;
    public boolean phase2 = false;
    private boolean phase2Triggered = false;
    //time
    private int  stateTimer = 0;
    private int  decisionCooldown = 0;
    private int  stunTimer = 0;
    private int recentHits = 0;
    private int recentHitWindow = 0;
    private FKState lastMove = null;
    private int repeatCount = 0;
    private static final int CHARGE_DURATION = 60;
    private float leapTargetX;
    //wave
    public boolean slamImpact       = false;
    public boolean powerSlamImpact  = false;
    // map_bound
    public float arenaLeft,arenaRight;
    public static final float W = 60f, H = 70f;
    public FalseKnight(float x, float y, float arenaLeft, float arenaRight) {
        super(x, y, W, H, GameConfig.HP_FALSE_KNIGHT);
        this.arenaLeft = arenaLeft;
        this.arenaRight = arenaRight;
        this.damage = 2;
        this.knockbackForce = 0f;
    }
    @Override
    protected void updateAI(float px, float py) {
        if (!alive) return;
        slamImpact = false;
        powerSlamImpact = false;
        if (recentHitWindow > 0) recentHitWindow--;
        else recentHits = 0;
        checkPhase2Trigger();
        if (fkState == FKState.STUNNED) {
            updateStunned();
            return;
        }
        if (decisionCooldown > 0) decisionCooldown--;
        updateCurrentState(px, py);
    }

    private void checkPhase2Trigger() {
        if (!phase2Triggered && hp <= GameConfig.HP_FALSE_KNIGHT / 2) {
            phase2Triggered = true;
            enterStun();
        }
    }

    private void updateCurrentState(float px,float py) {
        switch (fkState) {
            case IDLE           -> handleIdle(px,py);
            case MACE_SLAM      -> handleMaceSlam(px,py);
            case CHARGE_RUN     -> handleChargeRun(px,py);
            case OFFENSIVE_LEAP -> handleOffensiveLeap(px,py);
            case DEFENSIVE_LEAP -> handleDefensiveLeap(px,py);
            case POWER_MACE_SLAM-> handlePowerMaceSlam(px,py);
        }
        //gravity
        if (!onGround) velY = Math.max(velY - 0.55f, -18f);
    }

    private void handleIdle(float px, float py) {
        velX = 0;
        facing = (px > x) ? 1 : -1;
        if (decisionCooldown <= 0) decideNextMove(px,py);
    }

    //1
    private void handleMaceSlam(float px, float py) {
        stateTimer--;
        velX = 0;
        if (stateTimer == 20) {
            // Wind_up-->slam
            slamImpact = true;
            // Shockwave
        }
        if (stateTimer <= 0) returnToIdle();
    }
    //2
    private void handleChargeRun(float px, float py) {
        stateTimer--;
        float speed = GameConfig.FK_CHARGE_SPEED * (phase2 ? GameConfig.FK_PHASE2_SPEED_MULT : 1f);
        velX = facing * speed;
        if (x     <= arenaLeft  + 10) { velX = 0; returnToIdle(); }
        if (x + W >= arenaRight - 10) { velX = 0; returnToIdle(); }
        if (stateTimer <= 0) returnToIdle();
    }
    //3
    private void handleOffensiveLeap(float px, float py) {
        stateTimer--;
        if (stateTimer == 44) {
            facing = (px > x) ? 1 : -1;
            velY = 14f;
            velX = facing * 4.5f;
            leapTargetX = px;
        }
        if (onGround && stateTimer < 40) returnToIdle();
        if (stateTimer <= 0) returnToIdle();
    }
    //4
    private void handleDefensiveLeap(float px, float py) {
        stateTimer--;
        if (stateTimer == 44) {
            velY = 12f;
            velX = -facing * 5f;
        }
        if (onGround && stateTimer < 40) returnToIdle();
        if (stateTimer <= 0) returnToIdle();
    }
    //5
    private void handlePowerMaceSlam(float px, float py) {
        stateTimer--;
        velX = 0;
        if (stateTimer == 60) velY = 10f;          //increase height jump
        if (onGround && stateTimer < 55) {         //fall
            powerSlamImpact = true;                //wave
            returnToIdle();
        }
        if (stateTimer <= 0) returnToIdle();
    }

    //AI(liner decision)
    private void decideNextMove(float px, float py) {
        float distance = Math.abs(px - (x + W / 2f));
        FKState chosen = pickMove(distance);
        if (chosen == lastMove) {
            repeatCount++;
            if (repeatCount >= 2) {
                chosen = forceDifferentMove(chosen, distance);
                repeatCount = 0;
            }
        }
        else repeatCount = 0;
        lastMove = chosen;//remove fake loop
        enterMove(chosen);
    }

    private FKState pickMove(float distance) {
        float random = this.random.nextFloat();
        if (phase2 && this.random.nextFloat() < 0.28f) return FKState.POWER_MACE_SLAM;
        if (distance < GameConfig.FK_NEAR_THRESHOLD) {
            if (random < 0.60f) return FKState.MACE_SLAM;
            if (random < 0.80f) return FKState.CHARGE_RUN;
            return FKState.DEFENSIVE_LEAP;
        }
        else if (distance < GameConfig.FK_FAR_THRESHOLD) {
            if (random < 0.40f) return FKState.CHARGE_RUN;
            if (random < 0.70f) return FKState.OFFENSIVE_LEAP;
            return FKState.MACE_SLAM;
        } else {
            if (random < 0.60f) return FKState.CHARGE_RUN;
            return FKState.OFFENSIVE_LEAP;
        }
    }

    private FKState forceDifferentMove(FKState avoid, float dist) {
        FKState[] options = {
            FKState.MACE_SLAM, FKState.CHARGE_RUN,
            FKState.OFFENSIVE_LEAP, FKState.DEFENSIVE_LEAP
        };
        for (FKState m : options) if (m != avoid) return m;
        return FKState.MACE_SLAM;
    }

    private void enterMove(FKState move) {
        fkState = move;
        decisionCooldown = (int)(GameConfig.FK_MIN_DECISION_CD * (phase2 ? 0.75f : 1f));
        facing = 1;

        stateTimer = switch (move) {
            case MACE_SLAM       -> 50;
            case CHARGE_RUN      -> CHARGE_DURATION;
            case OFFENSIVE_LEAP  -> 60;
            case DEFENSIVE_LEAP  -> 55;
            case POWER_MACE_SLAM -> 70;
            default              -> 30;
        };
    }

    private void returnToIdle() {
        fkState = FKState.IDLE;
        velX = 0;
        decisionCooldown = (int)(GameConfig.FK_MIN_DECISION_CD * (phase2 ? 0.75f : 1f));
    }

    //stun
    private void enterStun() {
        fkState = FKState.STUNNED;
        stunTimer  = GameConfig.FK_STUN_DURATION;
        velX = velY = 0;
    }

    private void updateStunned() {
        velX = 0;
        if (--stunTimer <= 0) {
            phase2   = true;    //increase speed
            fkState  = FKState.IDLE;
            decisionCooldown = 20;
        }
    }
    //damage
    @Override
    public boolean takeDamage(int damage, float srcX) {
        if (!alive) return false;
        //stun state damaging
        if (fkState == FKState.STUNNED) damage *= 2;
        hp -= damage;
        hurtTimer = 8;
        if (hp <= 0) { hp = 0; alive = false; fkState = FKState.DEAD; return true; }
        recentHits++;
        recentHitWindow = 90;//1.5second
        boolean canLeap = fkState == FKState.IDLE || fkState == FKState.MACE_SLAM;
        if (recentHits >= 3 && canLeap) {           //3 attack and the run back
            recentHits = 0;
            enterMove(FKState.DEFENSIVE_LEAP);
        } else if (canLeap && random.nextFloat() < 0.15f) {
            enterMove(FKState.DEFENSIVE_LEAP);
        }
        return true;
    }
    public boolean isVulnerable() {
        return fkState == FKState.STUNNED;
    }
    public float getMaceCenterX() { return x + W / 2f; }
    public Rectangle getSlamBounds() {
        float w = 74f, h = 42f;
        float sx = facing > 0 ? x + W : x - w;
        return new Rectangle(sx, y, w, h);
    }
    public Rectangle getVulnerableBounds() {
        return new Rectangle(x + W / 2f - 14f, y + H - 36f, 28f, 32f);
    }
}
