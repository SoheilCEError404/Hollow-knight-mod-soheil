package com.hollowknight.model.enemy.boss;

import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.config.GameConfig;
public class Shockwave {
    public static final float W = 40f, H = 45f;

    public float x,y;
    public float speed = GameConfig.FK_WAVE_START_SPEED;
    public final int dir;
    public final int damage = GameConfig.FK_WAVE_DAMAGE;
    public boolean alive = true;
    private int life  = 240;

    public Shockwave(float x, float y, int dir) {
        this.x = x; this.y = y; this.dir = dir;
    }
    public void update() {
        if (!alive) return;
        speed += GameConfig.FK_WAVE_ACCEL;//increase step by step
        x += dir * speed;
        if (--life <= 0) alive = false;
    }
    public Rectangle getBounds() { return new Rectangle(x, y, W, H); }
}
