package com.hollowknight.model.enemy.ground;

import com.hollowknight.config.GameConfig;

class Crawlid extends GroundEnemy {
    public Crawlid(float x, float y) {
        super(x, y, 40, 36, GameConfig.HP_CRAWLID, 1.4f);
    }
}

class Mosscreep extends GroundEnemy {
    public Mosscreep(float x, float y) {
        super(x, y, 40, 36, GameConfig.HP_MOSSCREEP, 1.8f);
    }
}

class CrystalCrawler extends GroundEnemy {
    public CrystalCrawler(float x, float y) {
        super(x, y, 28, 18, GameConfig.HP_CRYSTAL_CRAWLER, 2.6f);
    }
}

public final class GroundEnemyFactory {
    public static GroundEnemy create(String envirinment, float x, float y) {
        return switch (envirinment) {
            case GameConfig.ENV_FORGOTTEN_CROSSROADS -> new Crawlid(x, y);
            case GameConfig.ENV_GREENPATH -> new Mosscreep(x, y);
            case GameConfig.ENV_CRYSTAL_PEAKS -> new CrystalCrawler(x, y);
            default -> new Crawlid(x,y);
        };
    }
}
