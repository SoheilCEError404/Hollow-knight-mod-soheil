package com.hollowknight.model.enemy.ground;

import com.hollowknight.model.enemy.Enemy;
public abstract class GroundEnemy extends Enemy {

    protected float speed;
    public boolean needsFlip = false;
    public int turnTimer = 0;
    private static final int TURN_FRAMES = 10;
    protected GroundEnemy(float x, float y, float w, float h, int hp, float speed) {
        super(x, y, w, h, hp);
        this.velX = speed;
        this.speed = speed;
        this.facing = 1;
    }

    @Override
    protected void updateAI(float px, float py) {
        if (needsFlip) {
            facing *= -1;
            velX = facing * speed;
            needsFlip = false;
            turnTimer = TURN_FRAMES;
        }
        // Gravity
        if (turnTimer > 0) turnTimer--;
        if (!onGround) velY = Math.max(velY - 0.55f, -15f);
    }

    @Override
    protected void onRespawn() {
        facing = 1;
        velX   = speed;
        needsFlip = false;
        turnTimer = 0;
    }
}
