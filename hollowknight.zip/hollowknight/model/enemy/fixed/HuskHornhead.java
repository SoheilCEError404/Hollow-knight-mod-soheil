package com.hollowknight.model.enemy.fixed;

import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.Enemy;
public class HuskHornhead extends Enemy {
    public int turnTimer = 0;
    private static final int TURN_FRAMES = 15;//3frame
    private enum State { PATROL, WAITING, CHARGING }
    private State state      = State.PATROL;
    private float patrolspeed = 1.5f;
    private float chargespeed = 7.5f;
    private int   waitTimer  = 0;
    private static final int WAIT_DURATION  = 60;
    private static final float SIGHT_RANGE  = 220f;

    public HuskHornhead(float x, float y) {
        super(x, y, 60, 68, GameConfig.HP_HUSK_HORNHEAD);
        this.damage = 2;
        velX = patrolspeed;
        facing = 1;
    }

    @Override
    protected void updateAI(float px, float py) {
        if (turnTimer > 0) turnTimer--;
        if (!onGround) velY = Math.max(velY - 0.55f, -15f);

        float distX = Math.abs(px - (x + width / 2f));

        switch (state) {
            case PATROL -> {
                velX = facing * patrolspeed;
                if (distX < SIGHT_RANGE && Math.abs(py - y) < 60f) {
                    state   = State.WAITING;
                    waitTimer = WAIT_DURATION;
                    velX    = 0;
                    facing  = (px > x) ? 1 : -1;
                }
            }
            case WAITING -> {
                velX = 0;
                if (--waitTimer <= 0) {
                    state = State.CHARGING;
                    velX  = facing * chargespeed;
                }
            }
            case CHARGING -> {
                //ignore here
            }
        }
    }
    public void forceFlip() {
        facing *= -1;
        state = State.PATROL;
        velX = facing * patrolspeed;
        turnTimer = TURN_FRAMES;
    }
    @Override
    protected void onRespawn() {
        state = State.PATROL;
        waitTimer = 0;
        facing = 1;
        velX = patrolspeed;
        turnTimer = 0;
    }
}
