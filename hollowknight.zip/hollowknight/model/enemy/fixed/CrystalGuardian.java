package com.hollowknight.model.enemy.fixed;

import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.Enemy;
public class CrystalGuardian extends Enemy {
    public enum CGState { WATCHING, LASER_CHARGING, LASER_FIRING, ENRAGED, COOLDOWN }

    public CGState cgState = CGState.WATCHING;

    // Timers
    private int chargeTimer  = 0;
    private int fireTimer    = 0;
    private int enrageTimer  = 0;
    private int cooldownTimer = 0;

    private static final int CHARGE_FRAMES   = 40;
    private static final int FIRE_FRAMES     = 20;
    private static final int ENRAGE_FRAMES   = 90;
    private static final int COOLDOWN_FRAMES = 70;
    private static final float SIGHT_RANGE   = 350f;
    private static final float ENRAGE_SPEED  = 4.5f;
    public boolean laserActive = false;
    public int laserFacing = 1;  //dir laser is fired

    public CrystalGuardian(float x, float y) {
        super(x, y, 80, 80, GameConfig.HP_CRYSTAL_GUARDIAN);
        this.damage = 2;
    }

    @Override
    protected void updateAI(float px, float py) {
        float distX = Math.abs(px - (x + width / 2f));
        laserActive = false;

        switch (cgState) {
            case WATCHING -> {
                velX = 0; velY = 0;
                facing = (px > x) ? 1 : -1;
                if (distX < SIGHT_RANGE && Math.abs(py - y) < 80f) {
                    cgState = CGState.LASER_CHARGING;
                    chargeTimer = CHARGE_FRAMES;
                    laserFacing = facing;
                }
            }
            case LASER_CHARGING -> {
                velX = 0;
                if (--chargeTimer <= 0) {
                    cgState   = CGState.LASER_FIRING;
                    fireTimer = FIRE_FRAMES;
                }
            }
            case LASER_FIRING -> {
                laserActive = true;
                if (--fireTimer <= 0) {
                    laserActive  = false;
                    cgState      = CGState.ENRAGED;
                    enrageTimer  = ENRAGE_FRAMES;
                }
            }
            case ENRAGED -> {
                velX = (px > x ? 1 : -1) * ENRAGE_SPEED;
                facing = (velX > 0) ? 1 : -1;
                if (--enrageTimer <= 0) {
                    cgState = CGState.COOLDOWN;
                    cooldownTimer = COOLDOWN_FRAMES;
                    velX = 0;
                }
            }
            case COOLDOWN -> {
                velX = 0;
                if (--cooldownTimer <= 0) cgState = CGState.WATCHING;
            }
        }
        if (!onGround) velY = Math.max(velY - 0.55f, -15f);
    }

    @Override
    protected void onRespawn() {
        cgState = CGState.WATCHING;
        laserActive = false;
        chargeTimer = fireTimer = enrageTimer = cooldownTimer = 0;
    }
}
