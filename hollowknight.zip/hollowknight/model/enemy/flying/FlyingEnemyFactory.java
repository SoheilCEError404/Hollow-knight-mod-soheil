package com.hollowknight.model.enemy.flying;

import com.hollowknight.config.GameConfig;
import com.hollowknight.model.enemy.Enemy;

//mosquito
class Mosquito extends FlyingEnemy {
    private float savedPX, savedPY;
    private int   attackDelay = 0;
    private boolean charging  = false;
    Mosquito(float x, float y) {
        super(x, y, 50, 50, GameConfig.HP_MOSQUITO, 200f);
        chaseSpd = 5f;
    }
    @Override
    protected void updateAI(float px, float py) {
        if (!aggroed) {
            if (distToPlayer(px, py) < aggroRange) { aggroed = true; }
            return;
        }
        if (charging) {
            float disted = distToPlayer(savedPX, savedPY);
            if (disted < 20f) { charging = false; attackDelay = 40; }
        } else {
            if (attackDelay > 0) { attackDelay--; velX = 0; velY = 0; return; }
            savedPX = px; savedPY = py;
            chasePlayer(savedPX, savedPY, chaseSpd);
            charging = true;
        }
    }
}

//mossfly
class Mossfly extends FlyingEnemy {
    private float shakeTimer = 0f;
    private boolean dormant  = true;
    Mossfly(float x, float y) {
        super(x, y, 18, 18, GameConfig.HP_MOSSFLY, 160f);
        chaseSpd = 2.8f;
    }
    @Override
    protected void updateAI(float px, float py) {
        if (dormant) {
            if (distToPlayer(px, py) < aggroRange) {
                dormant = false; shakeTimer = 30f;
            }
            return;
        }
        if (shakeTimer > 0) { shakeTimer--; velX = 0; velY = 0; return; }
        chasePlayer(px, py, chaseSpd);
        aggroed = true;
    }
}

//wingedsentry
class WingedSentry extends FlyingEnemy {
    private float savedY;
    private int   chargeDelay = 0;
    private boolean charging  = false;

    WingedSentry(float x, float y) {
        super(x, y, 22, 28, GameConfig.HP_WINGED_SENTRY, 180f);
        this.savedY = y;
        chaseSpd = 6.5f;
    }
    @Override
    protected void updateAI(float px, float py) {
        if (!aggroed) {
            if (distToPlayer(px, py) < aggroRange) aggroed = true;
            return;
        }
        if (charging) {
            float distance = Math.abs(x + width / 2 - px);
            if (distance < 16f) { charging = false; chargeDelay = 50; }
        }
        else {
            if (chargeDelay > 0) { chargeDelay--; velX = 0; velY = 0; return; }
            float dx = px - (x + width / 2f);
            velX = (dx > 0 ? 1 : -1) * chaseSpd;
            velY = 0;
            charging = true;
        }
    }
}

//crystal_hunter
class CrystalHunter extends FlyingEnemy {
    private int shootCooldown = 80;
    public boolean wantsToShoot = false;
    CrystalHunter(float x, float y) {
        super(x, y, 26, 26, GameConfig.HP_CRYSTAL_HUNTER, 220f);
        chaseSpd = 0;
    }
    @Override
    protected void updateAI(float px, float py) {
        velX = 0; velY = 0;  // stationary
        if (!aggroed) {
            if (distToPlayer(px, py) < aggroRange) aggroed = true;
            return;
        }
        facing = (px > x) ? 1 : -1;
        if (shootCooldown > 0) { shootCooldown--; wantsToShoot = false; return; }
        wantsToShoot  = true;
        shootCooldown = 80;
    }
}
public final class FlyingEnemyFactory {
    private FlyingEnemyFactory() {}
    public static FlyingEnemy create(String env, float x, float y) {
        return switch (env) {
            case GameConfig.ENV_FORGOTTEN_CROSSROADS -> new Mosquito(x, y);
            case GameConfig.ENV_GREENPATH  -> new Mossfly(x, y);
            case GameConfig.ENV_CITY_OF_TEARS -> new WingedSentry(x, y);
            case GameConfig.ENV_CRYSTAL_PEAKS -> new CrystalHunter(x, y);
            default -> new Mosquito(x, y);
        };
    }
}
