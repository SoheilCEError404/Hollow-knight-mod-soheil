package com.hollowknight.model.enemy.flying;

import com.hollowknight.model.enemy.Enemy;
public abstract class FlyingEnemy extends Enemy {
    protected float aggroRange;
    protected boolean aggroed  = false;
    protected float   chaseSpd = 2.0f;
    protected FlyingEnemy(float x, float y, float w, float h,int hp, float aggroRange) {
        super(x,y,w,h,hp);
        this.aggroRange = aggroRange;
    }
    protected float distToPlayer(float px, float py) {
        float dx = px - (x + width / 2f);
        float dy = py - (y + height / 2f);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }
    protected void chasePlayer(float px, float py, float speed) {
        float dx = px - (x + width / 2f);
        float dy = py - (y + height / 2f);
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > 0.1f) {
            velX = (dx / len) * speed;
            velY = (dy / len) * speed;
        }
    }
}
