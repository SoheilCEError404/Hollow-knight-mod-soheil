package com.hollowknight.model;

import com.hollowknight.model.player.Player;
import com.hollowknight.model.spell.HowlingWraithsEffect;
import com.hollowknight.model.spell.Projectile;
import com.hollowknight.model.system.AchievementSystem;
import com.hollowknight.model.world.Level;

import java.util.ArrayList;
import java.util.List;

public class GameState {
    private Player            player;
    private Level             level;
    private AchievementSystem achievements = new AchievementSystem();
    public final List<Projectile>          projectiles = new ArrayList<>();
    public final List<HowlingWraithsEffect> wraiths    = new ArrayList<>();
    private long startTimeMs  = System.currentTimeMillis();
    private long pausedTimeMs = 0;
    private long pauseStartMs = 0;
    private boolean paused    = false;
    public int activeSaveSlot = -1;
    public boolean bossDefeated = false;
    public GameState() {}
    public void init(Player player, Level level) {
        this.player       = player;
        this.level        = level;
        this.achievements = new AchievementSystem();
        projectiles.clear();
        wraiths.clear();
        resetTimer();
    }
    public Player getPlayer()       { return player; }
    public Level  getLevel()        { return level;  }
    public AchievementSystem getAchievements() { return achievements; }

    //time
    public void resetTimer() {
        startTimeMs  = System.currentTimeMillis();
        pausedTimeMs = 0;
    }

    public void onPause() {
        if (!paused) { paused = true; pauseStartMs = System.currentTimeMillis(); }
    }

    public void onResume() {
        if (paused) {
            paused = false;
            pausedTimeMs += System.currentTimeMillis() - pauseStartMs;
        }
    }

    public long getElapsedSeconds() {
        long elapsed = System.currentTimeMillis() - startTimeMs - pausedTimeMs;
        if (paused) elapsed -= System.currentTimeMillis() - pauseStartMs;
        return elapsed / 1000L;
    }

    ///spell
    public void spawnProjectile(float x, float y, int facing) {
        projectiles.add(new Projectile(x, y, facing));
    }
    public void spawnHowlingWraiths() {
        wraiths.add(new HowlingWraithsEffect(player.x, player.y, player.W, player.H));
    }
    public void updateSpells() {
        // Vengeful_Spirit
        projectiles.removeIf(p -> { p.update(); return !p.alive; });
        // Howling_Wraiths
        wraiths.removeIf(w -> !w.alive);
    }
}
