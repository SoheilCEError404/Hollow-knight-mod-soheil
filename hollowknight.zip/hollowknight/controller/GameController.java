package com.hollowknight.controller;

import com.badlogic.gdx.math.Rectangle;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.GameState;
import com.hollowknight.model.enemy.Enemy;
import com.hollowknight.model.enemy.boss.FalseKnight;
import com.hollowknight.model.enemy.fixed.CrystalGuardian;
import com.hollowknight.model.enemy.ground.GroundEnemy;
import com.hollowknight.model.player.Player;
import com.hollowknight.model.player.PlayerState;
import com.hollowknight.model.spell.HowlingWraithsEffect;
import com.hollowknight.model.spell.Projectile;
import com.hollowknight.model.world.Hazard;
import com.hollowknight.model.world.Platform;
import com.hollowknight.model.world.Room;
import com.hollowknight.model.world.WaterWalkZone;
import com.hollowknight.model.enemy.fixed.HuskHornhead;
import com.hollowknight.model.world.BreakableWall;
import com.hollowknight.model.enemy.boss.Shockwave;
import java.util.List;

public class GameController {

    private final GameState gameState;
    private final InputHandler input;
    private final AudioManager audio;
    private final CheatManager cheat;
    private int  waterStepTimer = 0;
    private boolean inWaterLast = false;
    private static final int DEATH_ANIMATION_FRAMES = 120;   //you died png view for 2 seconds

    //Interface_Callback ---> GameScreen can react to change state(screen) requests
    public interface GameEventListener {
        void onPlayerDead();
        void onBossDefeated();
        void onRoomTransition(String roomId, float tx, float ty);
        void onPauseRequested();
        void onInventoryRequested();
        void onCheatActivated(String msg);
    }
    private GameEventListener listener;
    //Zote_dialouge
    private static final String[] ZOTE_LINES = {
        "hi soheyl im zote ai voice",
        "please kill every enemies",
        "Good Luck!",
    };
    private static final String[] ZOTE_PRECEPTS = {//غرغر هاش
        "Precept One: Always Win Your Battles.",
        "Precept Two: Never Let Them Laugh at You.",
        "Precept Three: Always Be Rested.",
        "Precept Four: Forget Your Past.",
        "Precept Five: Strength Beats Strength.",
        "Precept Six: Choose Your Own Fate.",
        "Precept Seven: Mourn Not the Dead.",
        "Precept Eight: Travel Alone.",
    };
    public String activeDialogue = null;
    public  boolean inDialogue        = false;
    public  int dialogueCharCount = 0;
    public  boolean playerNearZote    = false; // برای راهنمای [UP] Talk
    private int     dialogueLine = 0;
    private int dialogueCalmdown = 0;
    private float   typewriterTimer = 0f;
    private static final float CHARS_PER_SEC = 40f;
    private final java.util.Random zoteRng = new java.util.Random();
    public final java.util.List<Shockwave> waves = new java.util.ArrayList<>();
    ///
    ///
    public GameController(GameState gameState, InputHandler input,
                          AudioManager audio, CheatManager cheat) {
        this.gameState = gameState;
        this.input = input;
        this.audio = audio;
        this.cheat = cheat;
    }

    public void setListener(GameEventListener l) { this.listener = l; }

    private int deathFrameCounter = -1;
    public void update() {
        input.snapshot();

        String cheatMsg = cheat.update(gameState);
        if (cheatMsg != null && listener != null) listener.onCheatActivated(cheatMsg);

        Player player = gameState.getPlayer();
        if (player == null) return;

        gameState.getAchievements().updatePopups();
        resolveWaterWalk(gameState.getPlayer());

        if (player.state == PlayerState.DEAD) {
            if (deathFrameCounter < 0) {
                deathFrameCounter = 0;
                audio.playSfx(AudioManager.SFX_DEATH);
            }
            deathFrameCounter++;
            if (deathFrameCounter >= DEATH_ANIMATION_FRAMES) {
                deathFrameCounter = -1;
                if (listener != null) listener.onPlayerDead();
            }
            return;
        }

        if (cheat.noclipEnabled) cheat.applyNoclipMovement(player);
        else {
            processInput(player);
            player.update();
            resolvePhysics(player);
        }

        //spells
        handlePendingSpells(player);
        gameState.updateSpells();
        resolveProjectileCollisions();
        resolveWraithCollisions();

        // Enemy time
        Room room = gameState.getLevel().currentRoom;
        room.update(player.x + player.W / 2f, player.y + player.H / 2f);
        resolveEnemyPhysics();

        // Enemy_contact_damage
        resolveEnemyContact(player);
        updateFalseKnightAttacks(gameState.getPlayer());

        // Hazard_contact(traps,blade,..)
        resolveHazardContact(player);

        // Room_portals
        checkPortals(player);

        // Nail_enemies
        if (player.attackHitbox) resolveNailCollisions(player);
        resolveNailVsWalls(player);

        // CrystalGuardian_laser
        resolveLaserDamage(player);

        // Zote_action
        if (dialogueCalmdown > 0) dialogueCalmdown--;
        updateZote(player,room);          // عصبانیت / تعقیب
        checkZoteInteraction(player, room);

        // Pause / (charm,state,skills,deathtimes,...)
        if (input.justPressed(InputHandler.Action.PAUSE) && listener != null)
            listener.onPauseRequested();
        if (input.justPressed(InputHandler.Action.INVENTORY) && listener != null)
            listener.onInventoryRequested();

        // Achievements
        checkAchievements(player);
    }
    private void resolveWaterWalk(Player player) {
        boolean inWater = false;
        for (WaterWalkZone w : gameState.getLevel().currentRoom.waterWalkZones) {
            if (player.getBounds().overlaps(w.getBounds())) {
                inWater = true;
                break;
            }
        }
        if (inWater) {
            player.velX *= 0.55f;
            if (player.onGround && Math.abs(player.velX) > 0.5f) {
                if (++waterStepTimer >= 22) {
                    audio.playSfx(AudioManager.SFX_WATER_WALK);
                    waterStepTimer = 0;
                }
            }
            else waterStepTimer = 0;
        }
        else waterStepTimer = 0;
        inWaterLast = inWater;
    }

    //Input ----> Player actions

    private void processInput(Player player) {
        //movement
        if (input.isPressed(InputHandler.Action.MOVE_LEFT)) player.moveX(-1);
        else if (input.isPressed(InputHandler.Action.MOVE_RIGHT)) player.moveX(1);
        else player.stopX();
        if (inDialogue) { gameState.getPlayer().stopX(); return; }

        // Jump
        if (input.justPressed(InputHandler.Action.JUMP)) {
            if (player.tryJump()) audio.playSfx(AudioManager.SFX_JUMP);
        }
        if (input.justReleased(InputHandler.Action.JUMP)) player.cutJump();//liner height of jump

        // Dash
        if (input.justPressed(InputHandler.Action.DASH)) {
            if (player.tryDash()) audio.playSfx(AudioManager.SFX_DASH);
        }

        // Attack
        if (input.justPressed(InputHandler.Action.ATTACK)) {
            int dir = input.attackDirection(player.facing);
            if (player.tryAttack(dir)) audio.playSfx(AudioManager.SFX_NAIL_SLASH);
        }

        // Focus
        if (input.isPressed(InputHandler.Action.FOCUS)) {
            if (!player.isFocusing) {
                if (player.tryFocus()) audio.playSfx(AudioManager.SFX_FOCUS_BEGIN);
            }
        }
        else {
            if (player.isFocusing) player.stopFocus();
        }

        // Vengeful_Spirit
        if (input.justPressed(InputHandler.Action.CAST_VS)) {
            if (!input.isPressed(InputHandler.Action.LOOK_DOWN)) {
                if (player.tryVengefulSpirit()) {
                    //reserved for after update
                }
            }
            else player.tryHowlingWraiths();
        }
        if (input.justPressed(InputHandler.Action.CAST_HW)) {
            player.tryHowlingWraiths();
        }
    }

    private void handlePendingSpells(Player player) {
        if (player.pendingSpell == 0) return;
        int pendingSpell = player.pendingSpell;
        player.pendingSpell = 0;
        if (pendingSpell == 1) {
            gameState.spawnProjectile(player.x + player.W / 2f,player.y + player.H / 2f, player.facing);
        } else if (pendingSpell == 2) gameState.spawnHowlingWraiths();
    }

    private void resolvePhysics(Player player) {
        List<Platform> platforms = gameState.getLevel().currentRoom.platforms;

        //X movement
        float oldX = player.x;
        player.x += player.velX;
        boolean hitWallLeft  = false;
        boolean hitWallRight = false;

        for (Platform plat : platforms) {
            if (!overlaps(player.x, player.y, player.W, player.H, plat.x, plat.y, plat.w, plat.h)) continue;
            if (plat.type == Platform.Type.ONE_WAY) continue;

            if (player.velX > 0) {           // moving right--->left key
                player.x = plat.x - player.W;
                hitWallRight = true;
            } else if (player.velX < 0) {    // moving left--->right key
                player.x = plat.right();
                hitWallLeft = true;
            }
            player.velX = 0;
        }

        if (hitWallRight) player.touchWall(1);
        else if (hitWallLeft) player.touchWall(-1);
        else player.leaveWall();

        //Y movement
        boolean wasOnGround = player.onGround;
        player.onGround = false;
        player.y += player.velY;

        for (Platform plat : platforms) {
            if (!overlaps(player.x, player.y, player.W, player.H, plat.x, plat.y, plat.w, plat.h)) continue;

            if (plat.type == Platform.Type.ONE_WAY) {
                float prevBottom = player.y - player.velY;
                if (player.velY < 0 && prevBottom >= plat.top() - 2f) {
                    player.y = plat.top();
                    player.land_on_ground();
                }
                continue;
            }

            if (player.velY < 0) {           // fall
                player.y = plat.top();
                player.land_on_ground();
            } else if (player.velY > 0) {    // jump_up
                player.y = plat.y - player.H;
                player.velY = 0;
            }
        }

        if (!player.onGround && wasOnGround) player.leaveGround();

        // Keep player inside room bounds
        Room room = gameState.getLevel().currentRoom;
        player.x = Math.max(room.boundsX, Math.min(player.x, room.boundsX + room.boundsW - player.W));
        if (player.y < room.boundsY) {
            handleHazardHit(player);
        }
    }

    //enemy
    private void resolveEnemyPhysics() {
        Room room = gameState.getLevel().currentRoom;
        for (Enemy enemy : room.enemies) {
            if (!enemy.alive || !enemy.isActive) continue;
            if (enemy instanceof CrystalGuardian) continue;

            // movement and turn back from wall
            enemy.x += enemy.velX;
            for (Platform plat : room.platforms) {
                if (plat.type == Platform.Type.ONE_WAY) continue;
                if (!overlaps(enemy.x, enemy.y, enemy.width, enemy.height, plat.x, plat.y, plat.w, plat.h)) continue;
                if (enemy.velX > 0) enemy.x = plat.x - enemy.width;    // راست--->هل به چپ
                else if (enemy.velX < 0) enemy.x = plat.right();       // چپ--->هل به راست

                flipEnemy(enemy);        // wall--> turn
                enemy.velX = 0;
            }
            //turn from bound of room
            if (enemy.x < room.boundsX) {
                enemy.x = room.boundsX;
                flipEnemy(enemy);
            }
            else if (enemy.x + enemy.width > room.boundsX + room.boundsW) {
                enemy.x = room.boundsX + room.boundsW - enemy.width;
                flipEnemy(enemy);
            }
            //turn for flying enemies(عمودی)
            enemy.onGround = false;
            enemy.y += enemy.velY;
            for (Platform plat : room.platforms) {
                if (!overlaps(enemy.x, enemy.y, enemy.width, enemy.height, plat.x, plat.y, plat.w, plat.h)) continue;
                if (plat.type == Platform.Type.ONE_WAY) {
                    float prevBottom = enemy.y - enemy.velY;
                    if (enemy.velY < 0 && prevBottom >= plat.top() - 2f) {
                        enemy.y = plat.top();
                        enemy.velY = 0;
                        enemy.onGround = true;
                    }
                    continue;
                }
                //keep in bound
                if (enemy.velY < 0) {
                    enemy.y = plat.top();
                    enemy.velY = 0;
                    enemy.onGround = true;
                }
                else if (enemy.velY > 0) {
                    enemy.y = plat.y - enemy.height;
                    enemy.velY = 0;
                }
            }

            //if isnt floor--->turn
            if (enemy.onGround && Math.abs(enemy.velX) > 0.01f
                && (enemy instanceof GroundEnemy || enemy instanceof HuskHornhead)) {
                float probeX = enemy.velX > 0 ? enemy.x + enemy.width + 2f : enemy.x - 2f;
                boolean groundAhead = false;
                for (Platform plat : room.platforms) {
                    if (probeX >= plat.x && probeX <= plat.right() && Math.abs(enemy.y - plat.top()) < 4f) {
                        groundAhead = true;
                        break;
                    }
                }
                if (!groundAhead) flipEnemy(enemy);
            }
        }
    }
    private void flipEnemy(Enemy enemy) {
        if (enemy instanceof GroundEnemy ge)  ge.needsFlip = true;   // Crawler
        else if (enemy instanceof HuskHornhead hh) hh.forceFlip();   // Crystallized
    }
    //traps(hazard)
    private void resolveHazardContact(Player player) {
        Rectangle pb = player.getBounds();
        for (Hazard hazard : gameState.getLevel().currentRoom.hazards) {
            if (pb.overlaps(hazard.getBounds())) { handleHazardHit(player); return; }
        }
    }
    private void handleHazardHit(Player p) {
        if (cheat.godModeEnabled) return;
        p.masks = 0;//kill
        p.die();
    }
    //False_Knight
    private void updateFalseKnightAttacks(Player player) {
        var room = gameState.getLevel().currentRoom;
        FalseKnight fk = gameState.getLevel().falseKnight;
        if (fk != null && fk.alive && room.isBossRoom) {
            boolean canHurt = !cheat.godModeEnabled && !player.isInvincible;
            // slam damage
            if ((fk.slamImpact || fk.powerSlamImpact) && canHurt && fk.getSlamBounds().overlaps(player.getBounds())) {
                if (player.takeDamage(GameConfig.FK_SLAM_DAMAGE, fk.x))
                    audio.playSfx(AudioManager.SFX_DAMAGE);
            }

            //powerfull slam
            if (fk.powerSlamImpact) {
                float wy = fk.y;
                waves.add(new Shockwave(fk.getMaceCenterX(), wy,  1));
                waves.add(new Shockwave(fk.getMaceCenterX(), wy, -1));
                audio.playSfx(AudioManager.SFX_BOSS_ROAR);
            }
        }
        // update wave attacks
        for (var it = waves.iterator(); it.hasNext(); ) {
            Shockwave w = it.next();
            w.update();
            if (fk != null && (w.x < fk.arenaLeft - 40 || w.x > fk.arenaRight + 40))
                w.alive = false;
            if (w.alive && !cheat.godModeEnabled && !player.isInvincible
                && w.getBounds().overlaps(player.getBounds())) {
                if (player.takeDamage(w.damage, w.x))
                    audio.playSfx(AudioManager.SFX_DAMAGE);
                w.alive = false;
            }
            if (!w.alive) it.remove();
        }
    }
    private void resolveEnemyContact(Player player) {
        if (cheat.godModeEnabled || player.isInvincible) return;
        Rectangle pb = player.getBounds();
        for (Enemy e : gameState.getLevel().currentRoom.enemies) {
            if (!e.alive) continue;
            if (pb.overlaps(e.getContactBounds())) {
                if (player.takeDamage(e.damage, e.x)) {
                    audio.playSfx(AudioManager.SFX_DAMAGE);
                }
            }
        }
    }
    private void resolveNailVsWalls(Player player) {
        Room room = gameState.getLevel().currentRoom;
        Rectangle nail = player.getAttackBounds();
        for (BreakableWall bw : room.breakableWalls) {
            if (bw.hitCooldown > 0) bw.hitCooldown--;
            if (bw.broken || nail.width == 0 || bw.hitCooldown > 0) continue;
            if (!nail.overlaps(bw.getBounds())) continue;

            bw.hp--;
            bw.hitCooldown = 20;//5 damage health
            audio.playSfx(AudioManager.SFX_NAIL_HIT);

            if (bw.hp <= 0) {
                bw.broken = true;
                room.platforms.remove(bw.platform);//remove wall
                audio.playSfx(AudioManager.SFX_WALL_BREAK);
            }
        }
    }
    private void resolveNailCollisions(Player player) {
        Rectangle nail = player.getAttackBounds();
        if (nail.width == 0) return;
        int dmg = player.nailDamage();

        for (Enemy enemy : gameState.getLevel().currentRoom.enemies) {
            if (!enemy.alive || enemy.hurtTimer > 0) continue;
            if (!nail.overlaps(enemy.getBounds())) continue;

            // Pogo
            if (player.attackDir == 3 && !player.onGround) {
                player.triggerPogo();
            }

            // Boss FK only damaged in stun
            if (enemy instanceof FalseKnight fk && fk.isVulnerable()  && !nail.overlaps(fk.getVulnerableBounds())) continue;

            boolean hit = enemy.takeDamage(dmg, player.x);
            if (hit) {
                player.gainSoul(GameConfig.SOUL_PER_HIT);
                audio.playSfx(AudioManager.SFX_NAIL_HIT);
                audio.playSfx(AudioManager.SFX_SOUL_GAIN);
                if (!enemy.alive) {
                    player.enemiesKilled++;
                    if (enemy instanceof FalseKnight) {
                        gameState.bossDefeated = true;
                        gameState.getAchievements().unlock("false_knight");
                        if (listener != null) listener.onBossDefeated();
                    }
                }
            }
        }
    }

    //projectiles
    private void resolveProjectileCollisions() {
        Room room = gameState.getLevel().currentRoom;
        for (Projectile projectile : gameState.projectiles) {
            if (!projectile.alive) continue;

            // Wall
            for (Platform plat : room.platforms) {
                if (projectile.getBounds().overlaps(plat.getBounds())) { projectile.destroy(); break; }
            }
            if (!projectile.alive) continue;
            // Enemy
            for (Enemy enemy : room.enemies) {
                if (!enemy.alive) continue;
                if (projectile.getBounds().overlaps(enemy.getBounds())) {
                    if (enemy instanceof FalseKnight fk && fk.isVulnerable()
                        && !projectile.getBounds().overlaps(fk.getVulnerableBounds())) continue;
                    int damage = projectile.damage;
                    if (gameState.getPlayer().equippedCharms.contains(
                            com.hollowknight.model.item.CharmType.VOID_HEART))
                        damage = (int)(damage * 1.5f);
                    enemy.takeDamage(damage, projectile.x);
                    projectile.destroy();
                    if (!enemy.alive) {
                        gameState.getPlayer().enemiesKilled++;
                        if (enemy instanceof FalseKnight) {
                            gameState.bossDefeated = true;
                            gameState.getAchievements().unlock("false_knight");
                            if (listener != null) listener.onBossDefeated();
                        }
                    }
                    break;
                }
            }

            // out of room bounds
            Room r = gameState.getLevel().currentRoom;
            if (projectile.x < r.boundsX || projectile.x > r.boundsX + r.boundsW)
                projectile.destroy();
        }
    }

    //Howling_Wraiths
    private void resolveWraithCollisions() {
        Room room = gameState.getLevel().currentRoom;
        for (HowlingWraithsEffect hw : gameState.wraiths) {
            boolean damageFrame = hw.update();
            if (!damageFrame || !hw.alive) continue;

            int damage = GameConfig.HW_DAMAGE;
            if (gameState.getPlayer().equippedCharms.contains(
                    com.hollowknight.model.item.CharmType.VOID_HEART))
                damage = (int)(damage * 1.5f);
            for (Enemy enemy : room.enemies) {
                if (!enemy.alive) continue;
                if (hw.getBounds().overlaps(enemy.getBounds())) {
                    if (enemy instanceof FalseKnight fk && fk.isVulnerable()
                        && !hw.getBounds().overlaps(fk.getVulnerableBounds())) continue;
                    enemy.takeDamage(damage, hw.x + hw.W / 2f);
                    if (!enemy.alive) gameState.getPlayer().enemiesKilled++;
                }
            }
        }
    }

    //Crystal_Guardian laser damage
    private void resolveLaserDamage(Player player) {
        if (cheat.godModeEnabled) return;
        for (Enemy enemy : gameState.getLevel().currentRoom.enemies) {
            if (!(enemy instanceof CrystalGuardian cg) || !cg.laserActive) continue;
            float laserY   = cg.y + cg.height / 2f;
            float laserMinX = cg.laserFacing > 0 ? cg.x + cg.width : 0;
            float laserMaxX = cg.laserFacing > 0
                    ? gameState.getLevel().currentRoom.boundsX + gameState.getLevel().currentRoom.boundsW
                    : cg.x;

            if (player.y < laserY + 8 && player.y + player.H > laserY - 8
                    && player.x + player.W > laserMinX && player.x < laserMaxX) {
                if (player.takeDamage(cg.damage, cg.x)) {
                    audio.playSfx(AudioManager.SFX_DAMAGE);
                }
            }
        }
    }

    //portals
    private void checkPortals(Player player) {
        Rectangle pb = player.getBounds();
        for (Room.Portal portal : gameState.getLevel().currentRoom.portals) {
            Rectangle pr = new Rectangle(portal.x, portal.y, portal.w, portal.h);
            if (pb.overlaps(pr)) {
                if (listener != null)
                    listener.onRoomTransition(portal.targetRoomId, portal.targetX, portal.targetY);
                return;
            }
        }
    }

    //zote
    private void checkZoteInteraction(Player player, Room room) {
        playerNearZote = false;
        if (!room.hasZote || room.zoteAngryTimer > 0) {
            if (inDialogue) endDialogue();
            return;
        }
        float dx = Math.abs((player.x + player.W / 2f) - (room.zoteX + 13f));
        float dy = Math.abs(player.y - room.zoteY);
        boolean near = dx < 70f && dy < 80f;
        playerNearZote = near && !inDialogue;
        if (!inDialogue) {
            if (near && dialogueCalmdown <= 0
                && input.justPressed(InputHandler.Action.INTERACT)) {
                inDialogue = true;
                dialogueLine = 0;
                player.stopX();
                startZoteLine(room);
            }
            return;
        }

        //word to word animation
        typewriterTimer  += 1f / 60f;
        int total         = activeDialogue.length();
        dialogueCharCount = Math.min(total, (int) (typewriterTimer * CHARS_PER_SEC));

        // enter ---> next dialouge
        if (com.badlogic.gdx.Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.ENTER)) {
            if (dialogueCharCount < total) {
                dialogueCharCount = total;
                typewriterTimer   = total / CHARS_PER_SEC;
            }
            else {
                boolean mainPhase = room.zoteDialogueIndex == 0;
                dialogueLine++;
                if (mainPhase && dialogueLine < ZOTE_LINES.length) {
                    startZoteLine(room);
                }
                else {
                    if (mainPhase) room.zoteDialogueIndex = 1;  // اصلی‌ها تمام شد → حالت Precepts
                    endDialogue();
                }
            }
        }

        if (!near) endDialogue();   //end when increase distance
    }
    private void startZoteLine(Room room) {
        activeDialogue = (room.zoteDialogueIndex == 0)
            ? ZOTE_LINES[dialogueLine]                                    //dialouge
            : ZOTE_PRECEPTS[zoteRng.nextInt(ZOTE_PRECEPTS.length)];      //rule(غرغر)
        dialogueCharCount = 0;
        typewriterTimer   = 0f;
        playZoteVoice();
    }

    private void endDialogue() {
        inDialogue = false;
        activeDialogue = null;
        dialogueCharCount = 0;
        dialogueCalmdown = 20;
    }

    private void playZoteVoice() {
        audio.playZoteVoice(1 + zoteRng.nextInt(AudioManager.ZOTE_VOICE_COUNT));
    }
    //angry zote
    private void updateZote(Player player, Room room) {
        if (!room.hasZote) return;
        if (room.zoteHitCooldown > 0) room.zoteHitCooldown--;
        //attack zote
        Rectangle nail = player.getAttackBounds();
        if (nail.width > 0 && room.zoteHitCooldown <= 0) {
            Rectangle zb = new Rectangle(room.zoteX, room.zoteY, 26f, 36f);
            if (nail.overlaps(zb)) {
                room.zoteAngryTimer  = 300;//5 second angry
                room.zoteHitCooldown = 25;
                room.zoteAttackTick  = 1;//time in game
                endDialogue();
                playZoteVoice();
                com.badlogic.gdx.Gdx.app.log("Zote", "ANGRY! hit at zoteX=" + room.zoteX);
            }
        }
        float dxToPlayer = (player.x + player.W / 2f) - (room.zoteX + 13f);
        if (room.zoteAngryTimer > 0) {
            //run and attack without damage
            room.zoteAngryTimer--;
            if (Math.abs(dxToPlayer) > 30f) {
                float dir = Math.signum(dxToPlayer);
                room.zoteFacing = dir >= 0 ? 1 : -1;
                room.zoteX += dir * 2.2f;
            }
            room.zoteAttackTick = (room.zoteAttackTick + 1) % 120;
            if (room.zoteAttackTick == 0) playZoteVoice();

            // MAX 250 f distance from spawn point and then return
            room.zoteX = Math.max(room.zoteHomeX - 250f,
                Math.min(room.zoteX, room.zoteHomeX + 250f));
            room.zoteX = Math.max(room.boundsX + 8f,
                Math.min(room.zoteX, room.boundsX + room.boundsW - 34f));
        }
        else if (Math.abs(room.zoteX - room.zoteHomeX) > 2f) {
            //return
            float dir = Math.signum(room.zoteHomeX - room.zoteX);
            room.zoteFacing = dir >= 0 ? 1 : -1;
            room.zoteX += dir * 1.2f;
        }
        else {
            //idle
            room.zoteFacing = 1;
        }
    }

    private void checkAchievements(Player player) {
        var achievements = gameState.getAchievements();
        if (gameState.bossDefeated) achievements.unlock("false_knight");
        if (gameState.bossDefeated) achievements.unlock("completion");
        if (player.enemiesKilled >= 50)  achievements.unlock("true_hunter");
        if (player.enemiesKilled == 0 && gameState.getLevel().currentRoom.isBossRoom) achievements.unlock("pacifist");
        if (gameState.getElapsedSeconds() < 1200 && gameState.bossDefeated)      achievements.unlock("speedrun");
    }
    private boolean overlaps(float ax, float ay, float aw, float ah,
                             float bx, float by, float bw, float bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }
    public void enterRoom(String roomId, float px, float py) {
        boolean confirm = gameState.getLevel().switchRoom(roomId, px, py);
        waves.clear();
        if (!confirm) return;
        Room next = gameState.getLevel().currentRoom;
        gameState.getPlayer().x = px;
        gameState.getPlayer().y = py;
        gameState.getPlayer().setRespawnPoint(px, py);
        audio.playBgmForRoom(next);
    }
}
