package com.hollowknight.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Preferences;

public class InputHandler {
    public enum Action {
        MOVE_LEFT, MOVE_RIGHT, JUMP, DASH,
        ATTACK, FOCUS, CAST_VS, CAST_HW,
        LOOK_UP, LOOK_DOWN, INTERACT,
        INVENTORY, PAUSE
    }
    private final int[] bindings = new int[Action.values().length];
    private final boolean[] current = new boolean[Action.values().length];
    private final boolean[] prev = new boolean[Action.values().length];
    private static final String PREF_NAME = "hk_controls";

    public InputHandler() {
        setDefaults();
        loadBindings();
    }

    private void setDefaults() {
        bindings[Action.MOVE_LEFT .ordinal()] = Keys.LEFT;
        bindings[Action.MOVE_RIGHT.ordinal()] = Keys.RIGHT;
        bindings[Action.JUMP      .ordinal()] = Keys.Z;
        bindings[Action.DASH      .ordinal()] = Keys.C;
        bindings[Action.ATTACK    .ordinal()] = Keys.X;
        bindings[Action.FOCUS     .ordinal()] = Keys.A;
        bindings[Action.CAST_VS   .ordinal()] = Keys.V;
        bindings[Action.CAST_HW   .ordinal()] = Keys.S;
        bindings[Action.LOOK_UP   .ordinal()] = Keys.UP;
        bindings[Action.LOOK_DOWN .ordinal()] = Keys.DOWN;
        bindings[Action.INTERACT  .ordinal()] = Keys.UP;
        bindings[Action.INVENTORY .ordinal()] = Keys.I;
        bindings[Action.PAUSE     .ordinal()] = Keys.ESCAPE;
    }
    public void snapshot() {
        for (Action a : Action.values()) {
            int i = a.ordinal();
            prev[i] = current[i];
            current[i]  = Gdx.input.isKeyPressed(bindings[i]);
        }
    }
    public boolean isPressed (Action a) { return current[a.ordinal()]; }
    public boolean justPressed(Action a) { return  current[a.ordinal()] && !prev[a.ordinal()]; }
    public boolean justReleased(Action a) { return !current[a.ordinal()] &&  prev[a.ordinal()]; }

    // 0=right
    // 1=left
    // 2=up
    // 3=down
    public int attackDirection(int playerFacing) {
        if (isPressed(Action.LOOK_UP))   return 2;
        if (isPressed(Action.LOOK_DOWN)) return 3;
        return playerFacing > 0 ? 0 : 1;
    }
    public void rebind(Action a, int keyCode) {
        bindings[a.ordinal()] = keyCode;
        saveBindings();
    }
    public void resetBindings() {
        setDefaults();
        saveBindings();
    }
    public int getBinding(Action a) { return bindings[a.ordinal()]; }

    private void saveBindings() {
        Preferences preferences = Gdx.app.getPreferences(PREF_NAME);
        for (Action action : Action.values())
            preferences.putInteger(action.name(), bindings[action.ordinal()]);
        preferences.flush();
    }
    private void loadBindings() {
        Preferences preferences = Gdx.app.getPreferences(PREF_NAME);
        for (Action action : Action.values()) {
            int def = bindings[action.ordinal()];//current-->default
            bindings[action.ordinal()] = preferences.getInteger(action.name(), def);
        }
    }
}
