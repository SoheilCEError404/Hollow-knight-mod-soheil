package com.hollowknight.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.hollowknight.config.GameConfig;
import com.hollowknight.model.world.Room;
import java.util.HashMap;
import java.util.Map;

public class AudioManager {

    //setting_menu
    public float   musicVolume  = GameConfig.DEFAULT_MUSIC_VOL;
    public float   sfxVolume    = GameConfig.DEFAULT_SFX_VOL;
    public boolean musicEnabled = true;
    public boolean sfxEnabled   = true;

    //music
    private Music currentMusic;
    private String currentTrackId = "";
    private final Map<String, Music>  musicMap = new HashMap<>();
    //sfx
    private final Map<String, Sound>  sfxMap   = new HashMap<>();
    private Sound lastZoteSound;//--->disconnect zote

    //musics
    public static final String BGM_MENU        = "menu";
    public static final String BGM_CROSSROADS  = "crossroads";
    public static final String BGM_GREENPATH   = "greenpath";
    public static final String BGM_CITY        = "city_of_tears";
    public static final String BGM_CRYSTAL     = "crystal_peaks";
    public static final String BGM_BOSS        = "false_knight";
    public static final String BGM_MAP1        = "map1";
    public static final String BGM_MAP2        = "map2";
    public static final String BGM_END         = "the_end";

    //sfxs
    public static final String SFX_NAIL_SLASH  = "nail_slash";
    public static final String SFX_NAIL_HIT    = "nail_hit";
    public static final String SFX_DAMAGE      = "damage";
    public static final String SFX_SOUL_GAIN   = "soul_gain";
    public static final String SFX_FOCUS_BEGIN = "focus_begin";
    public static final String SFX_FOCUS_END   = "focus_end";
    public static final String SFX_DASH        = "dash";
    public static final String SFX_JUMP        = "jump";
    public static final String SFX_DEATH       = "death";
    public static final String SFX_BOSS_ROAR   = "boss_roar";
    public static final String SFX_WATER_WALK  = "water_walk";
    public static final String SFX_WALL_BREAK = "wall_break";
    public static final int ZOTE_VOICE_COUNT = 3;

    public void loadAll() {
        loadMusic(BGM_MENU,       "audio/music/menu.mp3");
        loadMusic(BGM_CROSSROADS, "audio/music/crossroads.ogg");
        loadMusic(BGM_GREENPATH,  "audio/music/greenpath.ogg");
        loadMusic(BGM_CITY,       "audio/music/city_of_tears.ogg");
        loadMusic(BGM_CRYSTAL,    "audio/music/crystal_peaks.ogg");
        loadMusic(BGM_BOSS,       "audio/music/false_knight.ogg");
        loadMusic(BGM_MAP1,       "audio/music/map1.mp3");
        loadMusic(BGM_MAP2,       "audio/music/map2.mp3");
        loadMusic(BGM_END,        "audio/music/the_end.mp3");
        //
        loadSfx(SFX_NAIL_SLASH,  "audio/sfx/nail_slash.wav");
        loadSfx(SFX_NAIL_HIT,    "audio/sfx/nail_hit.wav");
        loadSfx(SFX_DAMAGE,      "audio/sfx/damage.wav");
        loadSfx(SFX_SOUL_GAIN,   "audio/sfx/soul_gain.wav");
        loadSfx(SFX_FOCUS_BEGIN, "audio/sfx/focus_begin.wav");
        loadSfx(SFX_FOCUS_END,   "audio/sfx/focus_end.wav");
        loadSfx(SFX_DASH,        "audio/sfx/dash.wav");
        loadSfx(SFX_JUMP,        "audio/sfx/jump.wav");
        loadSfx(SFX_DEATH,       "audio/sfx/death.wav");
        loadSfx(SFX_BOSS_ROAR,   "audio/sfx/boss_roar.wav");
        loadSfx(SFX_WALL_BREAK,  "audio/sfx/wall_break.wav");
        loadSfx(SFX_WATER_WALK,  "audio/sfx/water_walk.wav");
        for (int i = 1; i <= ZOTE_VOICE_COUNT; i++)
            loadSfx("zote_" + i, "audio/sfx/zote_" + i + ".mp3");
    }
    //each world music
    public void playBgmForEnvironment(String env) {
        String trackId = switch (env) {
            case GameConfig.ENV_GREENPATH     -> BGM_GREENPATH;
            case GameConfig.ENV_CITY_OF_TEARS -> BGM_CITY;
            case GameConfig.ENV_CRYSTAL_PEAKS -> BGM_CRYSTAL;
            default                           -> BGM_CROSSROADS;
        };
        playMusic(trackId);
    }
    public void playBgmForRoom(Room room) {
        if (room.isBossRoom) { playMusic(BGM_BOSS); return; }
        switch (room.id) {
            case "tiled_map1" -> playMusic(BGM_MAP1);
            case "tiled_map2" -> playMusic(BGM_MAP2);
            default           -> playBgmForEnvironment(room.environment);
        }
    }

    //play music methods
    public void playMusic(String id) {
        if (id.equals(currentTrackId)) return;
        stopMusic();
        Music music = musicMap.get(id);
        if (music == null) return;
        currentTrackId = id;
        currentMusic   = music;
        music.setLooping(true);
        music.setVolume(musicEnabled ? musicVolume : 0f);
        music.play();
    }
    public void stopMusic() {
        if (currentMusic != null) { currentMusic.stop(); currentMusic = null; }
        currentTrackId = "";
    }
    public void setMusicVolume(float v) {
        musicVolume = Math.max(0, Math.min(1, v));
        if (currentMusic != null) currentMusic.setVolume(musicEnabled ? musicVolume : 0f);
    }
    public void toggleMusic() {
        musicEnabled = !musicEnabled;
        if (currentMusic != null)
            currentMusic.setVolume(musicEnabled ? musicVolume : 0f);
    }

    //play sfx methods

    public void playSfx(String id) {
        if (!sfxEnabled) return;
        Sound s = sfxMap.get(id);
        if (s != null) s.play(sfxVolume);
    }
    public void playZoteVoice(int idx) {
        if (!sfxEnabled) return;
        if (lastZoteSound != null) lastZoteSound.stop();
        Sound sfx = sfxMap.get("zote_" + idx);
        if (sfx != null) { sfx.play(sfxVolume); lastZoteSound = sfx; }
    }
    public void setSfxVolume(float v) {
        sfxVolume = Math.max(0, Math.min(1, v));
    }
    public void toggleSfx() { sfxEnabled = !sfxEnabled; }

    //setting
    public void saveSettings() {
        Preferences p = Gdx.app.getPreferences("hk_audio");
        p.putFloat  ("musicVol", musicVolume);
        p.putFloat  ("sfxVol",   sfxVolume);
        p.putBoolean("musicOn",  musicEnabled);
        p.putBoolean("sfxOn",    sfxEnabled);
        p.flush();
    }

    public void loadSettings() {
        Preferences prefence = Gdx.app.getPreferences("hk_audio");
        musicVolume  = prefence.getFloat  ("musicVol", GameConfig.DEFAULT_MUSIC_VOL);
        sfxVolume    = prefence.getFloat  ("sfxVol",   GameConfig.DEFAULT_SFX_VOL);
        musicEnabled = prefence.getBoolean("musicOn",  true);
        sfxEnabled   = prefence.getBoolean("sfxOn",    true);
    }

    //load files
    private void loadMusic(String id, String path) {
        boolean exists = Gdx.files.internal(path).exists();
        Gdx.app.log("AudioManager", path + " -> exists=" + exists);
        try {
            if (exists)
                musicMap.put(id, Gdx.audio.newMusic(Gdx.files.internal(path)));
        } catch (Exception e) {
            Gdx.app.error("AudioManager", "Could not load music: " + path, e);
        }
    }
    private void loadSfx(String id, String path) {
        try {
            if (Gdx.files.internal(path).exists())
                sfxMap.put(id, Gdx.audio.newSound(Gdx.files.internal(path)));
        } catch (Exception e) {
            Gdx.app.error("AudioManager", "Could not load SFX: " + path);
        }
    }
    public void dispose() {
        musicMap.values().forEach(Music::dispose);
        sfxMap  .values().forEach(Sound::dispose);
    }
}
