package com.hollowknight.controller;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.hollowknight.model.GameState;
import com.hollowknight.model.player.Player;
import com.hollowknight.controller.AudioManager;

public class CheatManager {

    public boolean noclipEnabled = false;
    public boolean godModeEnabled = false;
    private final AudioManager audio;

    public CheatManager(AudioManager audio) {
        this.audio = audio;
    }

    public String update(GameState gameState) {
        if (!Gdx.input.isKeyPressed(Keys.CONTROL_LEFT)
                && !Gdx.input.isKeyPressed(Keys.CONTROL_RIGHT)) return null;

        if (Gdx.input.isKeyJustPressed(Keys.B)) return cheatBossTP(gameState);
        if (Gdx.input.isKeyJustPressed(Keys.N)) return cheatNoclip();
        if (Gdx.input.isKeyJustPressed(Keys.H)) return cheatHeal(gameState.getPlayer());
        if (Gdx.input.isKeyJustPressed(Keys.R)) return cheatRefillSoul(gameState.getPlayer());
        if (Gdx.input.isKeyJustPressed(Keys.G)) return cheatGodMode();
        if (Gdx.input.isKeyJustPressed(Keys.K)) return cheatKillAll(gameState);
        return null;
    }
    //Boss
    private String cheatBossTP(GameState gs) {
        boolean ok = gs.getLevel().switchRoom("boss_room", 0, 0);
        if (ok) {
            gs.getPlayer().x = gs.getLevel().currentRoom.spawnX;
            gs.getPlayer().y = gs.getLevel().currentRoom.spawnY;
            audio.playBgmForRoom(gs.getLevel().currentRoom);
        }
        return ok ? "[CHEAT] Teleported to Boss Arena." : "[CHEAT] Boss room not found.";
    }
    //spector
    private String cheatNoclip() {
        noclipEnabled = !noclipEnabled;
        return noclipEnabled ? "[CHEAT] Noclip ON." : "[CHEAT] Noclip OFF.";
    }
    //health
    private String cheatHeal(Player p) {
        p.masks = p.maxMasks;
        return "[CHEAT] Full heal applied.";
    }
    //fill_soul
    private String cheatRefillSoul(Player p) {
        p.soul = p.maxSoul;
        return "[CHEAT] Soul refilled.";
    }
    //God_mode
    private String cheatGodMode() {
        godModeEnabled = !godModeEnabled;
        return godModeEnabled ? "[CHEAT] God Mode ON." : "[CHEAT] God Mode OFF.";
    }
    //kill_all
    private String cheatKillAll(GameState gs) {
        gs.getLevel().currentRoom.enemies.forEach(e -> { e.hp = 0; e.alive = false; });
        return "[CHEAT] All enemies eliminated.";
    }
    //spector_movement
    public void applyNoclipMovement(Player player) {
        float speed = 5f;
        if (Gdx.input.isKeyPressed(Keys.LEFT))  player.x -= speed;
        if (Gdx.input.isKeyPressed(Keys.RIGHT)) player.x += speed;
        if (Gdx.input.isKeyPressed(Keys.UP))    player.y += speed;
        if (Gdx.input.isKeyPressed(Keys.DOWN))  player.y -= speed;
        player.velX = 0; player.velY = 0;
    }
}
