package com.hollowknight;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.hollowknight.config.GameConfig;
import com.hollowknight.controller.AudioManager;
import com.hollowknight.model.GameState;
import com.hollowknight.model.system.AccountManager;
import com.hollowknight.model.system.SaveManager;
import com.hollowknight.view.screens.GameScreen;
import com.hollowknight.view.screens.InventoryScreen;
import com.hollowknight.view.screens.LoadMenuScreen;
import com.hollowknight.view.screens.LoginScreen;
import com.hollowknight.view.screens.NewGameScreen;
import com.hollowknight.view.screens.ScreenFactory;
import com.hollowknight.view.screens.SettingsScreen;
import com.hollowknight.view.screens.SignupScreen;

public class HollowKnight extends Game {
    public SpriteBatch   batch;
    public ShapeRenderer shapes;

    //singleton
    public AudioManager   audioManager;
    public SaveManager    saveManager;
    public AccountManager accountManager;
    public GameState      gameState;
    //
    public String loggedInUsername = null;
    //screen
    private Screen          mainMenuScreen;
    private LoginScreen     loginScreen;
    private SignupScreen    signupScreen;
    private LoadMenuScreen  loadMenuScreen;
    private NewGameScreen   newGameScreen;
    private GameScreen      gameScreen;
    private Screen          pauseScreen;
    private SettingsScreen  settingsScreen;
    private InventoryScreen inventoryScreen;
    private Screen          guideScreen;
    private Screen          achievementsScreen;
    private com.badlogic.gdx.graphics.Cursor customCursor;

    @Override
    public void create() {
        com.hollowknight.config.Lang.load();
        batch          = new SpriteBatch();
        shapes         = new ShapeRenderer();
        audioManager   = new AudioManager();
        saveManager    = new SaveManager();
        accountManager = new AccountManager();
        gameState      = new GameState();

        audioManager.loadSettings();
        audioManager.loadAll();
        navigateTo(GameConfig.STATE_MAIN_MENU);
        /// game cursor
        try {
            com.badlogic.gdx.graphics.Pixmap pm =
                new com.badlogic.gdx.graphics.Pixmap(
                    com.badlogic.gdx.Gdx.files.internal("sprites/ui/cursor.png"));
            int size = 32;
            com.badlogic.gdx.graphics.Pixmap pot = new com.badlogic.gdx.graphics.Pixmap(
                size, size, com.badlogic.gdx.graphics.Pixmap.Format.RGBA8888);
            pot.drawPixmap(pm,
                0, 0, pm.getWidth(), pm.getHeight(),
                0, 0, size, size);

            customCursor = com.badlogic.gdx.Gdx.graphics.newCursor(pot, 0, 0);
            com.badlogic.gdx.Gdx.graphics.setCursor(customCursor);
            pm.dispose();
            pot.dispose();
        } catch (Exception ex) {
            com.badlogic.gdx.Gdx.app.log("Cursor", "cursor.png load failed: " + ex.getMessage());
        }
    }

    public void navigateTo(String state) { navigateTo(state, -1); }

    public void navigateTo(String state, int saveSlot) {
        switch (state) {
            case GameConfig.STATE_MAIN_MENU -> {
                if (mainMenuScreen == null) mainMenuScreen = ScreenFactory.mainMenu(this);
                audioManager.playMusic(AudioManager.BGM_MENU);
                setScreen(mainMenuScreen);
            }
            case GameConfig.STATE_LOGIN -> {
                if (loginScreen == null) loginScreen = new LoginScreen(this);
                setScreen(loginScreen);
            }
            case GameConfig.STATE_SIGNUP -> {
                if (signupScreen == null) signupScreen = new SignupScreen(this);
                setScreen(signupScreen);
            }
            case GameConfig.STATE_LOAD_MENU -> {
                if (loadMenuScreen == null) loadMenuScreen = new LoadMenuScreen(this);
                setScreen(loadMenuScreen);
            }
            case GameConfig.STATE_NEW_GAME_MENU -> {
                if (newGameScreen == null) newGameScreen = new NewGameScreen(this);
                setScreen(newGameScreen);
            }
            case GameConfig.STATE_PLAYING -> {
                if (gameScreen == null) gameScreen = new GameScreen(this);
                if (saveSlot >= 0) gameScreen.loadSlot(saveSlot);
                else               gameScreen.newGame();
                setScreen(gameScreen);
            }
            case GameConfig.STATE_PAUSED -> {
                if (pauseScreen == null) pauseScreen = ScreenFactory.pauseScreen(this, gameScreen);
                else                     ScreenFactory.setPauseBack(pauseScreen, gameScreen);
                setScreen(pauseScreen);
            }
            case GameConfig.STATE_SETTINGS -> {
                if (settingsScreen == null) settingsScreen = new SettingsScreen(this);
                settingsScreen.setPreviousScreen(getScreen());
                setScreen(settingsScreen);
            }
            case GameConfig.STATE_INVENTORY -> {
                if (inventoryScreen == null) inventoryScreen = new InventoryScreen(this);
                inventoryScreen.setPreviousScreen(gameScreen);
                setScreen(inventoryScreen);
            }
            case GameConfig.STATE_GUIDE -> {
                if (guideScreen == null) guideScreen = ScreenFactory.guide(this);
                ScreenFactory.setBack(guideScreen, getScreen());
                setScreen(guideScreen);
            }
            case GameConfig.STATE_ACHIEVEMENTS -> {
                if (achievementsScreen == null) achievementsScreen = ScreenFactory.achievements(this);
                ScreenFactory.setBack(achievementsScreen, getScreen());
                setScreen(achievementsScreen);
            }
            case GameConfig.STATE_GAME_OVER -> {
                var player = gameState.getPlayer();
                int deaths = player != null ? player.deaths : 0;
                int kills = player != null ? player.enemiesKilled : 0;
                setScreen(ScreenFactory.gameOver(this, deaths, kills, gameState.getElapsedSeconds()));
            }
            case GameConfig.STATE_THE_END -> {
                //end music
                audioManager.playMusic(AudioManager.BGM_END);
                setScreen(ScreenFactory.theEnd(this));
            }
        }
    }
    //save game
    public boolean continueGame() {
        SaveManager.SaveData[] all = saveManager.loadAllSlots();
        int bestSlot = -1;
        long bestTime = -1;
        for (int i = 0; i < all.length; i++) {
            if (all[i] == null) continue;
            long t = parseTimestamp(all[i].timestamp);
            if (t > bestTime) { bestTime = t; bestSlot = i; }
        }
        if (bestSlot == -1) return false;
        loadGame(bestSlot);
        return true;
    }
    public void loadGame(int slot) {
        if (gameScreen == null) gameScreen = new GameScreen(this);
        gameScreen.loadSlot(slot);
        setScreen(gameScreen);
    }
    public void startNewGame(int slot) {
        if (gameScreen == null) gameScreen = new GameScreen(this);
        gameScreen.newGame();
        gameState.activeSaveSlot = slot;
        setScreen(gameScreen);
    }
    private long parseTimestamp(String iso) {
        try {
            return java.time.LocalDateTime.parse(iso).toEpochSecond(java.time.ZoneOffset.UTC);
        } catch (Exception e) {
            return 0L;
        }
    }
    /// /////////////
    @Override
    public void dispose() {
        batch.dispose();
        shapes.dispose();
        audioManager.dispose();
        if (customCursor != null) customCursor.dispose();
    }
}
